param([string]$Repo='C:\Users\karatuga\dev\git\client-insights')
$ErrorActionPreference='Stop'
$Repo=[IO.Path]::GetFullPath($Repo)
$manifest=Get-Content (Join-Path $PSScriptRoot 'update-manifest.json') -Raw | ConvertFrom-Json
function TextHash([string]$Path) {
    $text=[Text.Encoding]::UTF8.GetString([IO.File]::ReadAllBytes($Path)).Replace("`r`n","`n")
    $sha=[Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($text)))).Replace('-','').ToLowerInvariant() } finally {$sha.Dispose()}
}
$branch=git -C $Repo branch --show-current
$head=git -C $Repo rev-parse HEAD
if($branch -ne 'cdx/mr1-kotlin-icms-export' -or $head -ne '4ca6cd6845c4b6db41ef1b5919a703bd089a7995'){throw 'Unexpected branch or baseline; no files were changed.'}
$pending=@(git -C $Repo status --porcelain --untracked-files=no)
if($pending.Count -gt 0){throw 'Tracked changes already exist; preserve them and inspect before applying.'}
foreach($file in $manifest) {
    if($file.path -notlike 'icms-export/*' -or $file.path -match '(^|/)\.\.(/|$)'){throw 'Invalid update path.'}
    $source=Join-Path $PSScriptRoot $file.path
    $target=Join-Path $Repo $file.path
    if((Get-FileHash $source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $file.sha256){throw ('Package hash mismatch: '+$file.path)}
    if(Test-Path -LiteralPath $target) {
        if(!$file.oldSha256 -or (TextHash $target) -ne $file.oldSha256){throw ('Existing file differs from the expected baseline: '+$file.path)}
    } elseif($file.oldSha256){throw ('Expected baseline file is missing: '+$file.path)}
}
$backup=Join-Path $PSScriptRoot ('backup-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $backup | Out-Null
foreach($file in $manifest) {
    $target=Join-Path $Repo $file.path
    if(Test-Path -LiteralPath $target) {
        $saved=Join-Path $backup $file.path
        New-Item -ItemType Directory -Path (Split-Path $saved) -Force | Out-Null
        Copy-Item -LiteralPath $target -Destination $saved
    }
}
foreach($file in $manifest) {
    $target=Join-Path $Repo $file.path
    New-Item -ItemType Directory -Path (Split-Path $target) -Force | Out-Null
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot $file.path) -Destination $target
    if((Get-FileHash $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $file.sha256){throw ('Written file hash mismatch: '+$file.path)}
}
Write-Output ('APPLIED_FILES='+$manifest.Count)
Write-Output ('BACKUP='+$backup)
Write-Output 'No files deleted. No git add, commit or push performed.'
