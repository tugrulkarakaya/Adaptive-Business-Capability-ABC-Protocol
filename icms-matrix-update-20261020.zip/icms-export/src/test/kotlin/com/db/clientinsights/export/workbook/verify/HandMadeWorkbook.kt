package com.db.clientinsights.export.workbook.verify

import com.db.clientinsights.export.workbook.Booking
import com.db.clientinsights.export.workbook.Candidate
import com.db.clientinsights.export.workbook.Cell
import com.db.clientinsights.export.workbook.Chart
import com.db.clientinsights.export.workbook.ChartXml
import com.db.clientinsights.export.workbook.CollectionData
import com.db.clientinsights.export.workbook.Company
import com.db.clientinsights.export.workbook.CsvRow
import com.db.clientinsights.export.workbook.Jump
import com.db.clientinsights.export.workbook.PlatformNames
import com.db.clientinsights.export.workbook.ReviewData
import com.db.clientinsights.export.workbook.Row
import com.db.clientinsights.export.workbook.Sheet
import com.db.clientinsights.export.workbook.WorkbookLayout
import com.db.clientinsights.export.workbook.WorkbookLayout.BOOKING_HEADERS
import com.db.clientinsights.export.workbook.WorkbookLayout.MAIN_HEADERS
import com.db.clientinsights.export.workbook.WorkbookLayout.NS_A
import com.db.clientinsights.export.workbook.WorkbookLayout.NS_CHART
import com.db.clientinsights.export.workbook.WorkbookLayout.NS_DRAWING
import com.db.clientinsights.export.workbook.WorkbookLayout.NS_MAIN
import com.db.clientinsights.export.workbook.WorkbookLayout.NS_PKG_REL
import com.db.clientinsights.export.workbook.WorkbookLayout.NS_REL
import com.db.clientinsights.export.workbook.WorkbookLayout.S_BOOK_TEXT
import com.db.clientinsights.export.workbook.WorkbookLayout.S_INPUT
import com.db.clientinsights.export.workbook.WorkbookLayout.S_INPUT_DATE
import com.db.clientinsights.export.workbook.WorkbookModel
import com.db.clientinsights.export.workbook.WorksheetXml
import com.db.clientinsights.export.workbook.columnName
import com.db.clientinsights.export.workbook.ooxmlLiteral
import com.db.clientinsights.export.workbook.xmlEscape
import java.nio.file.Files
import java.nio.file.Path
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * A hand-made synthetic source and model with a matching .xlsx rendered by a minimal XML helper in this file, so the
 * verifier is also tested independently of the writer. Client 1 has one parent with 2 selected bookings and 1
 * unassigned booking; client 2 has no parent rows and no bookings. withBookings = false gives an empty Bookings tab.
 */
internal class HandMadeWorkbook(withBookings: Boolean) {
    private val c1 = "0012345"
    private val c2 = "777"
    private val parent = "900001"
    private val b1 = booking(c1, "000101", parent)
    private val b2 = booking(c1, "000102", parent)
    private val b3 = booking(c1, "000103", null)
    private val candidate = Candidate(csv("parent_id" to parent, "signals" to "CURRENT_PARENT",
        "current_records" to if (withBookings) "2" else "0"), emptyList(), null, if (withBookings) listOf(b1, b2) else emptyList())
    private val company1 = Company(c1, 1, csv("entity_id" to c1), csv("current_parent_count" to "1"), listOf(candidate), true,
        "complete", "None", 0, if (withBookings) listOf(b1, b2, b3) else emptyList(), if (withBookings) listOf(b3) else emptyList())
    private val company2 = Company(c2, 1, csv("entity_id" to c2), csv("current_parent_count" to ""), emptyList(), false,
        "INCOMPLETE", "None", 0, emptyList(), emptyList())
    val review = ReviewData(listOf(company1, company2), emptyMap(), emptyMap(), emptyList(), emptyList())
    val collection = CollectionData(Path.of("synthetic"), CollectionData.KIND_COLLECTION, "collection-manifest.json", "0".repeat(64), "run-1", null, null, "COMPLETE", null,
        "EXPLICIT_ENTITY_IDS", true, if (withBookings) 3 else 0, "Active", "0.4.0", "abc", "false", "1.3.0",
        listOf(c1, c2), emptyList())
    val model: WorkbookModel = buildModel(withBookings)

    private fun buildModel(withBookings: Boolean): WorkbookModel {
        val count = if (withBookings) 3L else 0L
        val pCount = if (withBookings) 2L else 0L
        val linkC = if (withBookings) WorkbookLayout.S_SUM_LINK else WorkbookLayout.S_SUM_INT
        val linkP = if (withBookings) WorkbookLayout.S_CHILD_LINK else WorkbookLayout.S_CHILD_INT
        fun inputs() = listOf(Cell.blank(13, S_INPUT), Cell.blank(14, S_INPUT), Cell.blank(15, S_INPUT), Cell.blank(16, S_INPUT_DATE))
        val main = listOf(
            Row(1, 0, false, 54.0, MAIN_HEADERS.mapIndexed { i, h -> Cell.text(i + 1, WorkbookLayout.S_HEADER, h) }),
            Row(2, 0, true, null, listOf(Cell.text(1, 2, c1), Cell.blank(2, 2), Cell.text(3, 2, "Alpha Holdings"),
                Cell.text(4, 2, WorkbookLayout.ROW_CLIENT), Cell.number(5, 3, 1), Cell.number(10, linkC, count),
                Cell.text(12, 2, "One current parent · no data issues")) + inputs()),
            Row(3, 1, false, null, listOf(Cell.text(1, 16, c1), Cell.text(4, 17, WorkbookLayout.ROW_CLIENT_DETAILS),
                Cell.text(12, 18, "Current rule: one\nliteral _x0041_ stays literal & <safe>"))),
            Row(4, 1, true, null, listOf(Cell.text(1, 10, c1), Cell.text(2, 6, parent), Cell.text(3, 11, "Parent Co"),
                Cell.text(4, 11, WorkbookLayout.ROW_CURRENT), Cell.decimal(7, 8, "16.7", "share"),
                Cell.number(10, linkP, pCount)) + inputs()),
            Row(5, 2, false, null, listOf(Cell.text(1, 16, c1), Cell.text(2, 16, parent),
                Cell.text(4, 17, WorkbookLayout.ROW_PARENT_DETAILS), Cell.text(12, 18, "Key share 16.7%"))),
            Row(6, 0, true, null, listOf(Cell.text(1, 2, c2), Cell.text(4, 2, WorkbookLayout.ROW_CLIENT),
                Cell.blank(5, 3), Cell.number(10, WorkbookLayout.S_SUM_INT, 0)) + inputs()),
            Row(7, 1, false, null, listOf(Cell.text(1, 16, c2), Cell.text(4, 17, WorkbookLayout.ROW_CLIENT_DETAILS))),
        )
        val bookingRows = mutableListOf(Row(1, 0, false, 66.0, BOOKING_HEADERS.mapIndexed { i, h -> Cell.text(i + 1, 1, h) }))
        if (withBookings) {
            listOf(Triple(b1, parent, "C0001-P0001"), Triple(b2, parent, "C0001-P0001"), Triple(b3, null, null))
                .forEachIndexed { i, (b, p, key) ->
                    bookingRows.add(Row(i + 2, 0, false, null, listOf(Cell.text(1, S_BOOK_TEXT, c1),
                        Cell.text(3, S_BOOK_TEXT, b.record["booking_record_id"]), Cell.text(10, S_BOOK_TEXT, p),
                        Cell.number(12, WorkbookLayout.S_BOOK_INT, 1), Cell.text(31, S_BOOK_TEXT, "C0001"),
                        Cell.text(32, S_BOOK_TEXT, key))))
                }
        }
        val labels = listOf("0 parents", "1 parent", "2 parents", "3 to 5 parents", "6 to 9 parents", "10 or more parents",
            "Unknown (total blank)")
        val values = listOf(0L, 1L, 0L, 0L, 0L, 0L, 1L)
        val summary = (1..29).map { r ->
            val cells = when (r) {
                1 -> listOf(Cell.text(1, WorkbookLayout.S_TITLE, "ICMS client parent review"))
                11 -> listOf(Cell.text(1, 22, "Clients with a recorded review status"),
                    Cell.formula(2, 27, WorkbookLayout.progressFormula(7), "0"))
                22 -> listOf(Cell.text(1, 1, "Current parents"), Cell.text(2, 1, "Clients"))
                in 23..29 -> listOf(Cell.text(1, 28, labels[r - 23]), Cell.number(2, 29, values[r - 23]))
                else -> emptyList()
            }
            Row(r, 0, false, if (r == 1) 24.0 else null, cells)
        }
        val rules = listOf(Row(1, 0, false, null, listOf(Cell.text(1, WorkbookLayout.S_TITLE, "Rules and assumptions"))),
            Row(2, 0, false, null, (1..4).map { Cell.blank(it, S_INPUT) }),
            Row(3, 0, false, null, (1..4).map { Cell.blank(it, S_INPUT) }))
        val jumps = if (withBookings) listOf(
            Jump(2, "jump_client_0001", WorkbookLayout.B_CLIENT_KEY, "C0001", c1, null),
            Jump(4, "jump_parent_0001_0001", WorkbookLayout.B_PARENT_KEY, "C0001-P0001", c1, parent)) else emptyList()
        return WorkbookModel(
            Sheet.of(WorkbookLayout.SUMMARY_SHEET, summary, WorkbookLayout.SUMMARY_WIDTHS, 0, 0),
            Sheet.of(WorkbookLayout.MAIN_SHEET, main, WorkbookLayout.MAIN_WIDTHS, 3, 1),
            Sheet.of(WorkbookLayout.BOOKINGS_SHEET, bookingRows, WorkbookLayout.BOOKING_WIDTHS, 3, 1),
            Sheet.of(WorkbookLayout.RULES_SHEET, rules, WorkbookLayout.RULES_WIDTHS, 0, 0),
            mapOf(c1 to 2, c2 to 6), mapOf(c1 to 3, c2 to 7), mapOf(c1 to listOf(4), c2 to emptyList()),
            mapOf(c1 to listOf(5), c2 to emptyList()), listOf(2, 4, 6),
            mapOf(c1 to if (withBookings) listOf(2, 3, 4) else emptyList(), c2 to emptyList()), jumps, 11,
            Chart(22, 23, labels, values, 3, 4), WorkbookLayout.DRAFT_DECISION_OPTIONS)
    }

    fun write(file: Path): Path = zip(parts(), file)

    fun zip(parts: Map<String, String>, file: Path): Path {
        ZipOutputStream(Files.newOutputStream(file)).use { zip ->
            for ((name, text) in parts) {
                zip.putNextEntry(ZipEntry(name).apply { time = 0 })
                zip.write(text.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
        }
        return file
    }

    /** A minimal, hand-written rendering of the model (independent of the writer lane). */
    fun parts(): MutableMap<String, String> {
        val d = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
        val ct = "application/vnd.openxmlformats-officedocument."
        val rt = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/"
        fun rels(vararg r: Pair<String, String>) = d + "<Relationships xmlns=\"$NS_PKG_REL\">" +
            r.mapIndexed { i, (t, target) -> "<Relationship Id=\"rId${i + 1}\" Type=\"$rt$t\" Target=\"$target\"/>" }.joinToString("") +
            "</Relationships>"
        val last = model.bookings.lastRow
        return linkedMapOf(
            "[Content_Types].xml" to d + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"${ct}spreadsheetml.sheet.main+xml\"/>" +
                "<Override PartName=\"/xl/styles.xml\" ContentType=\"${ct}spreadsheetml.styles+xml\"/>" +
                (1..WorkbookLayout.SHEETS.size).joinToString("") { "<Override PartName=\"/xl/worksheets/sheet$it.xml\" ContentType=\"${ct}spreadsheetml.worksheet+xml\"/>" } +
                "<Override PartName=\"/xl/drawings/drawing1.xml\" ContentType=\"${ct}drawing+xml\"/>" +
                "<Override PartName=\"/xl/charts/chart1.xml\" ContentType=\"${ct}drawingml.chart+xml\"/></Types>",
            "_rels/.rels" to rels("officeDocument" to "xl/workbook.xml"),
            "xl/workbook.xml" to d + "<workbook xmlns=\"$NS_MAIN\" xmlns:r=\"$NS_REL\"><bookViews><workbookView activeTab=\"0\"/></bookViews><sheets>" +
                WorkbookLayout.SHEETS.mapIndexed { i, n -> "<sheet name=\"$n\" sheetId=\"${i + 1}\" r:id=\"rId${i + 1}\"/>" }.joinToString("") +
                "</sheets><definedNames><definedName name=\"_xlnm._FilterDatabase\" localSheetId=\"2\" hidden=\"1\">" +
                xmlEscape(WorkbookLayout.filterDatabaseFormula(last)) + "</definedName>" +
                model.jumps.joinToString("") { "<definedName name=\"${it.name}\">${xmlEscape(WorkbookLayout.jumpFormula(it, last))}</definedName>" } +
                "</definedNames><calcPr calcId=\"191029\" fullCalcOnLoad=\"1\"/></workbook>",
            "xl/_rels/workbook.xml.rels" to rels("worksheet" to "worksheets/sheet1.xml", "worksheet" to "worksheets/sheet2.xml",
                "worksheet" to "worksheets/sheet3.xml", "worksheet" to "worksheets/sheet4.xml",
                "worksheet" to "worksheets/sheet5.xml", "worksheet" to "worksheets/sheet6.xml", "styles" to "styles.xml"),
            "xl/styles.xml" to WorkbookLayout.STYLES_XML,
            "xl/worksheets/sheet1.xml" to sheet(model.summary),
            "xl/worksheets/_rels/sheet1.xml.rels" to rels("drawing" to "../drawings/drawing1.xml"),
            "xl/worksheets/sheet2.xml" to sheet(model.main),
            "xl/worksheets/sheet3.xml" to sheet(model.bookings),
            "xl/worksheets/sheet4.xml" to sheet(model.rules),
            "xl/worksheets/sheet5.xml" to sheet(model.companyEvidence),
            "xl/worksheets/sheet6.xml" to sheet(model.matrix),
            "xl/drawings/drawing1.xml" to d + "<xdr:wsDr xmlns:xdr=\"$NS_DRAWING\" xmlns:a=\"$NS_A\"><xdr:oneCellAnchor>" +
                "<xdr:from><xdr:col>3</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>4</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from>" +
                "<xdr:ext cx=\"${WorkbookLayout.CHART_CX}\" cy=\"${WorkbookLayout.CHART_CY}\"/><xdr:graphicFrame macro=\"\">" +
                "<xdr:nvGraphicFramePr><xdr:cNvPr id=\"2\" name=\"Chart 1\" descr=\"${xmlEscape(ChartXml.ALT_TEXT)}\"/><xdr:cNvGraphicFramePr/></xdr:nvGraphicFramePr>" +
                "<xdr:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"0\" cy=\"0\"/></xdr:xfrm><a:graphic><a:graphicData uri=\"$NS_CHART\">" +
                "<c:chart xmlns:c=\"$NS_CHART\" xmlns:r=\"$NS_REL\" r:id=\"rId1\"/></a:graphicData></a:graphic></xdr:graphicFrame>" +
                "<xdr:clientData/></xdr:oneCellAnchor></xdr:wsDr>",
            "xl/drawings/_rels/drawing1.xml.rels" to rels("chart" to "../charts/chart1.xml"),
            "xl/charts/chart1.xml" to d + "<c:chartSpace xmlns:c=\"$NS_CHART\" xmlns:a=\"$NS_A\"><c:chart><c:title><c:tx><c:rich>" +
                "<a:bodyPr/><a:p><a:r><a:t>${ChartXml.TITLE}</a:t></a:r></a:p></c:rich></c:tx></c:title><c:plotArea><c:barChart>" +
                "<c:barDir val=\"col\"/><c:ser><c:idx val=\"0\"/><c:order val=\"0\"/><c:tx><c:strRef><c:f>Summary!\$B\$22</c:f>" +
                "<c:strCache><c:ptCount val=\"1\"/><c:pt idx=\"0\"><c:v>Clients</c:v></c:pt></c:strCache></c:strRef></c:tx>" +
                "<c:cat><c:strRef><c:f>Summary!\$A\$23:\$A\$29</c:f><c:strCache><c:ptCount val=\"7\"/>" +
                model.chart.labels.mapIndexed { i, l -> "<c:pt idx=\"$i\"><c:v>$l</c:v></c:pt>" }.joinToString("") +
                "</c:strCache></c:strRef></c:cat><c:val><c:numRef><c:f>Summary!\$B\$23:\$B\$29</c:f><c:numCache>" +
                "<c:formatCode>General</c:formatCode><c:ptCount val=\"7\"/>" +
                model.chart.values.mapIndexed { i, v -> "<c:pt idx=\"$i\"><c:v>$v</c:v></c:pt>" }.joinToString("") +
                "</c:numCache></c:numRef></c:val></c:ser></c:barChart></c:plotArea></c:chart></c:chartSpace>",
        )
    }

    private fun sheet(sheet: Sheet): String {
        val main = sheet === model.main
        val last = sheet.lastRow
        val b = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<worksheet xmlns=\"$NS_MAIN\" xmlns:r=\"$NS_REL\">")
        if (main) b.append("<sheetPr><outlinePr summaryBelow=\"0\" summaryRight=\"1\"/></sheetPr>")
        b.append("<dimension ref=\"A1:${columnName(sheet.widths.size)}$last\"/>")
        b.append("<sheetViews><sheetView${if (sheet === model.summary) " tabSelected=\"1\"" else ""} workbookViewId=\"0\">")
        if (sheet.frozenColumns > 0) b.append("<pane xSplit=\"3\" ySplit=\"1\" topLeftCell=\"D2\" activePane=\"bottomRight\" state=\"frozen\"/>")
        if (sheet.frozenColumns == 0 && sheet.frozenRows > 0)
            b.append("<pane ySplit=\"${sheet.frozenRows}\" topLeftCell=\"A${sheet.frozenRows + 1}\" activePane=\"bottomLeft\" state=\"frozen\"/>")
        b.append("</sheetView></sheetViews><sheetFormatPr defaultRowHeight=\"13.2\"${if (main) " outlineLevelRow=\"2\"" else ""}/><cols>")
        sheet.widths.forEachIndexed { i, w -> b.append("<col min=\"${i + 1}\" max=\"${i + 1}\" width=\"$w\" customWidth=\"1\"/>") }
        b.append("</cols><sheetData>")
        for (row in sheet.rows()) {
            b.append("<row r=\"${row.number}\"")
            if (row.level > 0) b.append(" hidden=\"1\" outlineLevel=\"${row.level}\"")
            if (row.collapsed) b.append(" collapsed=\"1\"")
            row.height?.let { b.append(" ht=\"$it\" customHeight=\"1\"") }
            b.append(">")
            for (c in row.cells) {
                val ref = columnName(c.column) + row.number
                b.append(when {
                    c.formula != null -> "<c r=\"$ref\" s=\"${c.style}\"><f>${xmlEscape(c.formula)}</f><v>${c.number}</v></c>"
                    c.number != null -> "<c r=\"$ref\" s=\"${c.style}\"><v>${c.number}</v></c>"
                    c.text != null -> "<c r=\"$ref\" s=\"${c.style}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">" +
                        xmlEscape(ooxmlLiteral(c.text)) + "</t></is></c>"
                    else -> "<c r=\"$ref\" s=\"${c.style}\"/>"
                })
            }
            b.append("</row>")
        }
        b.append("</sheetData>")
        if (sheet === model.bookings) b.append("<autoFilter ref=\"${WorkbookLayout.bookingsFilterRef(last)}\"/>")
        if (sheet === model.companyEvidence || sheet === model.matrix)
            b.append("<autoFilter ref=\"A1:${columnName(sheet.widths.size)}$last\"/>")
        if (main) {
            b.append("<conditionalFormatting sqref=\"A2:P$last\"><cfRule type=\"expression\" dxfId=\"0\" priority=\"1\">")
            b.append("<formula>${xmlEscape(WorkbookLayout.recordedStatusFormula())}</formula></cfRule></conditionalFormatting>")
            b.append("<conditionalFormatting sqref=\"G2:G$last\"><cfRule type=\"dataBar\" priority=\"2\"><dataBar minLength=\"0\" maxLength=\"100\">")
            b.append("<cfvo type=\"num\" val=\"0\"/><cfvo type=\"num\" val=\"100\"/><color rgb=\"FF9BC2E6\"/></dataBar></cfRule></conditionalFormatting>")
            b.append("<dataValidations count=\"2\"><dataValidation type=\"list\" allowBlank=\"1\" showInputMessage=\"1\" showErrorMessage=\"1\"")
            b.append(" errorTitle=\"Reviewer decision\" error=\"${xmlEscape(WorksheetXml.DECISION_ERROR)}\"")
            b.append(" promptTitle=\"Reviewer decision\" prompt=\"${xmlEscape(WorksheetXml.decisionPrompt(model.decisionOptions))}\"")
            b.append(" sqref=\"M2 M4 M6\"><formula1>${xmlEscape(WorkbookLayout.decisionListFormula(model.decisionOptions))}</formula1></dataValidation>")
            b.append("<dataValidation type=\"date\" operator=\"between\" allowBlank=\"1\" showErrorMessage=\"1\" errorTitle=\"Review date\"")
            b.append(" error=\"${xmlEscape(WorksheetXml.DATE_ERROR)}\" sqref=\"P2 P4 P6\">")
            b.append("<formula1>1</formula1><formula2>2958465</formula2></dataValidation></dataValidations>")
            if (model.jumps.isNotEmpty()) {
                b.append("<hyperlinks>")
                model.jumps.forEach { b.append("<hyperlink ref=\"${it.cellRef}\" location=\"${it.name}\" tooltip=\"${WorksheetXml.JUMP_TOOLTIP}\"/>") }
                b.append("</hyperlinks>")
            }
        }
        b.append("<pageMargins left=\"0.4\" right=\"0.4\" top=\"0.5\" bottom=\"0.5\" header=\"0.3\" footer=\"0.3\"/>")
        if (main) b.append("<ignoredErrors><ignoredError sqref=\"${WorkbookLayout.mainIdRanges(last)}\" numberStoredAsText=\"1\"/></ignoredErrors>")
        if (sheet === model.bookings && last >= 2) {
            b.append("<ignoredErrors><ignoredError sqref=\"${WorkbookLayout.bookingIdRanges(last)}\" numberStoredAsText=\"1\"/></ignoredErrors>")
        }
        if (sheet === model.summary) b.append("<drawing r:id=\"rId1\"/>")
        return b.append("</worksheet>").toString()
    }

    private fun booking(entity: String, record: String, parent: String?) = Booking(
        csv("entity_id" to entity, "booking_record_id" to record),
        parent?.let { csv("ultimate_parent_id" to it) }, PlatformNames("", "", ""))

    private fun csv(vararg pairs: Pair<String, String>): CsvRow =
        CsvRow(pairs.mapIndexed { i, p -> p.first to i }.toMap(), pairs.map { it.second }.toTypedArray())
}
