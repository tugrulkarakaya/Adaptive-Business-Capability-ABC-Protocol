package com.db.clientinsights.export.workbook

import com.db.clientinsights.export.TEST_PRODUCER
import com.db.clientinsights.export.adapters.serialization.EvidenceJson
import java.nio.file.Files
import java.nio.file.Path
import kotlinx.serialization.json.*
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.io.TempDir

class ConfluenceEvidenceWorkbookTest {
    @TempDir lateinit var temporary: Path

    @Test fun `standard workbook shows known contact count separately from unknown names and three independent matrix checks`() {
        val directory = WorkbookFixtures.corpusCollection(temporary.resolve("exports"), 14)
        val edit = EditableCollection(directory)
        val contacts = edit.read(0, "active-contact-review.csv")
        val entity = contacts[0, "entity_id"]
        contacts[0, "active_contact_count"] = "7"
        contacts[0, "status"] = "COMPLETE"
        contacts[0, "limitations"] = "ACTIVE_CONTACT_CUSTOMER_PLATFORM_NAMES_NOT_VALIDATED_OR_INCOMPLETE"
        edit.write(0, "active-contact-review.csv", contacts)
        val template = edit.read(0, "theme-b6-booking-assessments.csv")
        val exportedBookings = edit.read(0, "booking-records.csv")
        val bookingIndex = exportedBookings.rows.indices.first { exportedBookings[it, "entity_id"] == entity }
        val record = exportedBookings[bookingIndex, "booking_record_id"]
        val code = exportedBookings[bookingIndex, "booking_code"]
        val crdsSystem = exportedBookings[bookingIndex, "crds_system_id"]
        val method = exportedBookings[bookingIndex, "settlement_method_id"]
        val matrixRows = listOf(
            mapOf("category" to "INACTIVE_CRDS_LEGAL_ENTITY", "result" to "NO_SIGNAL"),
            mapOf("category" to "INACTIVE_CRDS_BOOKING_CODE", "result" to "NOT_DETERMINED", "if_no_recent_trading" to "HIGH", "if_recent_trading" to "MEDIUM"),
            mapOf("category" to "ROUTINGS_AND_TRADING", "result" to "NOT_DETERMINED")
        ).map { fields -> template.header.map { column ->
            fields[column] ?: mapOf("entity_id" to entity, "booking_record_id" to record, "booking_code" to code,
                "crds_system_id" to crdsSystem, "settlement_method_id" to method, "path_evidence_id" to "synthetic-path", "source_status" to "COMPLETE",
                "missing_inputs" to "RECENT_TRADING", "explanation" to "Evidence only; human review.")[column].orEmpty()
        }.toMutableList() }.toMutableList()
        edit.write(0, "theme-b6-booking-assessments.csv", CsvFile(template.header, matrixRows))
        edit.rehash()

        val result = ReviewWorkbookService.generate(WorkbookOptions(directory, temporary.resolve("review.xlsx"), null, null,
            emptyList(), WorkbookLayout.DRAFT_DECISION_OPTIONS), TEST_PRODUCER)

        val workbook = WorkbookInspector(result.workbook)
        assertEquals(listOf("Summary", "Company review", "Bookings", "Rules and assumptions", "Company evidence", "Matrix review"), workbook.sheetNames)
        val company = workbook.sheet(5).rows.single { it.value("A") == entity }
        assertEquals("7", company.value("C"))
        assertEquals("COMPLETE", company.value("D"))
        assertEquals("NOT_CONFIGURED", company.value("F"))
        val matrix = workbook.sheet(6)
        assertEquals(2, matrix.rows.size)
        val row = matrix.rows.last()
        assertEquals(code, row.value("C"))
        assertEquals(crdsSystem.ifEmpty { "Unknown / not supplied" }, row.value("D"))
        assertTrue(row.value("L")!!.contains("No concern under this category"))
        assertTrue(row.value("M")!!.contains("Unknown"))
        assertTrue(row.value("M")!!.contains("IF no recent trading: HIGH"))
        assertFalse(row.value("M")!!.contains("actual level: HIGH"))
        assertTrue(row.value("N")!!.contains("Unknown"))
        assertTrue(row.value("S")!!.contains("no overall score or automatic action"))
        assertTrue(matrix.all("autoFilter").isNotEmpty())
        assertEquals(emptyList<String>(), matrix.formulaCells)
    }

    @Test fun `new evidence CSVs are integrity checked before workbook use`() {
        val directory = WorkbookFixtures.corpusCollection(temporary.resolve("exports"), 14)
        val batch = EditableCollection(directory).batchFolders().single()
        Files.writeString(batch.resolve("active-contact-review.csv"), "tampered")

        val failure = assertThrows(WorkbookCheckFailure::class.java) { WorkbookInput.read(directory) }
        assertTrue(failure.message!!.contains("active-contact-review.csv"))
    }

    @Test fun `schema 1 point 3 without new CSVs stays readable and displays missing new evidence explicitly`() {
        val directory = WorkbookFixtures.corpusCollection(temporary.resolve("exports"), 14)
        val batch = EditableCollection(directory).batchFolders().single()
        val manifestPath = batch.resolve("run-manifest.json")
        val manifest = EvidenceJson.format.parseToJsonElement(Files.readString(manifestPath)).jsonObject
        val old = JsonObject(manifest.toMutableMap().apply {
            put("schemaVersion", JsonPrimitive("1.3.0"))
            put("artifacts", JsonArray(manifest.getValue("artifacts").jsonArray.filter {
                it.jsonObject.getValue("filename").jsonPrimitive.content !in CollectionData.OPTIONAL_FILES
            }))
        })
        Files.writeString(manifestPath, EvidenceJson.format.encodeToString(JsonObject.serializer(), old))
        CollectionData.OPTIONAL_FILES.forEach { Files.delete(batch.resolve(it)) }

        val result = ReviewWorkbookService.generate(WorkbookOptions(batch, temporary.resolve("old-review.xlsx"), null, null,
            emptyList(), WorkbookLayout.DRAFT_DECISION_OPTIONS), TEST_PRODUCER)

        val workbook = WorkbookInspector(result.workbook)
        assertEquals(6, workbook.sheetNames.size)
        assertTrue(workbook.sheet(5).rows.drop(1).all { it.value("D") == "Unknown / not supplied" })
        assertEquals(1, workbook.sheet(6).rows.size)
    }
}
