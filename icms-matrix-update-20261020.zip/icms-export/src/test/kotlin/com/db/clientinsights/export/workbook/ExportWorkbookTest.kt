package com.db.clientinsights.export.workbook

import com.db.clientinsights.export.RuleCorpus
import com.db.clientinsights.export.adapters.fixture.FixtureSources
import com.db.clientinsights.export.cli.CliOptions
import com.db.clientinsights.export.cli.CliSources
import com.db.clientinsights.export.cli.ExportWorkbookBuilder
import com.db.clientinsights.export.cli.exitCodeOf
import com.db.clientinsights.export.cli.exportCollection
import com.db.clientinsights.export.cli.runCli
import com.db.clientinsights.export.ports.ReviewCohortSource
import java.io.ByteArrayOutputStream
import java.io.PrintStream
import java.nio.file.Files
import java.nio.file.Path
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.io.TempDir

/**
 * A normal export builds the review workbook before it publishes collection-manifest.json. If the workbook fails,
 * the batches stay, no manifest is published and the run exits 3. Exports with nothing to review are not affected.
 */
class ExportWorkbookTest {
    @TempDir lateinit var temporary: Path
    private val out = ByteArrayOutputStream()
    private val err = ByteArrayOutputStream()
    private val output: Path get() = temporary.resolve("runs")

    @AfterEach fun clearInterrupt() { Thread.interrupted() }

    @Test fun `a normal demo export writes the workbook and receipt next to the published manifest`() {
        val code = runCli(arrayOf("--demo", "--ids=101,102,103,404", "--output=$output"), PrintStream(out), PrintStream(err))
        assertEquals(0, code, console())
        val folder = collectionFolder()
        assertTrue(Files.isRegularFile(folder.resolve("collection-manifest.json")))
        assertFalse(Files.exists(folder.resolve(".collection-manifest.pending.json")))
        val workbook = folder.resolve(WorkbookTarget.WORKBOOK_NAME)
        val receipt = readJson(folder.resolve(WorkbookTarget.RECEIPT_NAME))
        assertEquals("icms-review-workbook/5", receipt["workbookFormat"]!!.jsonPrimitive.content)
        assertEquals("export-run", receipt["inputKind"]!!.jsonPrimitive.content)
        assertEquals(ReviewWorkbookService.fileSha256(workbook), receipt["workbookSha256"]!!.jsonPrimitive.content)
        assertEquals(com.db.clientinsights.export.adapters.serialization.sha256(
            Files.readAllBytes(folder.resolve("collection-manifest.json"))),
            receipt["manifestSha256"]!!.jsonPrimitive.content)
        val lines = out.toString().lines().filter { it.isNotBlank() }
        val line = "Review workbook: ${workbook.toRealPath()}"
        assertEquals(line, lines.last(), "the workbook path is the one prominent last line")
        assertEquals(1, lines.count { it.startsWith("Review workbook:") })
        assertEquals(6, WorkbookInspector(workbook).sheetNames.size)
    }

    @Test fun `a partial rule corpus export still gets its workbook and keeps exit two`() {
        val sources = CliSources(RuleCorpus.icms, ReviewCohortSource { _, _ -> error("explicit") }, RuleCorpus.references,
            RuleCorpus.review)
        val options = CliOptions.parse(arrayOf("--demo", "--ids=${RuleCorpus.requestedIds.joinToString(",")}",
            "--export-batch-size=5", "--output=$output"))
        val code = exitCodeOf(PrintStream(err)) { exportCollection(options, sources, PrintStream(out)) }
        assertEquals(2, code, console())
        val folder = collectionFolder()
        assertTrue(Files.isRegularFile(folder.resolve("collection-manifest.json")))
        assertTrue(Files.isRegularFile(folder.resolve(WorkbookTarget.WORKBOOK_NAME)))
        val receipt = readJson(folder.resolve(WorkbookTarget.RECEIPT_NAME))
        assertEquals(3, receipt["batches"]!!.jsonPrimitive.content.toInt())
    }

    @Test fun `a failing workbook keeps the batches, publishes no manifest and exits three`() {
        val failing = ExportWorkbookBuilder { _, _, _, _ ->
            throw WorkbookCheckFailure("Company review C2 text has 40000 UTF-16 units")
        }
        val code = export(failing)
        assertEquals(3, code, console())
        assertTrue(err.toString().contains("Batches were saved in ${collectionFolder().toAbsolutePath()}"), console())
        assertTrue(err.toString().contains("Company review C2 text has 40000 UTF-16 units"), console())
        assertTrue(err.toString().contains("The collection manifest was NOT published."), console())
        assertUnpublished()
        assertEquals(1, batchCount())
    }

    @Test fun `an unexpected workbook failure exits three without its text`() {
        val code = export { _, _, _, _ -> throw IllegalStateException("SYNTHETIC-CLIENT-NAME") }
        assertEquals(3, code, console())
        assertFalse(console().contains("SYNTHETIC-CLIENT-NAME"), console())
        assertTrue(err.toString().contains("IllegalStateException"), console())
        assertUnpublished()
    }

    @Test fun `an existing workbook name in the collection folder is never replaced`() {
        // The console hook places a file under the workbook's name once the first batch is saved.
        val hook = object : PrintStream(out, true) {
            override fun println(x: String?) {
                super.println(x)
                if (x?.startsWith("Batch 1 saved") == true) {
                    Files.writeString(collectionFolder().resolve(WorkbookTarget.WORKBOOK_NAME), "pre-existing")
                }
            }
        }
        val options = CliOptions.parse(arrayOf("--demo", "--ids=101", "--output=$output"))
        val fixture = FixtureSources.demo()
        val code = exitCodeOf(PrintStream(err)) {
            exportCollection(options, CliSources(fixture, fixture, fixture, fixture.reviewSource), hook)
        }
        assertEquals(3, code, console())
        assertTrue(err.toString().contains("already exists (nothing was replaced)"), console())
        assertEquals("pre-existing", Files.readString(collectionFolder().resolve(WorkbookTarget.WORKBOOK_NAME)))
        assertFalse(Files.exists(collectionFolder().resolve(WorkbookTarget.RECEIPT_NAME)))
        assertFalse(Files.exists(collectionFolder().resolve("collection-manifest.json")))
        assertFalse(Files.exists(collectionFolder().resolve(".collection-manifest.pending.json")))
    }

    @Test fun `an interruption while the workbook is built publishes nothing and exits one hundred thirty`() {
        val code = export { _, _, _, _ -> throw InterruptedException() }
        assertTrue(Thread.interrupted(), "The interrupt flag must be preserved")
        assertEquals(130, code, console())
        assertUnpublished()
    }

    @Test fun `an interruption after the workbook removes it and the receipt and publishes no manifest`() {
        val code = export { folder, _, _, _ ->
            val workbook = Files.writeString(folder.resolve(WorkbookTarget.WORKBOOK_NAME), "synthetic")
            val receipt = Files.writeString(folder.resolve(WorkbookTarget.RECEIPT_NAME), "{}")
            Thread.currentThread().interrupt()
            WorkbookResult(workbook, receipt, 1, 0, 0, "0".repeat(64))
        }
        assertTrue(Thread.interrupted(), "The interrupt flag must be preserved")
        assertEquals(130, code, console())
        assertUnpublished()
    }

    @Test fun `an export without review data keeps its outcome and says it has no workbook`() {
        val fixture = FixtureSources.demo()
        val options = CliOptions.parse(arrayOf("--demo", "--ids=101", "--output=$output"))
        val builder = ExportWorkbookBuilder { _, _, _, _ -> error("must not be called") }
        val code = exitCodeOf(PrintStream(err)) {
            exportCollection(options, CliSources(fixture, fixture, fixture, review = null), PrintStream(out), builder)
        }
        assertEquals(0, code, console())
        assertTrue(out.toString().contains("No review workbook: this export has no review data."), console())
        assertTrue(Files.isRegularFile(collectionFolder().resolve("collection-manifest.json")))
        assertFalse(Files.exists(collectionFolder().resolve(WorkbookTarget.WORKBOOK_NAME)))
    }

    @Test fun `an export that selected no companies publishes its manifest as before and exits two`() {
        val config = Files.writeString(temporary.resolve("empty.properties"), "")
        val code = runCli(arrayOf("--config=$config", "--all-flagged", "--output=$output"), PrintStream(out), PrintStream(err))
        assertEquals(2, code, console())
        assertTrue(out.toString().contains("No review workbook: the export selected no companies."), console())
        val manifest = readJson(collectionFolder().resolve("collection-manifest.json"))
        assertEquals(0, manifest["batches"]!!.jsonArray.size)
        assertFalse(Files.exists(collectionFolder().resolve(WorkbookTarget.WORKBOOK_NAME)))
    }

    @Test fun `the staged manifest is published byte for byte`() {
        var stagedBytes = ByteArray(0)
        val code = export { folder, staged, _, _ ->
            assertEquals(folder.resolve(".collection-manifest.pending.json"), staged)
            assertFalse(Files.exists(folder.resolve("collection-manifest.json")))
            stagedBytes = Files.readAllBytes(staged)
            val workbook = Files.writeString(folder.resolve(WorkbookTarget.WORKBOOK_NAME), "synthetic")
            val receipt = Files.writeString(folder.resolve(WorkbookTarget.RECEIPT_NAME), "{}")
            WorkbookResult(workbook, receipt, 1, 0, 0, "0".repeat(64))
        }
        assertEquals(0, code, console())
        assertTrue(stagedBytes.contentEquals(Files.readAllBytes(collectionFolder().resolve("collection-manifest.json"))))
        val manifest = readJson(collectionFolder().resolve("collection-manifest.json"))
        assertEquals("101", manifest["requestedEntityIds"]!!.jsonArray.single().jsonPrimitive.content)
        assertTrue(manifest["batches"]!!.jsonArray.single().jsonObject.isNotEmpty())
    }

    /** Exports demo entity 101 with the given workbook builder. */
    private fun export(builder: ExportWorkbookBuilder): Int {
        val fixture = FixtureSources.demo()
        val options = CliOptions.parse(arrayOf("--demo", "--ids=101", "--output=$output"))
        return exitCodeOf(PrintStream(err)) {
            exportCollection(options, CliSources(fixture, fixture, fixture, fixture.reviewSource), PrintStream(out), builder)
        }
    }

    private fun assertUnpublished() {
        val folder = collectionFolder()
        assertFalse(Files.exists(folder.resolve("collection-manifest.json")), console())
        assertFalse(Files.exists(folder.resolve(".collection-manifest.pending.json")), console())
        assertFalse(Files.exists(folder.resolve(WorkbookTarget.WORKBOOK_NAME)), console())
        assertFalse(Files.exists(folder.resolve(WorkbookTarget.RECEIPT_NAME)), console())
        assertTrue(batchCount() > 0, "batches are kept")
    }

    private fun batchCount(): Int = Files.walk(collectionFolder().resolve("batches")).use { files ->
        files.filter { it.fileName.toString() == "run-manifest.json" }.count().toInt()
    }

    private fun collectionFolder(): Path = Files.list(output).use { it.findFirst().orElseThrow() }

    private fun console() = "$out$err"
}
