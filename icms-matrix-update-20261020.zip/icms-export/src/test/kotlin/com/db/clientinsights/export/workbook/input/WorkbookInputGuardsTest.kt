package com.db.clientinsights.export.workbook.input

import com.db.clientinsights.export.RuleCorpus
import com.db.clientinsights.export.TEST_CLOCK
import com.db.clientinsights.export.TEST_PRODUCER
import com.db.clientinsights.export.adapters.bundle.ExportCollectionWriter
import com.db.clientinsights.export.adapters.serialization.sha256
import com.db.clientinsights.export.application.CohortExportService
import com.db.clientinsights.export.application.ExportService
import com.db.clientinsights.export.domain.ExportRequest
import com.db.clientinsights.export.entityId
import com.db.clientinsights.export.ports.ReviewCohortSource
import com.db.clientinsights.export.workbook.CollectionData
import com.db.clientinsights.export.workbook.ReviewJoin
import com.db.clientinsights.export.workbook.WorkbookCheckFailure
import com.db.clientinsights.export.workbook.WorkbookInput
import com.db.clientinsights.export.workbook.WorkbookLayout
import java.nio.file.Files
import java.nio.file.Path
import kotlin.io.path.name
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Assumptions.assumeTrue
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import org.junit.jupiter.api.io.TempDir

/**
 * Integrity guards of WorkbookInput on synthetic rule-corpus exports written by the application itself: single-run
 * provenance, the early Bookings capacity check, manifest symlink consistency and required CSV dataRows.
 */
class WorkbookInputGuardsTest {
    @TempDir lateinit var temp: Path

    /** Exports the 14-company rule corpus as one collection in batches of batchSize; returns the collection folder. */
    private fun exportCorpus(batchSize: Int): Path {
        val runId = "corpus-batch-$batchSize"
        val writer = ExportCollectionWriter(temp.resolve("out-" + System.nanoTime()), runId)
        val service = ExportService(RuleCorpus.icms, RuleCorpus.references, TEST_PRODUCER, clock = TEST_CLOCK,
            reviewSource = RuleCorpus.review)
        val collection = CohortExportService(ReviewCohortSource { _, _ -> error("explicit IDs only") }, service,
            TEST_PRODUCER, clock = TEST_CLOCK)
            .exportSelected(runId, ExportRequest(RuleCorpus.requestedIds.map(::entityId)), batchSize, writer, 2)
        writer.finish(collection)
        return writer.directory
    }

    private fun batches(collection: Path): List<Path> =
        Files.list(collection.resolve("batches")).use { s -> s.toList().sortedBy { it.name } }

    private fun failure(input: Path): String =
        assertThrows<WorkbookCheckFailure> { ReviewJoin.join(WorkbookInput.read(input)) }.message.orEmpty()

    /** Rewrites a manifest JSON file through `edit`. */
    private fun editJson(file: Path, edit: (JsonObject) -> JsonObject) {
        Files.writeString(file, edit(Json.parseToJsonElement(Files.readString(file)).jsonObject).toString())
    }

    private fun JsonObject.with(key: String, value: JsonElement?): JsonObject =
        JsonObject(if (value == null) this - key else this + (key to value))

    /** Applies `edit` to the run-manifest artifact entry of `file`. */
    private fun editArtifact(runManifest: Path, file: String, edit: (JsonObject) -> JsonObject) = editJson(runManifest) {
        val artifacts = (it["artifacts"] as JsonArray).map { a ->
            val entry = a.jsonObject
            if (entry["filename"]?.jsonPrimitive?.content == file) edit(entry) else entry
        }
        it.with("artifacts", JsonArray(artifacts))
    }

    private fun symlinksSupported(): Boolean = try {
        Files.createSymbolicLink(temp.resolve("probe-" + System.nanoTime()), temp)
        true
    } catch (_: Exception) {
        false
    }

    @Test fun `collection and single-run inputs join the whole corpus`() {
        val collection = exportCorpus(5)
        val data = ReviewJoin.join(WorkbookInput.read(collection))
        assertEquals(14, data.companies.size)
        assertEquals(31, data.bookingCount)
        val single = ReviewJoin.join(WorkbookInput.read(batches(exportCorpus(14)).single()))
        assertEquals(14, single.companies.size)
        assertEquals(31, single.bookingCount)
    }

    @Test fun `single-run provenance lists each consumed file once`() {
        val batch = batches(exportCorpus(14)).single()
        val c = WorkbookInput.read(batch.resolve("run-manifest.json"))
        assertEquals(CollectionData.KIND_SINGLE_RUN, WorkbookInput.inputKind(c))
        val keys = c.consumedHashes().keys
        assertTrue("run-manifest.json" in keys)
        assertFalse("collection-manifest.json" in keys)
        assertFalse("B1/run-manifest.json" in keys)
        assertEquals(1, keys.count { it.endsWith("run-manifest.json") })
        assertEquals((CollectionData.CONSUMED_FILES + CollectionData.OPTIONAL_FILES).map { "B1/$it" }.toSet(), keys - "run-manifest.json")
        assertEquals(c.consumedFileCount, keys.size)
        assertEquals(1 + (CollectionData.CONSUMED_FILES.size + CollectionData.OPTIONAL_FILES.size), c.consumedFileCount)
    }

    @Test fun `declared booking count over capacity fails before any CSV is opened`() {
        val collection = exportCorpus(5)
        editJson(collection.resolve("collection-manifest.json")) {
            it.with("exportedBookingCount", JsonPrimitive(WorkbookLayout.MAX_SHEET_ROWS))
        }
        Files.delete(batches(collection).first().resolve("booking-records.csv"))
        assertTrue("exportedBookingCount" in failure(collection))

        val batch = batches(exportCorpus(14)).single()
        editJson(batch.resolve("run-manifest.json")) {
            it.with("exportedBookingCount", JsonPrimitive(WorkbookLayout.MAX_SHEET_ROWS))
        }
        Files.writeString(batch.resolve("entities.csv"), "corrupt")
        assertTrue("exportedBookingCount" in failure(batch))
    }

    @Test fun `negative declared booking count fails`() {
        val collection = exportCorpus(5)
        editJson(collection.resolve("collection-manifest.json")) { it.with("exportedBookingCount", JsonPrimitive(-1)) }
        assertTrue("exportedBookingCount" in failure(collection))
    }

    @Test fun `largest declared booking count passes the capacity check and is reconciled later`() {
        val collection = exportCorpus(5)
        editJson(collection.resolve("collection-manifest.json")) {
            it.with("exportedBookingCount", JsonPrimitive(WorkbookLayout.MAX_SHEET_ROWS - 1))
        }
        val c = WorkbookInput.read(collection)
        val message = assertThrows<WorkbookCheckFailure> { ReviewJoin.join(c) }.message.orEmpty()
        assertTrue("exported booking count" in message, message)
    }

    @Test fun `manifest symlink to another name or another folder fails`() {
        assumeTrue(symlinksSupported(), "symbolic links are not supported here")
        val collection = exportCorpus(5)
        val manifest = collection.resolve("collection-manifest.json")

        // Same folder, different real name.
        val other = collection.resolve("manifest-copy.json")
        Files.move(manifest, other)
        Files.createSymbolicLink(manifest, other)
        assertTrue("another name" in failure(manifest))
        assertTrue("another name" in failure(collection))

        // Same name, different folder: a link in a fresh folder pointing at a real collection manifest.
        val real = exportCorpus(5).resolve("collection-manifest.json")
        val elsewhere = Files.createDirectory(temp.resolve("elsewhere"))
        val link = Files.createSymbolicLink(elsewhere.resolve("collection-manifest.json"), real)
        assertTrue("outside its folder" in failure(link))
    }

    @Test fun `staged manifest name is not accepted as input`() {
        val collection = exportCorpus(5)
        val pending = collection.resolve(".collection-manifest.pending.json")
        Files.move(collection.resolve("collection-manifest.json"), pending)
        assertTrue("not read" in failure(pending))
        assertEquals(14, ReviewJoin.join(WorkbookInput.readCollection(collection, pending)).companies.size)
    }

    @Test fun `missing, null, negative or non-integer dataRows fails naming the file`() {
        val cases = listOf<JsonElement?>(null, JsonNull, JsonPrimitive(-1), JsonPrimitive("many"), JsonPrimitive(1.5))
        for (value in cases) {
            val batch = batches(exportCorpus(14)).single()
            editArtifact(batch.resolve("run-manifest.json"), "data-issues.csv") { it.with("dataRows", value) }
            val message = failure(batch)
            assertTrue("data-issues.csv" in message && "dataRows" in message, message)
        }
    }

    @Test fun `zero dataRows is valid`() {
        val batch = batches(exportCorpus(14)).single()
        val file = batch.resolve("parent-relationships.csv")
        val headerOnly = Files.readString(file).substringBefore("\r\n") + "\r\n"
        Files.writeString(file, headerOnly)
        val bytes = Files.readAllBytes(file)
        editArtifact(batch.resolve("run-manifest.json"), "parent-relationships.csv") {
            it.with("dataRows", JsonPrimitive(0)).with("bytes", JsonPrimitive(bytes.size))
                .with("sha256", JsonPrimitive(sha256(bytes)))
        }
        val c = WorkbookInput.read(batch)
        assertEquals(0, c.batches.single().tables.getValue("parent-relationships.csv").rows.size)
    }

    @Test fun `expected-ids accepts the export's own ids file`() {
        val file = temp.resolve("cohort.csv")
        Files.writeString(file, "\uFEFFentity_id\r\n0601\r\n\"602\"\r\n\r\n603 # note\r\n")
        assertEquals(listOf("601", "602", "603"), WorkbookInput.readIdList(file))
        Files.writeString(file, "601, 602\n601\n")
        assertEquals(listOf("601", "602", "601"), WorkbookInput.readIdList(file))
    }
}
