package com.db.clientinsights.export

import com.db.clientinsights.export.adapters.bundle.EvidenceBundleWriter
import com.db.clientinsights.export.adapters.fixture.FixtureData
import com.db.clientinsights.export.adapters.fixture.FixtureSources
import com.db.clientinsights.export.adapters.icms.*
import com.db.clientinsights.export.adapters.serialization.EvidenceJson
import com.db.clientinsights.export.adapters.serialization.sha256
import com.db.clientinsights.export.application.ExportService
import com.db.clientinsights.export.domain.*
import java.nio.file.Files
import java.nio.file.Path
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.io.TempDir

class PlatformNamesTest {
    @TempDir lateinit var temporary: Path

    @Test fun `native ID verification preserves export IDs and separates key-only and conflicting links`() {
        TestDatabase().use { db ->
            seed(db)
            val review = checkNotNull(export(db).review)
            val assessments = review.platformNames.assessments.groupBy { it.bookingRecordId }
            assertEquals(PlatformLinkStatus.VERIFIED_BOOKING_ID, assessments["1"]!!.first().linkStatus,
                assessments["1"].toString() + review.facts.queries.filter { it.dataset == "PLATFORM_NATIVE_BOOKINGS" })
            assertEquals(PlatformLinkStatus.BOOKING_KEY_ONLY, assessments["2"]!!.single().linkStatus)
            assertEquals("NATIVE_REFERENCE_NOT_FOUND", assessments["2"]!!.single().reason)
            assertEquals(PlatformLinkStatus.NATIVE_BOOKING_KEY_MISMATCH, assessments["3"]!!.single().linkStatus)
            assertEquals(PlatformLinkStatus.ACCOUNT_OWNER_MISMATCH, assessments["4"]!!.single().linkStatus)
            assertEquals(PlatformLinkStatus.ACCOUNT_OWNER_UNKNOWN, assessments["5"]!!.single().linkStatus)
            assertEquals("9001", review.facts.platformNames.first { it.data.bookingRecordId == "1" }.data.nativeBookingId)
            val coverage = review.platformNames.entities.single()
            assertEquals(1, coverage.verifiedNamedBookings)
            assertEquals(1, coverage.keyOnlyNamedBookings)
            assertEquals(3, coverage.conflictedNamedBookings)
            assertEquals(1, coverage.bookingsWithoutName)
            assertEquals("AVAILABLE", coverage.coverageStatus)
            assertTrue(review.bookings.all { it.unused.level == "NOT_DETERMINED" })
        }
    }

    @Test fun `failed native source preserves names as key-only and reports unavailable validation`() {
        TestDatabase().use { db ->
            seed(db)
            db.execute("DROP TABLE T_BOOKING_CODE")
            val bundle = export(db)
            assertEquals(FetchStatus.PARTIAL, bundle.extractionStatus)
            val names = checkNotNull(bundle.review).platformNames
            val result = names.assessments.first { it.bookingRecordId == "1" }
            assertEquals(PlatformLinkStatus.BOOKING_KEY_ONLY, result.linkStatus)
            assertEquals(FetchStatus.FAILED, result.nativeReadStatus)
            assertEquals("NATIVE_LOOKUP_INCOMPLETE", result.reason)
            assertEquals(0, names.entities.single().verifiedNamedBookings)
            assertTrue(result.hasName)
        }
    }

    @Test fun `failed platform source never claims no names`() {
        TestDatabase().use { db ->
            seed(db)
            db.execute("DROP TABLE T_ACCOUNT_CODE_ON_EP")
            val bundle = export(db)
            val coverage = checkNotNull(bundle.review).platformNames.entities.single()
            assertEquals(FetchStatus.FAILED, coverage.sourceStatus)
            assertEquals("UNAVAILABLE", coverage.coverageStatus)
            assertNull(coverage.bookingsWithoutName)
            assertEquals(FetchStatus.PARTIAL, bundle.extractionStatus)
        }
    }

    @Test fun `empty and blank names are not counted`() {
        TestDatabase().use { db ->
            seed(db)
            db.execute("UPDATE T_ACCOUNT_CODE_ON_EP SET name='  ', bbg_firm_name=NULL")
            val coverage = checkNotNull(export(db).review).platformNames.entities.single()
            assertEquals("NO_NAME", coverage.coverageStatus)
            assertEquals(0, coverage.namedPlatformRecordCount)
            assertEquals(6, coverage.bookingsWithoutName)
        }
    }

    @Test fun `missing native references need no lookup and remain key-only`() {
        TestDatabase().use { db ->
            seed(db)
            db.execute("UPDATE PRD_EXPORT_SETTLEMENT_ROUTING SET booking_code_id=NULL")
            val bundle = export(db)
            val review = checkNotNull(bundle.review)
            assertTrue(bundle.queries.filter { it.dataset == "PLATFORM_NATIVE_BOOKINGS" }
                .all { it.requestedKeys.isEmpty() && it.pagesRead == 0 && it.status == FetchStatus.COMPLETE })
            val result = review.platformNames.assessments.first { it.bookingRecordId == "1" }
            assertEquals(PlatformLinkStatus.BOOKING_KEY_ONLY, result.linkStatus)
            assertEquals("NATIVE_REFERENCE_MISSING", result.reason)
            assertNull(result.nativeReadStatus)
        }
    }

    @Test fun `incomplete core scope never claims complete platform absence`() {
        TestDatabase().use { db ->
            seed(db)
            val limited = JdbcQueryExecutor("limited-core", "", db.connections, QueryLimits(maxRows = 1))
            val full = JdbcQueryExecutor("full-platforms", "", db.connections)
            val bundle = ExportService(OracleIcmsSource(limited), OracleIcmsReferenceSource(full), TEST_PRODUCER,
                reviewSource = OracleReviewDataSource { full }).extract(ExportRequest(listOf(entityId("248"))))
            val coverage = checkNotNull(bundle.review).platformNames.entities.single()
            assertEquals(FetchStatus.COMPLETE, coverage.sourceStatus)
            assertEquals("PARTIAL", coverage.coverageStatus)
            assertNull(coverage.bookingsWithoutName)
            assertTrue(checkNotNull(bundle.review).platformNames.assessments.any { it.linkStatus == PlatformLinkStatus.EXPORTED_BOOKING_UNAVAILABLE })
        }
    }

    @Test fun `pagination and request status prevent leakage from inactive bookings or other companies`() {
        TestDatabase().use { db ->
            seed(db)
            seedBooking(db, 7, 300, "VERIFIED")
            db.execute("UPDATE PRD_EXPORT_BOOKING_CODE SET status='Inactive' WHERE id=2")
            val active = checkNotNull(export(db).review)
            assertFalse(active.facts.platformNames.any { it.data.bookingRecordId in setOf("2", "7") })
            assertTrue(active.platformNames.assessments.all { it.entityId == entityId("248") })
            assertTrue(active.facts.queries.filter { it.dataset == "BOOKING_PLATFORM_NAMES" }.all { it.pagesRead > 1 })
            val all = checkNotNull(export(db, null).review)
            assertTrue(all.facts.platformNames.any { it.data.bookingRecordId == "2" && it.data.bookingStatus == "Inactive" })
        }
    }

    @Test fun `CSV bundle preserves original names with separate confidence and reconciles provenance and hashes`() {
        TestDatabase().use { db ->
            seed(db)
            db.execute("UPDATE T_ACCOUNT_CODE_ON_EP SET name='=Untrusted, \"Platform\"' WHERE id=100")
            val bundle = export(db)
            val output = EvidenceBundleWriter().write(bundle, temporary)
            val csv = readCsv(output.resolve("booking-platform-names.csv"))
            assertEquals("'=Untrusted, \"Platform\"", csv.first { it["booking_record_id"] == "1" }["name_on_platform"])
            assertTrue(csv.any { it["link_status"] == "VERIFIED_BOOKING_ID" })
            assertTrue(csv.any { it["link_status"] == "BOOKING_KEY_ONLY" })
            assertTrue(csv.any { it["link_status"] == "NATIVE_BOOKING_KEY_MISMATCH" })
            val restored = EvidenceJson.format.decodeFromString<EvidenceBundle>(Files.readString(output.resolve("evidence.json")))
            assertEquals(bundle, restored)
            assertEquals("=Untrusted, \"Platform\"", checkNotNull(restored.review).facts.platformNames.first { it.data.platformRecordId == "100" }.data.name)
            val review = checkNotNull(bundle.review)
            val origins = review.facts.platformNames.map { it.origin } + review.facts.platformNativeBookings.map { it.origin }
            val runs = bundle.queries.associateBy { it.queryRunId }
            assertTrue(origins.all { it.queryRunId in runs })
            review.platformNames.assessments.forEach { assessment ->
                assertTrue(assessment.queryRunIds.all { it in runs })
                assertTrue(assessment.nativeEvidenceIds.all { id -> origins.any { it.evidenceId == id } })
            }
            val manifest = EvidenceJson.format.decodeFromString<RunManifest>(Files.readString(output.resolve("run-manifest.json")))
            assertEquals(33, manifest.artifacts.size)
            manifest.artifacts.forEach {
                assertEquals(it.sha256, sha256(Files.readAllBytes(output.resolve(it.filename))))
                it.dataRows?.let { count -> assertEquals(count, readCsv(output.resolve(it.filename)).size) }
            }
        }
    }

    @Test fun `row limits leave coverage partial and never turn omitted names into negatives`() {
        TestDatabase().use { db ->
            seed(db)
            val bundle = export(db, limits = QueryLimits(pageSize = 1, maxRows = 2))
            val coverage = checkNotNull(bundle.review).platformNames.entities.single()
            assertEquals(FetchStatus.PARTIAL, coverage.sourceStatus)
            assertEquals("PARTIAL", coverage.coverageStatus)
            assertNull(coverage.bookingsWithoutName)
            assertEquals(FetchStatus.PARTIAL, bundle.extractionStatus)
        }
    }

    @Test fun `offline fixtures scope and retag platform and native facts without leaking companies`() {
        TestDatabase().use { db ->
            seed(db)
            val original = export(db)
            val fixture = FixtureSources(FixtureData(entities = original.facts.entities.map { it.data },
                bookingRecords = original.facts.bookingRecords.map { it.data }, bookingSystems = original.facts.bookingSystems.map { it.data },
                settlementMethods = original.facts.settlementMethods.map { it.data }, review = checkNotNull(original.review).facts))
            val restored = ExportService(fixture, fixture, TEST_PRODUCER, reviewSource = fixture.reviewSource)
                .extract(ExportRequest(listOf(entityId("248"))))
            val review = checkNotNull(restored.review)
            assertEquals(original.review!!.platformNames.assessments.map { it.linkStatus }, review.platformNames.assessments.map { it.linkStatus })
            assertTrue(restored.queries.all { it.adapter == "fixture" })
            val other = ExportService(fixture, fixture, TEST_PRODUCER, reviewSource = fixture.reviewSource)
                .extract(ExportRequest(listOf(entityId("300"))))
            assertTrue(checkNotNull(other.review).facts.platformNames.isEmpty())
            assertTrue(checkNotNull(other.review).facts.platformNativeBookings.isEmpty())
        }
    }

    private fun export(db: TestDatabase, status: String? = "Active", limits: QueryLimits = QueryLimits(pageSize = 2)): EvidenceBundle {
        val executor = JdbcQueryExecutor("test", "", db.connections, limits, adapter = "h2-test")
        return ExportService(OracleIcmsSource(executor), OracleIcmsReferenceSource(executor), TEST_PRODUCER,
            clock = TEST_CLOCK, reviewSource = OracleReviewDataSource { executor }).extract(ExportRequest(listOf(entityId("248")), status))
    }

    private fun seed(db: TestDatabase) {
        installReviewSchema(db)
        db.execute("INSERT INTO PRD_EXPORT_LEGAL_ENTITY VALUES (248, 'Synthetic bank', 'Active'), (300, 'Other bank', 'Active')")
        listOf("VERIFIED", "KEY_ONLY", "CONFLICT", "FOREIGN", "UNKNOWN", "EMPTY").forEachIndexed { index, code ->
            seedBooking(db, index + 1, 248, code)
        }
        db.execute("""
            INSERT INTO PRD_EXPORT_ACCOUNT VALUES (50,248),(51,300),(52,NULL),(53,248);
            INSERT INTO T_EPLATFORM VALUES (1,'Autobahn');
            INSERT INTO T_ACCOUNT_CODE_ON_EP VALUES
              (100,50,1,'000123','New name','FIRM01','Firm name',TIMESTAMP '2025-01-01 00:00:00',NULL),
              (101,51,1,'000123','Other owner',NULL,NULL,NULL,NULL),
              (102,52,1,'000123','Unknown owner',NULL,NULL,NULL,NULL),
              (103,53,1,NULL,NULL,NULL,NULL,NULL,NULL);
            INSERT INTO T_BOOKING_CODE VALUES (9001,248,'VERIFIED',10,'Active'),(9003,300,'CONFLICT',20,'Inactive'),
              (9004,248,'FOREIGN',10,'Active'),(9005,248,'UNKNOWN',10,'Active'),(9006,248,'EMPTY',10,'Active');
            INSERT INTO PRD_EXPORT_SETTLEMENT_ROUTING (settlement_routing_id,le_id,booking_code,settlement_system_id,booking_code_id,account_id) VALUES
              (1,248,'VERIFIED',10,9001,50),(2,248,'KEY_ONLY',10,9999,50),(3,248,'CONFLICT',10,9003,50),
              (4,248,'FOREIGN',10,9004,51),(5,248,'UNKNOWN',10,9005,52),(6,248,'EMPTY',10,9006,53),
              (7,248,'VERIFIED',10,9001,50);
        """.trimIndent())
    }
}
