package com.db.clientinsights.export.workbook

import com.db.clientinsights.export.RuleCorpus
import com.db.clientinsights.export.adapters.serialization.sha256
import java.nio.file.Files
import java.nio.file.Path
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.junit.jupiter.api.Assertions.assertArrayEquals
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.io.TempDir

/**
 * End to end through the CLI: `icms-export workbook` on synthetic rule-corpus exports (3 batches, 1 batch, a single
 * run), the receipt, deterministic bytes, and the input conditions that must be shown (not hidden) or must stop the
 * build with exit 3. Workbook content is read back with the independent [WorkbookInspector].
 */
class WorkbookCommandTest {
    @TempDir lateinit var temporary: Path
    private lateinit var threeBatches: Path
    private lateinit var oneBatch: Path

    @BeforeEach fun export() {
        threeBatches = WorkbookFixtures.corpusCollection(temporary.resolve("exports"), 5)
        oneBatch = WorkbookFixtures.corpusCollection(temporary.resolve("exports"), 14)
    }

    @Test fun `collections, manifests and a single-run batch folder build verified workbooks with receipts`() {
        val singleRun = EditableCollection(oneBatch).batchFolders().single()
        val inputs = listOf(threeBatches to "collection", threeBatches.resolve("collection-manifest.json") to "collection",
            oneBatch to "collection", singleRun to "single-run", singleRun.resolve("run-manifest.json") to "single-run")
        inputs.forEachIndexed { index, (input, kind) ->
            val asFile = index % 2 == 0
            val output = temporary.resolve(if (asFile) "review-$index.xlsx" else "review-$index")
            val run = workbookCli(input, output, "--expected-count", "14")
            assertEquals(0, run.code, "$input\n${run.console}")
            val workbook = if (asFile) output else output.resolve(WorkbookTarget.WORKBOOK_NAME)
            val receiptFile = if (asFile) temporary.resolve("review-$index.receipt.json")
            else output.resolve(WorkbookTarget.RECEIPT_NAME)
            assertTrue(Files.isRegularFile(workbook) && Files.isRegularFile(receiptFile), run.console)
            if (!asFile) assertEquals(listOf(WorkbookTarget.WORKBOOK_NAME, WorkbookTarget.RECEIPT_NAME).sorted(), listTree(output))
            val receipt = readJson(receiptFile)
            assertEquals(RECEIPT_KEYS, receipt.keys.toList())
            assertEquals("icms-review-workbook/5", receipt["workbookFormat"]!!.jsonPrimitive.content)
            assertEquals(kind, receipt["inputKind"]!!.jsonPrimitive.content)
            assertEquals(workbook.fileName.toString(), receipt["workbookFile"]!!.jsonPrimitive.content)
            assertEquals(Files.size(workbook), receipt["workbookBytes"]!!.jsonPrimitive.content.toLong())
            val workbookSha = sha256(Files.readAllBytes(workbook))
            assertEquals(workbookSha, receipt["workbookSha256"]!!.jsonPrimitive.content)
            assertTrue(run.out.contains(workbookSha), run.out)
            assertFalse(run.console.contains("Alpha Holdings"), "the console never shows business values")
            val options = receipt["options"]!!.jsonObject
            assertEquals(14, options["expectedCount"]!!.jsonPrimitive.content.toInt())
            assertEquals(WorkbookLayout.DRAFT_DECISION_OPTIONS, options["decisionOptions"]!!.jsonArray.map { it.jsonPrimitive.content })
            val producer = receipt["producer"]!!.jsonObject
            assertTrue(producer["applicationVersion"]!!.jsonPrimitive.content.isNotBlank())
            val verification = receipt["verification"]!!.jsonObject
            assertEquals(WorkbookLayout.SHEETS, verification["sheets"]!!.jsonArray.map { it.jsonPrimitive.content })
            assertEquals(0, verification["mainParentTokens"]!!.jsonPrimitive.content.toInt())
            assertEquals(if (kind == "collection") "collection-manifest.json" else "run-manifest.json",
                receipt["manifestFile"]!!.jsonPrimitive.content)
            if (kind == "single-run") {
                val folder = if (Files.isRegularFile(input)) input.parent else input
                val hashes = receipt["consumedFileSha256"]!!.jsonObject.mapValues { it.value.jsonPrimitive.content }
                assertEquals(sha256(Files.readAllBytes(folder.resolve("run-manifest.json"))), hashes["run-manifest.json"])
                assertEquals(1 + (CollectionData.CONSUMED_FILES.size + CollectionData.OPTIONAL_FILES.size), hashes.size)
                assertEquals(hashes["run-manifest.json"], receipt["manifestSha256"]!!.jsonPrimitive.content)
            }
            if (kind == "collection") {
                val folder = if (Files.isRegularFile(input)) input.parent else input
                val manifest = Files.readAllBytes(folder.resolve("collection-manifest.json"))
                assertEquals(sha256(manifest), receipt["manifestSha256"]!!.jsonPrimitive.content)
                assertConsumedHashes(EditableCollection(folder),
                    receipt["consumedFileSha256"]!!.jsonObject.mapValues { it.value.jsonPrimitive.content })
            }
        }
    }

    @Test fun `the same export gives byte-identical workbooks`() {
        assertEquals(0, workbookCli(threeBatches, temporary.resolve("first.xlsx")).code)
        assertEquals(0, workbookCli(threeBatches.resolve("collection-manifest.json"), temporary.resolve("second.xlsx")).code)
        assertArrayEquals(Files.readAllBytes(temporary.resolve("first.xlsx")), Files.readAllBytes(temporary.resolve("second.xlsx")))
    }

    @Test fun `the written workbook preserves the review contract with additive evidence tabs`() {
        val output = temporary.resolve("review.xlsx")
        val ids = temporary.resolve("ids.txt")
        Files.writeString(ids, "﻿# synthetic cohort\n" + RuleCorpus.requestedIds.reversed().joinToString(",\n"))
        val run = workbookCli(threeBatches, output, "--expected-ids", ids.toString(), "--run-note", "Synthetic run note")
        assertEquals(0, run.code, run.console)
        WorkbookContract(WorkbookInspector(output), EditableCollection(threeBatches)).checkAll()
    }

    @Test fun `a blank current-parent total stays blank and is counted as unknown, not zero`() {
        val copy = WorkbookFixtures.copy(threeBatches, temporary.resolve("unknown"))
        val (batch, table, row) = copy.find("entity-review.csv") { t, r -> t[r, "current_parent_count"].isNotEmpty() }
        val company = table[row, "entity_id"]
        table[row, "current_parent_count"] = ""
        copy.write(batch, "entity-review.csv", table)
        copy.rehash()
        val output = temporary.resolve("review.xlsx")
        assertEquals(0, workbookCli(copy.dir, output).code)
        val inspector = WorkbookInspector(output)
        val clients = inspector.sheet(2).rows.filter { it.value("D") == WorkbookLayout.ROW_CLIENT }
        val client = clients.single { it.value("A") == company }
        assertTrue(client["E"]!!.isBlank, "blank total must be a blank cell")
        val totals = collectionRows(copy, "entity-review.csv").associate { it["entity_id"] to it["current_parent_count"] }
        clients.filter { totals[it.value("A")] == "0" }.forEach { assertEquals("0", it["E"]!!.number) }
        val summary = inspector.sheet(1)
        val unknown = summary.rows.single { it.value("A") == "Unknown (total blank)" }
        assertEquals(totals.values.count { it.isNullOrEmpty() }.toString(), unknown.value("B"))
        assertTrue(totals.values.count { it.isNullOrEmpty() } >= 1)
    }

    @Test fun `an UNAVAILABLE booking with an observed parent shows that parent as an incomplete read`() {
        val copy = WorkbookFixtures.copy(threeBatches, temporary.resolve("unavailable"))
        val (batch, reviews, row) = copy.find("booking-review.csv") { t, r -> t[r, "resolution"] == "UNAVAILABLE" }
        val company = reviews[row, "entity_id"]
        val booking = reviews[row, "booking_record_id"]
        val candidates = copy.read(batch, "parent-candidates.csv")
        val candidate = candidates.rows.indices.first { candidates[it, "entity_id"] == company }
        val parent = candidates[candidate, "parent_id"]
        reviews[row, "ultimate_parent_id"] = parent
        reviews[row, "ultimate_parent_name"] = candidates[candidate, "name"].ifEmpty { "Synthetic Parent Name" }
        for (field in listOf("current_records", "current_booking_codes")) {
            candidates[candidate, field] = ((candidates[candidate, field].toIntOrNull() ?: 0) + 1).toString()
        }
        copy.write(batch, "booking-review.csv", reviews)
        copy.write(batch, "parent-candidates.csv", candidates)
        copy.rehash()
        val output = temporary.resolve("review.xlsx")
        val run = workbookCli(copy.dir, output)
        assertEquals(0, run.code, run.console)
        val bookingRow = WorkbookInspector(output).sheet(3).rows.single { it.value("C") == booking }
        assertEquals(company, bookingRow.value("A"))
        assertEquals(parent, bookingRow.value("J"))
        val result = bookingRow.value("M").orEmpty()
        assertTrue(result.startsWith("Current-path evidence unavailable or incomplete"), result)
        assertTrue(result.contains("incomplete read"), result)
    }

    @Test fun `an unreviewed Inactive booking of an all-status export is kept and marked not reviewed`() {
        val copy = WorkbookFixtures.copy(threeBatches, temporary.resolve("inactive"))
        copy.editManifest { it["bookingStatus"] = JsonNull }
        val (batch, records, row) = copy.find("booking-records.csv") { _, _ -> true }
        val company = records[row, "entity_id"]
        val existing = collectionRows(copy, "booking-records.csv").map { it["booking_record_id"] }.toSet()
        val booking = generateSequence(900_001) { it + 1 }.map { it.toString() }.first { it !in existing }
        val added = records.rows[row].toMutableList()
        added[records.column("booking_record_id")] = booking
        added[records.column("booking_code")] = "INACTIVE-1"
        added[records.column("source_status")] = "Inactive"
        added[records.column("assigned_crds_party_id")] = "8999001"
        for (column in listOf("issue_ids", "evidence_ids", "query_run_ids")) added[records.column(column)] = ""
        val last = records.rows.indices.last { records[it, "entity_id"] == company }
        records.rows.add(last + 1, added)
        copy.write(batch, "booking-records.csv", records)
        copy.addedBookingRows(batch, 1)
        copy.rehash()
        val output = temporary.resolve("review.xlsx")
        val run = workbookCli(copy.dir, output)
        assertEquals(0, run.code, run.console)
        val bookings = WorkbookInspector(output).sheet(3)
        val total = copy.manifest()["exportedBookingCount"]!!.jsonPrimitive.content.toInt()
        assertEquals(total, bookings.rows.size - 1)
        val kept = bookings.rows.single { it.value("C") == booking }
        assertEquals(company, kept.value("A"))
        assertEquals("INACTIVE-1", kept.value("D"))
        assertEquals("Not reviewed: no booking-review row (this does not mean no parent)", kept.value("M"))
        assertEquals("8999001", kept.value("R"))
        for (column in listOf("J", "K", "L", "N", "O", "P", "Q", "S", "T", "U", "V", "W", "X", "Y")) {
            assertTrue(kept[column]?.isBlank ?: true, "column $column must stay blank for an unreviewed booking")
        }
    }

    @Test fun `integrity, path, reconciliation, cohort and size problems stop the build with exit three`() {
        val cases = linkedMapOf<String, (EditableCollection) -> List<String>>(
            "CSV size tamper" to { copy ->
                val file = copy.batchFolders()[0].resolve("booking-records.csv")
                Files.write(file, Files.readAllBytes(file) + "x".toByteArray())
                emptyList()
            },
            "same-size content tamper" to { copy ->
                val file = copy.batchFolders()[1].resolve("entities.csv")
                val text = Files.readString(file)
                Files.writeString(file, text.replaceFirst("Ltd", "Plc"))
                emptyList()
            },
            "dot-dot batch folder" to { copy ->
                copy.editManifest { fields ->
                    val batches = fields["batches"]!!.jsonArray.mapIndexed { index, batch ->
                        if (index != 0) batch else kotlinx.serialization.json.JsonObject(batch.jsonObject.toMutableMap().apply {
                            put("folder", JsonPrimitive("batches/../" + get("folder")!!.jsonPrimitive.content))
                        })
                    }
                    fields["batches"] = kotlinx.serialization.json.JsonArray(batches)
                }
                emptyList()
            },
            "reconciliation with another candidate" to { copy ->
                val candidates = collectionRows(copy, "parent-candidates.csv").groupBy({ it["entity_id"] }, { it["parent_id"] })
                val (batch, reviews, row) = copy.find("booking-review.csv") { t, r ->
                    t[r, "resolution"] == "CURRENT_PATH" && t[r, "ultimate_parent_id"].isNotEmpty() &&
                        candidates[t[r, "entity_id"]].orEmpty().size > 1
                }
                reviews[row, "ultimate_parent_id"] = candidates.getValue(reviews[row, "entity_id"])
                    .first { it != reviews[row, "ultimate_parent_id"] }!!
                copy.write(batch, "booking-review.csv", reviews)
                copy.rehash()
                emptyList()
            },
            "selected parent that is no candidate" to { copy ->
                val (batch, reviews, row) = copy.find("booking-review.csv") { t, r ->
                    t[r, "ultimate_parent_id"].isEmpty() && t[r, "resolution"] != "UNAVAILABLE"
                }
                reviews[row, "ultimate_parent_id"] = "99999999"
                reviews[row, "ultimate_parent_name"] = "Synthetic Unknown Parent"
                copy.write(batch, "booking-review.csv", reviews)
                copy.rehash()
                emptyList()
            },
            "wrong expected count" to { _ -> listOf("--expected-count", "13") },
            "wrong expected IDs" to { copy ->
                val ids = Files.writeString(copy.dir.resolveSibling("${copy.dir.fileName}-ids.txt"),
                    (RuleCorpus.requestedIds.drop(1) + "999").joinToString("\n"))
                listOf("--expected-ids", ids.toString())
            },
            "40,000-character text" to { copy ->
                val (batch, entities, row) = copy.find("entities.csv") { t, r -> t[r, "entity_name"].isNotEmpty() }
                entities[row, "entity_name"] = "Synthetic" + "N".repeat(40_000)
                copy.write(batch, "entities.csv", entities)
                copy.rehash()
                emptyList()
            },
        )
        cases.entries.forEachIndexed { index, (name, edit) -> assertStopsWithExitThree("case-$index", name, edit) }
    }

    /** Kept apart from the cases above so that, where links cannot be created, only this check is skipped. */
    @Test fun `a batch folder linked to outside the export stops the build with exit three`() =
        assertStopsWithExitThree("case-link", "symlinked batch outside") { copy ->
            val batch = copy.batchFolders()[2]
            val outside = Files.createDirectories(temporary.resolve("outside-${copy.dir.fileName}"))
            val moved = Files.move(batch, outside.resolve(batch.fileName))
            symlinkOrSkip(batch, moved)
            emptyList()
        }

    /** Applies one edit to a fresh copy of the collection and expects exit 3 with nothing published. */
    private fun assertStopsWithExitThree(folder: String, name: String, edit: (EditableCollection) -> List<String>) {
        val copy = WorkbookFixtures.copy(threeBatches, temporary.resolve(folder))
        val extra = edit(copy)
        val outputs = Files.createDirectory(temporary.resolve("out-$folder"))
        val run = workbookCli(copy.dir, outputs.resolve("review.xlsx"), *extra.toTypedArray())
        assertEquals(3, run.code, "$name\n${run.console}")
        assertTrue(run.err.startsWith("Workbook check failed: "), "$name\n${run.console}")
        assertFalse(run.console.contains("NNNNNNNNNN"), "$name: no business value in the message")
        assertEquals(emptyList<String>(), listTree(outputs), "$name: nothing is published or left behind")
    }

    /** Every consumed file hash in the receipt equals the file on disk. */
    private fun assertConsumedHashes(collection: EditableCollection, hashes: Map<String, String>) {
        assertEquals(1 + collection.batchFolders().size * (1 + (CollectionData.CONSUMED_FILES.size + CollectionData.OPTIONAL_FILES.size)), hashes.size)
        collection.batchFolders().forEachIndexed { index, folder ->
            assertEquals(sha256(Files.readAllBytes(folder.resolve("run-manifest.json"))), hashes["B${index + 1}/run-manifest.json"])
            for (file in CollectionData.CONSUMED_FILES + CollectionData.OPTIONAL_FILES) {
                assertEquals(sha256(Files.readAllBytes(folder.resolve(file))), hashes["B${index + 1}/$file"], file)
            }
        }
    }

    private companion object {
        val RECEIPT_KEYS = listOf("workbookFormat", "producer", "inputKind", "runId", "manifestFile", "manifestSha256",
            "evidenceSchema", "extractionStatus", "bookingStatus", "exportProducer", "batches", "consumedFiles",
            "consumedFileSha256", "options", "verification", "workbookFile", "workbookBytes", "workbookSha256")
    }
}
