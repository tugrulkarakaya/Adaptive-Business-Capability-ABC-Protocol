package com.db.clientinsights.export.workbook

import com.db.clientinsights.export.workbook.WorkbookLayout.ROW_CLIENT
import com.db.clientinsights.export.workbook.WorkbookLayout.ROW_CLIENT_DETAILS
import com.db.clientinsights.export.workbook.WorkbookLayout.ROW_CURRENT
import com.db.clientinsights.export.workbook.WorkbookLayout.ROW_NOT_OBSERVED
import com.db.clientinsights.export.workbook.WorkbookLayout.ROW_OTHER
import com.db.clientinsights.export.workbook.WorkbookLayout.ROW_PARENT_DETAILS
import kotlin.random.Random
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue

/**
 * The v5 workbook contract, checked on a written file against the source CSVs: six tabs, counts, the single
 * worksheet formula, same-file links that still find the right client and parent after the Bookings rows are
 * re-sorted, validations, conditional formats, AutoFilter, ignored errors, blank reviewer and team cells, no
 * MAIN_PARENT anywhere.
 */
internal class WorkbookContract(private val inspector: WorkbookInspector, private val collection: EditableCollection) {
    private val summary = inspector.sheet(1)
    private val main = inspector.sheet(2)
    private val bookings = inspector.sheet(3)
    private val rules = inspector.sheet(4)
    private val cohort = collection.manifest()["requestedEntityIds"]!!.jsonArray.map { it.jsonPrimitive.content }
    private val candidates = collectionRows(collection, "parent-candidates.csv").filter { it["entity_id"] in cohort }
    private val clientRows = main.rows.filter { it.value("D") == ROW_CLIENT }
    private val parentRows = main.rows.filter { it.value("D") in PARENT_ROW_TYPES }

    fun checkAll() {
        tabsAndParts()
        counts()
        oneWorksheetFormula()
        sameFileLinksSurviveSorting()
        validations()
        formatsFiltersAndIgnoredErrors()
        blankReviewerAndTeamCells()
        noMainParent()
        chartBinsSumToClients()
    }

    private fun tabsAndParts() {
        assertEquals(WorkbookLayout.SHEETS, inspector.sheetNames)
        assertEquals(WorkbookLayout.PARTS, inspector.partNames)
        inspector.parts.keys.filter { it.endsWith(".rels") }.forEach { part ->
            val text = inspector.text(part)
            assertFalse(text.contains("TargetMode"), "$part has an external relationship")
            assertFalse(Regex("Target=\"[a-z]+:").containsMatchIn(text), "$part points to a URI")
        }
    }

    private fun counts() {
        assertEquals(cohort, clientRows.map { it.value("A") }, "client rows follow the collection order")
        assertEquals(candidates.size, parentRows.size, "one parent row per parent candidate")
        assertEquals(cohort.size, main.rows.count { it.value("D") == ROW_CLIENT_DETAILS })
        assertEquals(candidates.size, main.rows.count { it.value("D") == ROW_PARENT_DETAILS })
        assertEquals(1 + 2 * (cohort.size + candidates.size), main.rows.size)
        for (row in clientRows) assertTrue(!row.hidden && row.level == 0 && row.collapsed, "client row ${row.number}")
        for (row in parentRows) assertTrue(row.hidden && row.level == 1 && row.collapsed, "parent row ${row.number}")
        main.rows.filter { it.value("D") == ROW_PARENT_DETAILS }.forEach { assertTrue(it.hidden && it.level == 2) }
        val exported = collection.manifest()["exportedBookingCount"]!!.jsonPrimitive.content.toInt()
        assertEquals(exported, bookings.rows.size - 1, "one Bookings row per exported booking record")
        val sourceIds = collectionRows(collection, "booking-records.csv").map { it.getValue("booking_record_id") }.sorted()
        assertEquals(sourceIds, bookings.rows.drop(1).map { it.value("C").orEmpty() }.sorted())
    }

    private fun oneWorksheetFormula() {
        assertEquals(listOf("B11"), summary.formulaCells, "exactly one formula, at Summary!B11")
        listOf(main, bookings, rules).forEach { assertEquals(emptyList<String>(), it.formulaCells) }
        val formula = summary.cell(summary.formulaCells.single())!!
        assertEquals("0", formula.number, "cached value 0, recalculated on load")
        assertTrue(formula.formula!!.startsWith("COUNTIFS("), formula.formula)
        assertTrue(formula.formula.contains("\$M\$2:\$M\$${main.rows.size}"), formula.formula)
        val calc = WorkbookInspector.elements(inspector.xml("xl/workbook.xml").documentElement, "calcPr").single()
        assertEquals("1", calc.getAttribute("fullCalcOnLoad"))
        assertNotEquals1904()
    }

    private fun assertNotEquals1904() {
        val pr = WorkbookInspector.elements(inspector.xml("xl/workbook.xml").documentElement, "workbookPr").singleOrNull()
        assertTrue(pr == null || pr.getAttribute("date1904") !in setOf("1", "true"))
    }

    private fun sameFileLinksSurviveSorting() {
        listOf(summary, bookings, rules).forEach { assertTrue(it.all("hyperlink").isEmpty()) }
        val links = main.all("hyperlink")
        val names = inspector.definedNames
        assertEquals(names.size - 1, links.size, "one defined name per link, plus the filter range")
        assertTrue(names.keys.first() == "_xlnm._FilterDatabase")
        val dataRows = bookings.rows.drop(1)
        val random = Random(7)
        val orders = listOf(dataRows, dataRows.reversed(), dataRows.sortedByDescending { it.value("C") }, dataRows.shuffled(random))
        for (link in links) {
            assertEquals("", link.getAttributeNS(WorkbookInspector.NS_REL, "id"), "links stay inside the file")
            val ref = link.getAttribute("ref")
            val source = main.byNumber.getValue(ref.drop(1).toInt())
            val formula = names.getValue(link.getAttribute("location"))
            val match = JUMP.matchEntire(formula)
            assertNotNull(match, formula)
            val (key, keyColumn) = match!!.destructured
            assertEquals(source.value("J"), dataRows.count { it.value(keyColumn) == key }.toString(),
                "the number shown at $ref counts the rows it jumps to")
            for (order in orders) {
                val target = order.first { it.value(keyColumn) == key }
                assertEquals(source.value("A"), target.value("A"), "jump $ref finds its client after sorting")
                if (source.value("D") != ROW_CLIENT) {
                    assertEquals(source.value("B"), target.value("J"), "jump $ref finds its selected parent after sorting")
                }
            }
        }
        val linked = main.rows.filter { (it["J"]?.style ?: -1) in setOf(WorkbookLayout.S_SUM_LINK, WorkbookLayout.S_CHILD_LINK) }
        assertEquals(linked.map { "J${it.number}" }, links.map { it.getAttribute("ref") })
    }

    private fun validations() {
        listOf(summary, bookings, rules).forEach { assertTrue(it.all("dataValidation").isEmpty()) }
        val reviewRows = (clientRows + parentRows).map { it.number }.sorted()
        val validations = main.all("dataValidation")
        assertEquals(2, validations.size)
        val list = validations.single { it.getAttribute("type") == "list" }
        assertEquals("1", list.getAttribute("allowBlank"))
        assertEquals("1", list.getAttribute("showErrorMessage"))
        assertEquals(reviewRows.map { "M$it" }, list.getAttribute("sqref").split(" "))
        assertEquals("\"" + WorkbookLayout.DRAFT_DECISION_OPTIONS.joinToString(",") + "\"",
            WorkbookInspector.elements(list, "formula1").single().textContent)
        val date = validations.single { it.getAttribute("type") == "date" }
        assertEquals("between", date.getAttribute("operator"))
        assertEquals("1", date.getAttribute("allowBlank"))
        assertEquals(reviewRows.map { "P$it" }, date.getAttribute("sqref").split(" "))
        assertEquals("1", WorkbookInspector.elements(date, "formula1").single().textContent)
        assertEquals("2958465", WorkbookInspector.elements(date, "formula2").single().textContent)
    }

    private fun formatsFiltersAndIgnoredErrors() {
        listOf(summary, bookings, rules).forEach { assertTrue(it.all("conditionalFormatting").isEmpty()) }
        val rulesByType = main.all("cfRule").associateBy { it.getAttribute("type") }
        assertEquals(setOf("expression", "dataBar"), rulesByType.keys)
        assertEquals(2, main.all("cfRule").size)
        assertEquals("\$M2<>\"\"", WorkbookInspector.elements(rulesByType.getValue("expression"), "formula").single().textContent)
        listOf(summary, main, rules).forEach { assertTrue(it.all("autoFilter").isEmpty(), "AutoFilter only on Bookings") }
        assertEquals("A1:AF${bookings.rows.size}", bookings.all("autoFilter").single().getAttribute("ref"))
        for (sheet in listOf(summary, main, bookings, rules)) {
            for (ignored in sheet.all("ignoredError")) {
                val attributes = (0 until ignored.attributes.length).associate {
                    ignored.attributes.item(it).nodeName to ignored.attributes.item(it).nodeValue
                }
                assertEquals(setOf("sqref", "numberStoredAsText"), attributes.keys, "only number-stored-as-text is ignored")
                assertEquals("1", attributes["numberStoredAsText"])
            }
        }
    }

    private fun blankReviewerAndTeamCells() {
        for (row in clientRows + parentRows) {
            for (column in listOf("M", "N", "O", "P")) {
                val cell = row[column]
                assertNotNull(cell, "reviewer cell $column${row.number}")
                assertTrue(cell!!.isBlank, "reviewer cell $column${row.number} must be blank")
                val style = if (column == "P") WorkbookLayout.S_INPUT_DATE else WorkbookLayout.S_INPUT
                assertEquals(style, cell.style, "$column${row.number}")
            }
        }
        main.rows.filter { it.value("D") in setOf(ROW_CLIENT_DETAILS, ROW_PARENT_DETAILS) }.forEach { row ->
            listOf("M", "N", "O", "P").forEach { assertNull(row[it], "detail rows carry no reviewer cells") }
        }
        val teamCells = rules.rows.flatMap { it.cells.values }.filter { it.style == WorkbookLayout.S_INPUT }
        assertEquals(8, teamCells.size)
        assertTrue(teamCells.all { it.isBlank })
    }

    private fun noMainParent() {
        inspector.parts.forEach { (name, bytes) ->
            assertFalse(String(bytes, Charsets.UTF_8).contains("MAIN_PARENT"), "$name mentions MAIN_PARENT")
        }
    }

    private fun chartBinsSumToClients() {
        val header = summary.rows.single { it.value("A") == "Current parents" && it.value("B") == "Clients" }
        val bins = (1..7).map { summary.byNumber.getValue(header.number + it) }
        assertEquals("Unknown (total blank)", bins.last().value("A"))
        assertEquals(cohort.size.toLong(), bins.sumOf { it.value("B")!!.toLong() })
        val chart = inspector.xml("xl/charts/chart1.xml").documentElement
        val refs = WorkbookInspector.elements(chart, "f", NS_CHART).map { it.textContent }
        val first = header.number + 1
        val last = header.number + 7
        val d = '$'
        assertEquals(listOf("Summary!${d}B$d${header.number}", "Summary!${d}A$d$first:${d}A$d$last",
            "Summary!${d}B$d$first:${d}B$d$last"), refs, "the chart's three references point at the Summary table")
        val cached = WorkbookInspector.elements(chart, "v", NS_CHART).map { it.textContent }
        assertTrue(cached.containsAll(bins.map { it.value("A")!! }), "category cache equals the Summary labels")
    }

    private companion object {
        val PARENT_ROW_TYPES = setOf(ROW_CURRENT, ROW_OTHER, ROW_NOT_OBSERVED)
        private const val D = "\\$"
        const val NS_CHART = "http://schemas.openxmlformats.org/drawingml/2006/chart"
        /** INDEX(Bookings!$A$2:$A$n,MATCH("key",Bookings!$K$2:$K$n,0)): captures the key and its column. */
        val JUMP = Regex("INDEX\\(Bookings!${D}A${D}2:${D}A${D}\\d+,MATCH\\(\"([^\"]+)\",Bookings!${D}([A-Z]+)${D}2:" +
            "${D}[A-Z]+${D}\\d+,0\\)\\)")
    }
}
