package com.db.clientinsights.export

import com.db.clientinsights.export.adapters.fixture.FixtureData
import com.db.clientinsights.export.adapters.fixture.FixtureSources
import com.db.clientinsights.export.adapters.icms.*
import com.db.clientinsights.export.application.ExportService
import com.db.clientinsights.export.cli.CliOptions
import com.db.clientinsights.export.cli.openSources
import com.db.clientinsights.export.domain.*
import com.db.clientinsights.export.rules.CheckResults
import com.db.clientinsights.export.rules.UsageEvidenceRules
import java.nio.file.Files
import java.nio.file.Path
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.io.TempDir

class OracleUsageEvidenceSourceTest {
    @TempDir lateinit var temporary: Path
    private val request = ExportRequest(listOf(entityId("248")))
    private val emptyFacts = ExtractedFacts(emptyList(), emptyList(), emptyList(), emptyList())

    @Test fun `all statuses are scoped and paged by stable contact ID and only active people count`() {
        TestDatabase().use { db ->
            installContacts(db)
            db.execute("INSERT INTO T_CONTACT_PERSON VALUES (7, 248, 'Inactive'), (2, 248, 'Active'), (9, 300, 'Active'), (4, 248, 'Active')")
            val facts = adapter(db, pageSize = 1).fetch(request, emptyFacts)
            assertEquals(listOf("2", "4", "7"), facts.contacts.map { it.data.rowId })
            assertEquals(listOf("Active", "Active", "Inactive"), facts.contacts.map { it.data.status })
            assertTrue(facts.contacts.all { it.data.entityId == entityId("248") })
            assertTrue(facts.contacts.all { it.data.platformName == null && it.data.nameOnPlatform == null })
            val query = facts.queries.single()
            assertEquals("ACTIVE_CONTACT_PEOPLE", query.dataset)
            assertEquals(listOf("248"), query.requestedKeys)
            assertEquals(FetchStatus.COMPLETE, query.status)
            assertEquals(3, query.exportedRowCount)
            assertEquals(2, contactReview(facts).activeContactCount)
            assertTrue(facts.confirmations.isEmpty())
            assertTrue(facts.trading.isEmpty())
            assertEquals(listOf("2", "4", "7"), facts.contacts.map { it.origin.sourceRecordId })
            assertTrue(facts.contacts.all { it.origin.queryRunId == query.queryRunId && it.origin.sourceId == query.sourceId })
        }
    }

    @Test fun `completed empty contact read proves zero but failed or truncated read remains unknown`() {
        TestDatabase().use { db ->
            installContacts(db)
            val complete = adapter(db).fetch(request, emptyFacts)
            assertEquals(FetchStatus.COMPLETE, complete.queries.single().status)
            assertEquals(0, contactReview(complete).activeContactCount)
            db.execute("INSERT INTO T_CONTACT_PERSON VALUES (1, 248, 'Active'), (2, 248, 'Active')")
            val partial = adapter(db, pageSize = 1, maxRows = 1).fetch(request, emptyFacts)
            assertEquals(FetchStatus.PARTIAL, partial.queries.single().status)
            assertNull(contactReview(partial).activeContactCount)
            db.execute("DROP TABLE T_CONTACT_PERSON")
            val unavailable = adapter(db).fetch(request, emptyFacts)
            assertEquals(FetchStatus.FAILED, unavailable.queries.single().status)
            assertEquals("SQL_ERROR", unavailable.queries.single().failureCode)
            assertNull(contactReview(unavailable).activeContactCount)
        }
    }

    @Test fun `standard application source boundary publishes contact evidence without claiming confirmation or trading`() {
        TestDatabase().use { db ->
            installContacts(db)
            db.execute("INSERT INTO T_CONTACT_PERSON VALUES (1, 248, 'Active'), (2, 248, 'Inactive')")
            val core = FixtureSources(FixtureData(
                entities = listOf(IcmsEntity(entityId("248"), "Synthetic client", "Active")),
                bookingRecords = emptyList(), bookingSystems = emptyList(), settlementMethods = emptyList()))
            val bundle = ExportService(core, core, TEST_PRODUCER, clock = TEST_CLOCK, usageEvidenceSource = adapter(db)).extract(request)
            val review = checkNotNull(bundle.review)
            assertEquals(1, review.usage.contacts.single().activeContactCount)
            assertEquals(2, review.facts.usageEvidence.contacts.size)
            assertEquals(1, bundle.queries.count { it.dataset == "ACTIVE_CONTACT_PEOPLE" })
            assertTrue(bundle.queries.none { it.dataset in setOf("CONFIRMATION_ROUTINGS", "BOOKING_TRADING_24_MONTHS") })
        }
    }

    @Test fun `contacts profile inherits ICMS credentials or requires explicit separate password variable`() {
        val lookups = mutableListOf<String>()
        val file = temporary.resolve("oracle.properties")
        Files.writeString(file, "icms.jdbc.url=jdbc:oracle:thin:@//127.0.0.1:9/SYNTHETIC\nicms.username=SYNTHETIC\nicms.password-env=SYNTHETIC_PASSWORD\n")
        val config = OracleSourceConfiguration.load(file) { variable -> lookups += variable; "SYNTHETIC" }
        config.executor("contacts")
        assertEquals(listOf("SYNTHETIC_PASSWORD"), lookups)
        Files.writeString(file, "contacts.jdbc.url=jdbc:oracle:thin:@//127.0.0.1:9/SYNTHETIC\ncontacts.username=SYNTHETIC\n")
        val separate = OracleSourceConfiguration.load(file) { error("Environment must not be consulted") }
        assertThrows(IllegalArgumentException::class.java) { separate.executor("contacts") }
    }

    @Test fun `Oracle CLI sources wire the validated contacts adapter lazily`() {
        val file = temporary.resolve("empty-oracle.properties")
        Files.writeString(file, "")
        val options = CliOptions.parse(arrayOf("--config=$file", "--ids=248"))
        val sources = openSources(options) { error("No configured connection should require credentials") }
        assertTrue(sources.usage is OracleUsageEvidenceSource)
        val facts = checkNotNull(sources.usage).fetch(request, emptyFacts)
        assertEquals(FetchStatus.NOT_CONFIGURED, facts.queries.single().status)
        assertNull(contactReview(facts).activeContactCount)
    }

    private fun contactReview(facts: UsageEvidenceFacts) = UsageEvidenceRules(TEST_CLOCK)
        .evaluate(request, CheckResults(listOf(EntitySummary(entityId("248"), EntityPresence.FOUND,
            "Synthetic client", "Active", FetchStatus.COMPLETE, FetchStatus.COMPLETE, FetchStatus.COMPLETE,
            0, CheckStatus.PASS, emptyList(), emptyList())), emptyList(), emptyList()), facts).contacts.single()

    private fun adapter(db: TestDatabase, pageSize: Int = 1000, maxRows: Int = 100000) = OracleUsageEvidenceSource { profile ->
        assertEquals("contacts", profile)
        JdbcQueryExecutor("synthetic-contacts", "", db.connections, QueryLimits(pageSize = pageSize, maxRows = maxRows))
    }

    private fun installContacts(db: TestDatabase) {
        db.execute("INSERT INTO PRD_EXPORT_LEGAL_ENTITY VALUES (248, 'Synthetic client', 'Active'), (300, 'Other client', 'Active')")
        db.execute("CREATE TABLE T_CONTACT_PERSON (id NUMBER PRIMARY KEY, le_id NUMBER, status VARCHAR2(30))")
    }
}
