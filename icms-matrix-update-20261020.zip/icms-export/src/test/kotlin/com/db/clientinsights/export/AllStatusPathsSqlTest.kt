package com.db.clientinsights.export

import com.db.clientinsights.export.adapters.fixture.FixtureData
import com.db.clientinsights.export.adapters.fixture.FixtureSources
import com.db.clientinsights.export.adapters.icms.JdbcQueryExecutor
import com.db.clientinsights.export.adapters.icms.OracleReviewDataSource
import com.db.clientinsights.export.domain.*
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test

class AllStatusPathsSqlTest {
    @Test fun `inactive and missing hierarchy evidence survives without changing current parent selection`() {
        TestDatabase().use { db ->
            installReviewSchema(db)
            db.execute("INSERT INTO PRD_EXPORT_LEGAL_ENTITY VALUES (248, 'Synthetic status case', 'Active')")
            seedBooking(db, 1, 248, "MIXED")
            seedBooking(db, 2, 248, "NO-HIERARCHY")
            seedReviewPath(db, 1, "MIXED", 11, 100)
            seedReviewPath(db, 2, "MIXED", 12, 200, accountStatus = "SUSPENDED", relationshipStatus = "INACTIVE", ended = true)
            seedReviewPath(db, 3, "NO-HIERARCHY", 13, 300, accountStatus = "DELETED")
            db.execute("DELETE FROM CRDS_DIF_PARTY_HIERARCHY WHERE party_id = 13")
            val facts = fetch(db, pageSize = 1)
            assertTrue(facts.queries.all { it.status == FetchStatus.COMPLETE }, facts.queries.toString())
            assertEquals(3, facts.allStatusPaths.size)
            val inactive = facts.allStatusPaths.single { it.data.bookingStatus == "SUSPENDED" }.data
            assertEquals("12", inactive.rhpId)
            assertEquals("200", inactive.ultimateParentId)
            assertEquals("INACTIVE", inactive.statuses["business_relationship_status"])
            assertEquals("Y", inactive.statuses["hierarchy_ended"])
            val missing = facts.allStatusPaths.single { it.data.bookingCode == "NO-HIERARCHY" }.data
            assertEquals("13", missing.rhpId)
            assertNull(missing.ultimateParentId)
            assertNull(missing.statuses["hierarchy_ended"])
            assertEquals("DELETED", missing.bookingStatus)
            assertTrue(facts.parties.any { it.data.partyId == "13" })
            assertTrue(facts.parties.any { it.data.partyId == "12" })
            assertEquals("100", facts.currentBookings.single { it.data.recordId == "1" }.data.ultimateParentId)
            assertNull(facts.currentBookings.single { it.data.recordId == "2" }.data.ultimateParentId)
            assertEquals(3, facts.allStatusPaths.map { it.origin.sourceRecordId }.distinct().size)
        }
    }

    @Test fun `duplicate observations aggregate safely across pages and truncated reads are marked partial`() {
        TestDatabase().use { db ->
            installReviewSchema(db)
            db.execute("INSERT INTO PRD_EXPORT_LEGAL_ENTITY VALUES (248, 'Synthetic duplicate case', 'Active')")
            seedBooking(db, 1, 248, "MIXED")
            seedReviewPath(db, 1, "MIXED", 11, 100)
            seedReviewPath(db, 2, "MIXED", 12, 200, accountStatus = "INACTIVE")
            db.execute("INSERT INTO CRDS_BR_ACCOUNT_XREF SELECT * FROM CRDS_BR_ACCOUNT_XREF WHERE brps_id = 1")
            val complete = fetch(db, pageSize = 1)
            assertEquals(listOf(1L, 2L), complete.allStatusPaths.map { it.data.pathCount }.sorted())
            assertEquals(2, complete.allStatusPaths.map { it.origin.evidenceId }.distinct().size)
            val partial = fetch(db, pageSize = 1, maxRows = 1)
            val statusQuery = partial.queries.single { it.dataset == "ALL_BOOKING_STATUS_PATHS" }
            assertEquals(FetchStatus.PARTIAL, statusQuery.status)
            assertEquals("ROW_LIMIT_REACHED", statusQuery.failureCode)
            assertEquals(1, partial.allStatusPaths.size)
        }
    }

    @Test fun `missing upstream relationship still retains booking status without invented party identifiers`() {
        TestDatabase().use { db ->
            installReviewSchema(db)
            db.execute("INSERT INTO PRD_EXPORT_LEGAL_ENTITY VALUES (248, 'Synthetic orphan case', 'Active')")
            seedBooking(db, 1, 248, "ORPHAN")
            db.execute("INSERT INTO CRDS_BR_ACCOUNT_XREF VALUES ('ORPHAN', 1, 'SUSPENDED', TIMESTAMP '2026-01-01 00:00:00')")
            db.execute("INSERT INTO CRDS_BR_PRODUCT_SYSTEM VALUES (1, 150, 999, 'ACTIVE')")
            val path = fetch(db, pageSize = 1).allStatusPaths.single().data
            assertEquals("SUSPENDED", path.bookingStatus)
            assertNull(path.rhpId)
            assertNull(path.ultimateParentId)
            assertNull(path.statuses["business_relationship_status"])
        }
    }

    @Test fun `fixture keeps only requested mapped keys and retags status path provenance`() {
        TestDatabase().use { db ->
            installReviewSchema(db)
            db.execute("INSERT INTO PRD_EXPORT_LEGAL_ENTITY VALUES (248, 'Synthetic case', 'Active')")
            seedBooking(db, 1, 248, "KEEP")
            seedBooking(db, 2, 248, "EXCLUDE")
            seedReviewPath(db, 1, "KEEP", 11, 100)
            seedReviewPath(db, 2, "EXCLUDE", 12, 200, accountStatus = "INACTIVE")
            val raw = fetch(db, pageSize = 1)
            val usageQueries = listOf("ACTIVE_CONTACT_PEOPLE", "CONFIRMATION_ROUTINGS", "BOOKING_TRADING_24_MONTHS").map { dataset ->
                raw.queries.first().copy(queryRunId = "usage-$dataset", dataset = dataset, exportedRowCount = 2)
            }
            fun <T> usageRow(value: T, dataset: String, id: String) = SourceRow(value,
                RecordOrigin("usage:$dataset:$id", "test", dataset, id, "usage-$dataset"))
            val original = raw.copy(usageEvidence = UsageEvidenceFacts(
                contacts = listOf(usageRow(ContactPersonFact("1", entityId("248"), "person-1", "Active", "Synthetic", "Person"), "ACTIVE_CONTACT_PEOPLE", "1"),
                    usageRow(ContactPersonFact("2", entityId("300"), "person-2", "Active", "Synthetic", "Person"), "ACTIVE_CONTACT_PEOPLE", "2")),
                confirmations = listOf("1", "2").map { id -> usageRow(ConfirmationRoutingFact(id, entityId("248"), id, "Synthetic", true), "CONFIRMATION_ROUTINGS", id) },
                trading = listOf("1", "2").map { id -> usageRow(BookingTradingFact(id, entityId("248"), id, "2024-10-20", "2026-10-20", 1, "2026-10-19", true, true), "BOOKING_TRADING_24_MONTHS", id) },
                queries = usageQueries))
            val booking = BookingRecord("1", entityId("248"), "KEEP", IcmsSettlementSystemId("10"), "1", null, "Active")
            val fixture = FixtureSources(FixtureData(
                entities = listOf(IcmsEntity(entityId("248"), "Synthetic case", "Active")),
                bookingRecords = listOf(booking),
                bookingSystems = listOf(BookingSystem(IcmsSettlementSystemId("10"), "Synthetic", CrdsSystemId("150"))),
                settlementMethods = emptyList(), review = original))
            val request = ExportRequest(listOf(entityId("248")))
            val facts = ExtractedFacts(emptyList(), fixture.fetchBookingRecords(request.entityIds, "Active").rows, emptyList(), emptyList())
            val scoped = checkNotNull(fixture.reviewSource).fetch(request, facts)
            assertEquals(listOf("KEEP"), scoped.allStatusPaths.map { it.data.bookingCode })
            val query = scoped.queries.single { it.dataset == "ALL_BOOKING_STATUS_PATHS" }
            assertEquals(1, query.exportedRowCount)
            assertEquals(query.queryRunId, scoped.allStatusPaths.single().origin.queryRunId)
            assertNotEquals(original.allStatusPaths.first().origin.queryRunId, scoped.allStatusPaths.single().origin.queryRunId)
            assertEquals(1, scoped.usageEvidence.contacts.size)
            assertEquals(listOf("1"), scoped.usageEvidence.confirmations.map { it.data.bookingRecordId })
            assertEquals(listOf("1"), scoped.usageEvidence.trading.map { it.data.bookingRecordId })
            assertTrue(scoped.usageEvidence.queries.all { it.exportedRowCount == 1 })
            val usageQueryIds = scoped.usageEvidence.queries.map { it.queryRunId }.toSet()
            assertTrue(scoped.usageEvidence.contacts.all { it.origin.queryRunId in usageQueryIds })
            assertTrue(scoped.usageEvidence.confirmations.all { it.origin.queryRunId in usageQueryIds })
            assertTrue(scoped.usageEvidence.trading.all { it.origin.queryRunId in usageQueryIds })
            assertTrue(scoped.usageEvidence.contacts.all { it.origin.sourceId == "synthetic-fixture" })
        }
    }

    @Test fun `unavailable all status query remains failed and cannot claim empty complete evidence`() {
        TestDatabase().use { db ->
            installReviewSchema(db)
            db.execute("INSERT INTO PRD_EXPORT_LEGAL_ENTITY VALUES (248, 'Synthetic inaccessible case', 'Active')")
            seedBooking(db, 1, 248, "ONE")
            db.execute("DROP TABLE CRDS_BR_ACCOUNT_XREF")
            val facts = fetch(db, pageSize = 1)
            assertTrue(facts.allStatusPaths.isEmpty())
            val query = facts.queries.single { it.dataset == "ALL_BOOKING_STATUS_PATHS" }
            assertEquals(FetchStatus.FAILED, query.status)
            assertEquals("SQL_ERROR", query.failureCode)
        }
    }

    private fun fetch(db: TestDatabase, pageSize: Int, maxRows: Int = 100000): ReviewFacts {
        val executor = JdbcQueryExecutor("test", "", db.connections, QueryLimits(pageSize = pageSize, maxRows = maxRows))
        return OracleReviewDataSource { executor }.fetch(ExportRequest(listOf(entityId("248"))), ExtractedFacts(emptyList(), emptyList(), emptyList(), emptyList()))
    }
}
