package com.db.clientinsights.export

import com.db.clientinsights.export.adapters.csv.CsvExports
import com.db.clientinsights.export.adapters.csv.ThemeB6CsvExports
import com.db.clientinsights.export.domain.*
import java.nio.file.Files
import java.nio.file.Path
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.io.TempDir

class ThemeB6CsvExportsTest {
    @TempDir lateinit var temporary: Path

    @Test fun `CSV preserves conditional assessments and path provenance without inventing actual confidence`() {
        val path = SourceRow(AllStatusBookingPath("path-1", "150", "001234", "100", "200", "INACTIVE", "2026-01-02"),
            RecordOrigin("e-path", "crds", "ALL_STATUS_PATHS", "path-1", "q-path"))
        val category = ThemeB6CategoryAssessment("INACTIVE_BOOKING", "NOT_DETERMINED", null,
            "HIGH", "MEDIUM", listOf(5, 6), listOf("RECENT_TRADING"), "Trading has not been established.")
        val booking = ThemeB6BookingAssessment(entityId("248"), "record-1", "150", "001234", "1", "e-path", "100",
            "ACTIVE", "2026-01-01", "200", "ACTIVE", "2026-01-01", "INACTIVE", "2026-01-02", false,
            FetchStatus.COMPLETE, listOf(category), listOf("e-path"), listOf("q-path"))
        val review = emptyReview(ReviewFacts(allStatusPaths = listOf(path)))
            .copy(themeB6 = ThemeB6Review(bookings = listOf(booking)))

        val counts = ThemeB6CsvExports(CsvExports()).write(review, temporary)

        assertEquals(1, counts["theme-b6-booking-assessments.csv"])
        val row = readCsv(temporary.resolve("theme-b6-booking-assessments.csv")).single()
        assertEquals("001234", row["booking_code"])
        assertEquals("150", row["crds_system_id"])
        assertFalse(row.containsKey("icms_system_id"))
        assertEquals("NOT_DETERMINED", row["result"])
        assertEquals("", row["confidence"])
        assertEquals("HIGH", row["if_no_recent_trading"])
        assertEquals("MEDIUM", row["if_recent_trading"])
        assertEquals("5|6", row["matrix_rows"])
        assertEquals("RECENT_TRADING", row["missing_inputs"])
        assertEquals("false", row["matches_current_party_pair"])
        assertEquals("WIP", row["policy_status"])
        assertEquals("e-path", row["evidence_ids"])
        assertEquals("q-path", row["query_run_ids"])
        val raw = readCsv(temporary.resolve("theme-b6-status-paths.csv")).single()
        assertEquals("INACTIVE", raw["crds_booking_status"])
        assertEquals("e-path", raw["evidence_id"])
        assertEquals("ALL_STATUS_PATHS_INCLUDING_HISTORICAL_NOT_CURRENT_SELECTION", raw["evidence_scope"])
    }

    @Test fun `parent summary exposes ambiguous bucket and all-path scope separately from current selection`() {
        val parent = ThemeB6ParentSummary(entityId("248"), "200", 2, 1, 0,
            linkedMapOf("UNKNOWN" to 1, "AMBIGUOUS" to 1), listOf("ACTIVE", "INACTIVE"), FetchStatus.PARTIAL,
            listOf("e-a", "e-b"), listOf("q-a"))
        val review = emptyReview().copy(themeB6 = ThemeB6Review(parentSummaries = listOf(parent)))

        ThemeB6CsvExports(CsvExports()).write(review, temporary)

        val row = readCsv(temporary.resolve("theme-b6-parent-status-summary.csv")).single()
        assertEquals("2", row["booking_record_count"])
        assertEquals("1", row["distinct_booking_code_count"])
        assertEquals("0", row["current_selected_record_count"])
        assertEquals("AMBIGUOUS=1|UNKNOWN=1", row["booking_status_counts"])
        assertEquals("ACTIVE|INACTIVE", row["observed_statuses"])
        assertEquals("PARTIAL", row["source_status"])
        assertEquals("ALL_STATUS_PATH_ASSOCIATIONS_INCLUDING_HISTORICAL", row["count_scope"])
    }

    @Test fun `empty evidence writes discoverable headers and source gaps instead of fabricated booking results`() {
        val counts = ThemeB6CsvExports(CsvExports()).write(emptyReview(), temporary)

        assertEquals(5, counts.size)
        assertEquals(0, counts["theme-b6-booking-assessments.csv"])
        assertTrue(readCsv(temporary.resolve("theme-b6-booking-assessments.csv")).isEmpty())
        val gaps = readCsv(temporary.resolve("theme-b6-source-availability.csv")).associateBy { it.getValue("requirement") }
        assertEquals("NOT_CONFIGURED", gaps.getValue("RECENT_TRADING_24_MONTHS")["status"])
        assertEquals("NOT_CONFIGURED", gaps.getValue("ACTIVE_CONTACT_PEOPLE")["status"])
        assertEquals("BUSINESS_DECISION_REQUIRED", gaps.getValue("COMBINED_UNUSED_CONFIDENCE")["status"])
        assertTrue(Files.readString(temporary.resolve("theme-b6-rhp-summary.csv")).contains("has_unknown_status"))
    }

    @Test fun `source availability uses configured entity evidence rather than a fixed missing source label`() {
        val query = QueryRun("q-contact", "synthetic-contact-source", "fixture", "ACTIVE_CONTACT_PEOPLE", "contacts-v1",
            "a".repeat(64), listOf("248"), QueryLimits(), "2026-10-20T00:00:00Z", "2026-10-20T00:00:01Z",
            FetchStatus.COMPLETE, 2, 1)
        val contact = ContactReview(entityId("248"), 2, emptyList(), "COMPLETE", emptyList(), listOf("e-contact"), listOf("q-contact"))
        val review = emptyReview(ReviewFacts(usageEvidence = UsageEvidenceFacts(queries = listOf(query))))
            .copy(usage = UsageReview(contacts = listOf(contact)))

        ThemeB6CsvExports(CsvExports()).write(review, temporary)

        val rows = readCsv(temporary.resolve("theme-b6-source-availability.csv")).associateBy { it.getValue("requirement") }
        assertEquals("248", rows.getValue("ACTIVE_CONTACT_PEOPLE")["entity_id"])
        assertEquals("COMPLETE", rows.getValue("ACTIVE_CONTACT_PEOPLE")["status"])
        assertEquals("COMPLETE", rows.getValue("ACTIVE_CONTACT_PEOPLE")["source_read_status"])
        assertEquals("NOT_CONFIGURED", rows.getValue("RECENT_TRADING_24_MONTHS")["status"])
    }

    @Test fun `truncated configured source is partial even if its result claims complete`() {
        val query = QueryRun("q-contact", "synthetic-contact-source", "fixture", "ACTIVE_CONTACT_PEOPLE", "contacts-v1",
            "a".repeat(64), listOf("248"), QueryLimits(), "2026-10-20T00:00:00Z", "2026-10-20T00:00:01Z",
            FetchStatus.COMPLETE, 2, 1, truncated = true)
        val contact = ContactReview(entityId("248"), 2, emptyList(), "COMPLETE", emptyList(), listOf("e-contact"), listOf("q-contact"))
        val review = emptyReview(ReviewFacts(usageEvidence = UsageEvidenceFacts(queries = listOf(query))))
            .copy(usage = UsageReview(contacts = listOf(contact)))

        ThemeB6CsvExports(CsvExports()).write(review, temporary)

        val row = readCsv(temporary.resolve("theme-b6-source-availability.csv")).first { it["requirement"] == "ACTIVE_CONTACT_PEOPLE" }
        assertEquals("PARTIAL", row["status"])
        assertEquals("PARTIAL", row["source_read_status"])
    }

    @Test fun `complete active-person count does not certify an unvalidated platform name bridge`() {
        val query = QueryRun("q-contact", "synthetic-contact-source", "fixture", "ACTIVE_CONTACT_PEOPLE", "contacts-v1",
            "a".repeat(64), listOf("248"), QueryLimits(), "2026-10-20T00:00:00Z", "2026-10-20T00:00:01Z",
            FetchStatus.COMPLETE, 2, 1)
        val contact = ContactReview(entityId("248"), 2, emptyList(), "COMPLETE",
            listOf("ACTIVE_CONTACT_CUSTOMER_PLATFORM_NAMES_NOT_VALIDATED_OR_INCOMPLETE"), listOf("e-contact"), listOf("q-contact"))
        val review = emptyReview(ReviewFacts(usageEvidence = UsageEvidenceFacts(queries = listOf(query))))
            .copy(usage = UsageReview(contacts = listOf(contact)))

        ThemeB6CsvExports(CsvExports()).write(review, temporary)

        val rows = readCsv(temporary.resolve("theme-b6-source-availability.csv")).associateBy { it.getValue("requirement") }
        assertEquals("COMPLETE", rows.getValue("ACTIVE_CONTACT_PEOPLE")["status"])
        assertEquals("NOT_DETERMINED", rows.getValue("ACTIVE_CONTACT_CUSTOMER_PLATFORM_NAMES")["status"])
        assertEquals("COMPLETE", rows.getValue("ACTIVE_CONTACT_CUSTOMER_PLATFORM_NAMES")["source_read_status"])
    }

    private fun emptyReview(facts: ReviewFacts = ReviewFacts()) = DeterministicReview(
        facts = facts, entities = emptyList(), bookings = emptyList(), parents = emptyList(),
        relationships = emptyList(), findings = emptyList(),
    )
}
