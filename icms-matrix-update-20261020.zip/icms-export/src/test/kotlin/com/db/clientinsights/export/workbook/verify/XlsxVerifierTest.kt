package com.db.clientinsights.export.workbook.verify

import com.db.clientinsights.export.RuleCorpus
import com.db.clientinsights.export.TEST_CLOCK
import com.db.clientinsights.export.TEST_PRODUCER
import com.db.clientinsights.export.adapters.bundle.ExportCollectionWriter
import com.db.clientinsights.export.application.CohortExportService
import com.db.clientinsights.export.application.ExportService
import com.db.clientinsights.export.domain.ExportRequest
import com.db.clientinsights.export.entityId
import com.db.clientinsights.export.ports.ReviewCohortSource
import com.db.clientinsights.export.workbook.ChartXml
import com.db.clientinsights.export.workbook.CollectionData
import com.db.clientinsights.export.workbook.ReviewData
import com.db.clientinsights.export.workbook.ReviewJoin
import com.db.clientinsights.export.workbook.WorkbookCheckFailure
import com.db.clientinsights.export.workbook.WorkbookContent
import com.db.clientinsights.export.workbook.WorkbookInput
import com.db.clientinsights.export.workbook.WorkbookLayout
import com.db.clientinsights.export.workbook.WorkbookModel
import com.db.clientinsights.export.workbook.XlsxVerifier
import com.db.clientinsights.export.workbook.XlsxWriter
import java.nio.file.Files
import java.nio.file.Path
import java.util.Locale
import java.util.zip.ZipFile
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNotEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.DynamicTest
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.TestFactory
import org.junit.jupiter.api.assertThrows
import org.junit.jupiter.api.io.TempDir

/**
 * XlsxVerifier on synthetic data only: a hand-made workbook (independent of the writer) for the count order and the
 * empty-Bookings case, and the 14-company rule corpus exported by the application itself and taken through input,
 * content and writer, both as a valid workbook and as tampered copies that must each be refused with a message that
 * names only a sheet, cell or part.
 */
class XlsxVerifierTest {
    @TempDir lateinit var temp: Path

    /** A workbook written by the application from the exported rule corpus, with the inputs it was built from. */
    private class Written(val file: Path, val collection: CollectionData, val review: ReviewData, val model: WorkbookModel)

    /** Exports the rule corpus as one collection (as WorkbookInputGuardsTest does), then reads, joins, builds, writes. */
    private fun writeCorpus(): Written {
        val runId = "verifier-corpus"
        val writer = ExportCollectionWriter(temp.resolve("export-" + System.nanoTime()), runId)
        val service = ExportService(RuleCorpus.icms, RuleCorpus.references, TEST_PRODUCER, clock = TEST_CLOCK,
            reviewSource = RuleCorpus.review)
        val exported = CohortExportService(ReviewCohortSource { _, _ -> error("explicit IDs only") }, service,
            TEST_PRODUCER, clock = TEST_CLOCK)
            .exportSelected(runId, ExportRequest(RuleCorpus.requestedIds.map(::entityId)), 5, writer, 2)
        writer.finish(exported)
        val collection = WorkbookInput.read(writer.directory)
        val review = ReviewJoin.join(collection)
        val model = WorkbookContent.build(collection, review, emptyList(), WorkbookLayout.DRAFT_DECISION_OPTIONS)
        val file = temp.resolve("corpus-" + System.nanoTime() + ".xlsx")
        Files.newOutputStream(file).use { XlsxWriter.write(model, it) }
        return Written(file, collection, review, model)
    }

    private fun verify(w: Written, file: Path = w.file) = XlsxVerifier.verify(file, w.model, w.review, w.collection)

    @Test fun `a hand-made workbook verifies and the counts come back in the agreed order`() {
        val h = HandMadeWorkbook(withBookings = true)
        val counts = XlsxVerifier.verify(h.write(temp.resolve("hand.xlsx")), h.model, h.review, h.collection)
        assertEquals(COUNT_KEYS, counts.keys.toList())
        assertEquals(2, counts["companyRows"])
        assertEquals(1, counts["candidateRows"])
        assertEquals(3L, counts["bookingTableRows"])
        assertEquals(1, counts["unassignedBookings"])
        assertEquals(12, counts["blankReviewerCells"])
        assertEquals(8, counts["blankTeamDecisionCells"])
        assertEquals(listOf("Summary!B11"), counts["worksheetFormulaCells"])
        assertEquals(3, counts["definedNames"])
        assertEquals(2, counts["hyperlinks"])
        assertEquals(2, counts["dataValidations"])
        assertEquals(2, counts["conditionalFormats"])
        assertEquals(3, counts["chartReferences"])
        assertEquals(3, counts["autoFilters"])
        assertEquals(11, counts["ignoredErrorRanges"])
        assertEquals(0, counts["mainParentTokens"])
    }

    @Test fun `zero bookings verifies with no links and no Bookings ignoredErrors`() {
        val h = HandMadeWorkbook(withBookings = false)
        val counts = XlsxVerifier.verify(h.write(temp.resolve("empty.xlsx")), h.model, h.review, h.collection)
        assertEquals(0L, counts["bookingTableRows"])
        assertEquals(0, counts["hyperlinks"])
        assertEquals(1, counts["definedNames"])
        assertEquals(3, counts["autoFilters"])
        assertEquals(1, counts["ignoredErrorRanges"])
    }

    @Test fun `the exported rule corpus verifies end to end`() {
        val w = writeCorpus()
        val counts = verify(w)
        assertEquals(COUNT_KEYS, counts.keys.toList())
        assertEquals(w.review.companies.size, counts["companyRows"])
        assertEquals(w.review.candidateCount, counts["candidateRows"])
        assertEquals(w.collection.exportedBookingCount, counts["bookingTableRows"])
        assertEquals(w.model.jumps.size, counts["hyperlinks"])
        assertEquals(1 + w.model.jumps.size, counts["definedNames"])
        assertEquals(listOf("Summary!B${w.model.progressRow}"), counts["worksheetFormulaCells"])
        assertTrue(w.model.jumps.size >= 2) { "the corpus needs at least two links for the tamper cases" }
    }

    @Test fun `a default locale with non-Latin digits still writes and verifies ASCII jump names and keys`() {
        val saved = Locale.getDefault()
        try {
            Locale.setDefault(Locale.forLanguageTag("ar-EG-u-nu-arab"))
            assertNotEquals("1", String.format("%d", 1)) { "precondition: this locale must format digits as non-Latin" }
            val w = writeCorpus()
            verify(w)
            val clients = w.model.jumps.filter { it.parentId == null }
            val parents = w.model.jumps.filter { it.parentId != null }
            assertTrue(clients.isNotEmpty() && parents.isNotEmpty()) { "the corpus needs a client and a parent link" }
            assertTrue(clients.all { CLIENT_NAME.matches(it.name) && CLIENT_KEY.matches(it.key) })
            assertTrue(parents.all { PARENT_NAME.matches(it.name) && PARENT_KEY.matches(it.key) })
            assertEquals("jump_client_0001" to "C0001", clients.first().name to clients.first().key)
            assertEquals("jump_parent_0001_0001" to "C0001-P0001", parents.first().name to parents.first().key)
        } finally {
            Locale.setDefault(saved)
        }
    }

    @Test fun `verifying against reordered source data is refused`() {
        val w = writeCorpus()
        val c = w.collection
        val reversed = ReviewData(w.review.companies.reversed(), w.review.unknownSignals, w.review.unknownRelationshipTypes,
            w.review.globalIssues, w.review.batchLimitations)
        val reordered = CollectionData(c.dir, c.inputKind, c.manifestName, c.manifestSha256, c.runId, c.startedAt,
            c.finishedAt, c.extractionStatus, c.discoveryStatus, c.selection, c.crossSourceAtomicSnapshot,
            c.exportedBookingCount, c.bookingStatus, c.producerVersion, c.producerRevision, c.producerDirty,
            c.evidenceSchema, c.cohort.reversed(), c.batches)
        val failure = assertThrows<WorkbookCheckFailure> { XlsxVerifier.verify(w.file, w.model, reversed, reordered) }
        assertSafeMessage(failure.message, w.review)
    }

    @Test fun `an extra package part is refused`() {
        val w = writeCorpus()
        val parts = readParts(w.file)
        parts["xl/vbaProject.bin"] = "x"
        val failure = assertThrows<WorkbookCheckFailure> { verify(w, zipParts(parts, temp.resolve("extra.xlsx"))) }
        assertSafeMessage(failure.message, w.review)
    }

    /** Each tamper edits one part of a valid corpus workbook; the verifier must refuse every copy. */
    @TestFactory fun `tampered copies are refused`(): List<DynamicTest> {
        val w = writeCorpus()
        val (first, second) = w.model.jumps
        val tampers = linkedMapOf<String, (MutableMap<String, String>) -> Unit>(
            "changed cell text" to { it.edit(MAIN, Regex("(<c r=\"C2\"[^>]*><is><t xml:space=\"preserve\">)")) { m -> m.value + "x" } },
            "extra cell" to { it.edit(MAIN, "<c r=\"P2\" s=\"${WorkbookLayout.S_INPUT_DATE}\"/></row>",
                "<c r=\"P2\" s=\"${WorkbookLayout.S_INPUT_DATE}\"/><c r=\"Q2\" s=\"0\"/></row>") },
            "filled reviewer cell" to { it.edit(MAIN, "<c r=\"M2\" s=\"${WorkbookLayout.S_INPUT}\"/>",
                "<c r=\"M2\" s=\"${WorkbookLayout.S_INPUT}\"><v>1</v></c>") },
            "second worksheet formula" to { it.edit(SUMMARY, Regex("<c r=\"B${w.model.chart.firstRow}\" s=\"\\d+\">")) { m -> m.value + "<f>0</f>" } },
            "external relationship" to { it.edit("xl/worksheets/_rels/sheet1.xml.rels", "/>", " TargetMode=\"External\"/>") },
            "hyperlink with r:id" to { it.edit(MAIN, "<hyperlink ref=\"${first.cellRef}\"", "<hyperlink r:id=\"rId9\" ref=\"${first.cellRef}\"") },
            "wrong jump target" to { it.edit(MAIN, "location=\"${first.name}\"", "location=\"${second.name}\"") },
            "jump key changed on a Bookings row" to { it.edit(BOOKINGS, Regex("(<c r=\"AE2\"[^>]*><is><t xml:space=\"preserve\">)[^<]*")) { m -> m.groupValues[1] + "C9999" } },
            "changed jump formula" to { it.edit("xl/workbook.xml", "MATCH(&quot;${first.key}&quot;", "MATCH(&quot;C9999&quot;") },
            "extra data validation" to { it.edit(MAIN, "</dataValidations>",
                "<dataValidation type=\"whole\" sqref=\"N2\"><formula1>1</formula1></dataValidation></dataValidations>") },
            "other ignored error type" to { it.edit(BOOKINGS, "numberStoredAsText=\"1\"", "numberStoredAsText=\"1\" formula=\"1\"") },
            "AutoFilter on Company review" to { it.edit(MAIN, "<conditionalFormatting", "<autoFilter ref=\"A1:P2\"/><conditionalFormatting") },
            "MAIN_PARENT text" to { it.edit(RULES, "<t xml:space=\"preserve\">", "<t xml:space=\"preserve\">MAIN_PARENT ") },
            "MAIN_PARENT behind a character reference" to { it.edit(CHART, ChartXml.TITLE, "MAIN&#95;PARENT") },
            "chart cache differs" to { it.edit(CHART, Regex("(<c:numCache>.*?<c:pt idx=\"0\"><c:v>)(\\d+)")) { m ->
                m.groupValues[1] + (m.groupValues[2].toLong() + 1) } },
            "fourth chart reference" to { it.edit(CHART, "</c:ser>", "</c:ser><c:extra><c:f>Summary!\$A\$1</c:f></c:extra>") },
            "1904 date system" to { it.edit("xl/workbook.xml", "<bookViews>", "<workbookPr date1904=\"1\"/><bookViews>") },
            "DOCTYPE" to { it.edit("xl/workbook.xml", "<workbook ", "<!DOCTYPE workbook [<!ENTITY x \"y\">]><workbook ") },
            "visible detail row" to { it.edit(MAIN, "<row r=\"3\" hidden=\"1\" outlineLevel=\"1\"", "<row r=\"3\" outlineLevel=\"1\"") },
            "missing booking row" to { it.edit(BOOKINGS, Regex("<row r=\"2\"[^>]*>.*?</row>")) { "" } },
        )
        assertEquals(20, tampers.size)
        return tampers.map { (name, tamper) ->
            DynamicTest.dynamicTest(name) {
                val parts = readParts(w.file)
                tamper(parts)
                val copy = zipParts(parts, temp.resolve("tampered-" + System.nanoTime() + ".xlsx"))
                val failure = assertThrows<WorkbookCheckFailure> { verify(w, copy) }
                assertSafeMessage(failure.message, w.review)
            }
        }
    }

    /** The message names a sheet or package part and contains no business value (IDs, record IDs, names). */
    private fun assertSafeMessage(message: String?, review: ReviewData) {
        val text = message.orEmpty()
        assertTrue(WorkbookLayout.SHEETS.any { it in text } || WorkbookLayout.PARTS.any { it in text } || "package" in text ||
            "client order" in text) { "message names no sheet or part: $text" }
        val tokens = text.split(Regex("[^A-Za-z0-9_-]+")).toSet()
        val ids = review.companies.flatMap { c ->
            listOf(c.id) + c.candidates.map { it.parentId } + c.bookings.map { it.record["booking_record_id"] }
        }.filter { it.isNotEmpty() }
        assertTrue(ids.none { it in tokens }) { "message contains a business ID: $text" }
        val names = review.companies.map { it.entity["entity_name"] }.filter { it.length >= 4 }
        assertTrue(names.none { it in text }) { "message contains a business name: $text" }
    }

    private fun readParts(file: Path): MutableMap<String, String> = ZipFile(file.toFile()).use { zip ->
        zip.entries().asSequence().associateTo(LinkedHashMap()) { e ->
            e.name to zip.getInputStream(e).use { String(it.readAllBytes(), Charsets.UTF_8) }
        }
    }

    private fun zipParts(parts: Map<String, String>, file: Path): Path = HandMadeWorkbook(withBookings = false).zip(parts, file)

    private fun MutableMap<String, String>.edit(part: String, old: String, new: String) {
        val text = getValue(part)
        check(old in text) { "tamper anchor not found in $part" }
        this[part] = text.replaceFirst(old, new)
    }

    private fun MutableMap<String, String>.edit(part: String, pattern: Regex, replace: (MatchResult) -> String) {
        val text = getValue(part)
        val match = pattern.find(text) ?: error("tamper anchor not found in $part")
        this[part] = text.replaceRange(match.range, replace(match))
    }

    private companion object {
        const val SUMMARY = "xl/worksheets/sheet1.xml"
        const val MAIN = "xl/worksheets/sheet2.xml"
        const val BOOKINGS = "xl/worksheets/sheet3.xml"
        const val RULES = "xl/worksheets/sheet4.xml"
        const val CHART = "xl/charts/chart1.xml"
        val CLIENT_NAME = Regex("jump_client_[0-9]{4}")
        val PARENT_NAME = Regex("jump_parent_[0-9]{4}_[0-9]{4}")
        val CLIENT_KEY = Regex("C[0-9]{4}")
        val PARENT_KEY = Regex("C[0-9]{4}-P[0-9]{4}")
        val COUNT_KEYS = listOf("sheets", "companyRows", "companyDetailRows", "candidateRows", "parentDetailRows",
            "companiesWithoutCandidates", "bookingTableRows", "companiesWithoutBookings", "unassignedBookings",
            "currentRecordsReconciled", "reviewInputRows", "blankReviewerCells", "blankTeamDecisionCells",
            "cellsRoundTripped", "worksheetFormulaCells", "definedNames", "hyperlinks", "dataValidations",
            "conditionalFormats", "chartReferences", "autoFilters", "ignoredErrorRanges", "mainParentTokens",
            "unknownSignals", "unknownRelationshipTypes", "companyOrderSha256")
    }
}
