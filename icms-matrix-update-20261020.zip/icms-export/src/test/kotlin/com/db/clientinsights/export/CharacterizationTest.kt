package com.db.clientinsights.export

import com.db.clientinsights.export.adapters.bundle.EvidenceBundleWriter
import com.db.clientinsights.export.adapters.fixture.FixtureData
import com.db.clientinsights.export.adapters.fixture.FixtureSources
import com.db.clientinsights.export.adapters.icms.JdbcQueryExecutor
import com.db.clientinsights.export.adapters.icms.OracleIcmsReferenceSource
import com.db.clientinsights.export.adapters.icms.OracleIcmsSource
import com.db.clientinsights.export.adapters.icms.OracleReviewDataSource
import com.db.clientinsights.export.adapters.serialization.EvidenceJson
import com.db.clientinsights.export.application.ExportService
import com.db.clientinsights.export.domain.*
import com.db.clientinsights.export.ports.IcmsReferenceSource
import com.db.clientinsights.export.ports.IcmsSource
import com.db.clientinsights.export.ports.ReviewDataSource
import java.nio.file.Files
import java.nio.file.Path
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.io.TempDir

/**
 * Safety net for refactoring: every artifact the export writes for fixed inputs must match an accepted
 * snapshot. Clocks, run ID and producer are fixed. The only volatile values are the generated UUIDs of the
 * bundle's own query runs; each becomes query-run-1, query-run-2, ... in query order wherever it appears.
 * Nothing else is normalized: statuses, business dates, entity, booking and party IDs, SQL template
 * hashes and evidence links must stay exactly as they are.
 *
 * When a snapshot differs, the new output is written to build/characterization/. To accept an intended
 * change, review its diff and copy the file to src/test/resources/characterization/.
 */
class CharacterizationTest {
    @TempDir lateinit var temporary: Path

    @Test fun `snapshots replace only the bundle's own query-run IDs`() {
        val lookalike = "123e4567-e89b-42d3-a456-426614174000"
        val system = IcmsSettlementSystemId("10")
        val source = FixtureSources(FixtureData(entities = listOf(IcmsEntity(entityId("101"), lookalike, "Active")),
            bookingRecords = listOf(BookingRecord(id = "1", entityId = entityId("101"), bookingCode = lookalike,
                settlementSystemId = system, settlementMethodId = "1", assignedCrdsPartyId = CrdsPartyId("99"),
                status = "Active")),
            bookingSystems = listOf(BookingSystem(system, "Synthetic system", CrdsSystemId("150"))),
            settlementMethods = listOf(SettlementMethod("1", "Synthetic method"))), TEST_CLOCK)
        val bundle = export(source, source, null, listOf("101"))
        val text = snapshot(EvidenceBundleWriter().write(bundle, temporary), bundle.queries)
        assertTrue(text.contains("\n101,FOUND,$lookalike,"), "A UUID-shaped entity name is a business value")
        assertTrue(text.contains("\n1,101,$lookalike,"), "A UUID-shaped booking code is a business value")
        assertTrue(bundle.queries.none { text.contains(it.queryRunId) })
        assertEquals(bundle.queries.indices.map { "query-run-${it + 1}" }.toSet(),
            Regex("query-run-[0-9]+").findAll(text).map { it.value }.toSet())
    }

    @Test fun `demo fixture export matches its snapshot`() {
        val data = EvidenceJson.format.decodeFromString<FixtureData>(resource("/fixtures/demo.json"))
        val demo = FixtureSources(data, TEST_CLOCK)
        assertMatchesSnapshot("demo-fixture", export(demo, demo, demo.reviewSource, listOf("101", "102", "103", "404")))
    }

    @Test fun `rule corpus export matches its snapshot`() {
        assertMatchesSnapshot("rule-corpus", corpusExport())
    }

    @Test fun `rule corpus reaches every rule outcome`() {
        val review = checkNotNull(corpusExport().review)
        assertEquals(setOf("UNKNOWN", "NOT_APPLICABLE", "MULTIPLE_PARENTS", "ONE_PARENT", "NO_CURRENT_PARENT"),
            review.entities.map { it.currentRuleStatus }.toSet())
        assertEquals(setOf("UNAVAILABLE", "NO_CRDS_SYSTEM", "CURRENT_PATH", "NO_CURRENT_PATH", "NO_CRDS_PATH"),
            review.bookings.map { it.resolution }.toSet())
        assertEquals(setOf("MISSING", "UNAVAILABLE", "NO_RHP", "SAME_AS_RHP", "DIFFERS_FROM_RHP"),
            review.bookings.map { it.assignedCrdsIdCheck }.toSet())
        assertEquals(setOf("UNAVAILABLE", "NO_RHP", "AMBIGUOUS", "NOT_IN_SALESFORCE", "NO_REPORTING_GROUP",
            "SAME_AS_ULTIMATE", "SAME_AS_RHP", "NAME_MATCH", "DIFFERENT"), review.bookings.map { it.reportingGroupCheck }.toSet())
        assertEquals(setOf("NOT_CURRENT", "CURRENT_PARENT", "HIDDEN_BY_REPORT", "ONLY_INACTIVE_LINKS", "ONLY_SHARED_KEYS",
            "MINOR_SHARE", "SAME_AS_ENTITY", "NAME_LIKE_ENTITY", "PARENT_IS_DEUTSCHE_BANK", "NAME_MISSING", "PARTY_INACTIVE",
            "MERGED_INTO_OTHER_PARTY", "NOT_TOP_OF_OWN_HIERARCHY", "TIED_SELECTION", "INCOMPLETE_EVIDENCE", "MAIN_PARENT"),
            review.parents.flatMap { it.signals }.toSet())
        assertEquals(setOf("CURRENT_RULE_INCOMPLETE", "MULTIPLE_CURRENT_PARENTS", "BASELINE_CURRENT_DIFFERENCE",
            "MULTIPLE_CURRENT_PARENTS_ON_KEY", "TIED_BASELINE_SELECTION", "BOOKING_KEYS_WITHOUT_CRDS_PATH", "NO_CURRENT_PATH",
            "NO_CRDS_PATH", "ASSIGNED_CRDS_DIFFERS_FROM_RHP", "REPORTING_GROUP_DIFFERENT", "REPORTING_GROUP_NAME_MATCH",
            "REPORTING_GROUP_SAME_AS_RHP", "REPORTING_GROUP_NO_REPORTING_GROUP", "REPORTING_GROUP_AMBIGUOUS",
            "NO_SETTLEMENT_ROUTING", "ROUTING_ACCOUNT_MISSING"), review.findings.map { it.ruleId }.toSet())
        assertEquals(setOf(emptyList(), listOf("BLOCK"), listOf("FUND"), listOf("BLOCK", "FUND")),
            review.bookings.map { it.routingAccountTypes }.toSet())
        assertEquals(setOf(true, false, null), review.entities.map { it.flaggedByCurrentRule }.toSet())
        // Each tri-state count is unknown for at least one entity or booking and known for another.
        listOf<Pair<String, List<Any?>>>(
            "current parents" to review.entities.map { it.currentParentCount },
            "baseline parents" to review.entities.map { it.reportParentCount },
            "keys without path" to review.entities.map { it.keysWithoutPath },
            "shared keys" to review.entities.map { it.sharedKeyCount },
            "settlement routings" to review.bookings.map { it.settlementRoutingCount },
        ).forEach { (name, values) ->
            assertTrue(null in values && values.any { it != null }, "$name must be both known and unknown")
        }
    }

    @Test fun `rule corpus ranks parent candidates by every review-order key`() {
        val parents = checkNotNull(corpusExport().review).parents.filter { it.entityId.value == "614" }
        // Current records first, then Active-link keys, then keys, then numeric parent ID.
        assertEquals(listOf("7701", "7700", "780", "1001", "990"), parents.map { it.parentId })
    }

    @Test fun `SQL export of mapped entities matches its snapshot`() {
        TestDatabase().use { db ->
            installReviewSchema(db)
            seedMappedEntities(db)
            assertMatchesSnapshot("sql-mapped-entities", sqlExport(db, (248..256).map { "$it" }, pageSize = 2))
        }
    }

    @Test fun `SQL export when the cRDS path source fails matches its snapshot`() {
        TestDatabase().use { db ->
            installReviewSchema(db)
            db.execute("INSERT INTO PRD_EXPORT_LEGAL_ENTITY VALUES (248, 'Synthetic missing cRDS', 'Active')")
            seedBooking(db, 1, 248, "ONE")
            seedReviewPath(db, 1, "ONE", 11, 100)
            db.execute("DROP TABLE CRDS_BR_ACCOUNT_XREF")
            assertMatchesSnapshot("sql-crds-paths-unavailable", sqlExport(db, listOf("248")))
        }
    }

    @Test fun `SQL export when optional sources fail matches its snapshot`() {
        TestDatabase().use { db ->
            installReviewSchema(db)
            db.execute("INSERT INTO PRD_EXPORT_LEGAL_ENTITY VALUES (248, 'Synthetic unavailable sources', 'Active')")
            seedBooking(db, 1, 248, "ONE")
            seedReviewPath(db, 1, "ONE", 11, 100)
            db.execute("DROP TABLE PRD_EXPORT_CLIENT_REP_HIERARCHY_V6; DROP TABLE PRD_EXPORT_SETTLEMENT_ROUTING; DROP TABLE PS_TRADE")
            assertMatchesSnapshot("sql-optional-sources-unavailable", sqlExport(db, listOf("248")))
        }
    }

    /** Entities 248-255 are all reachable through mapped bookings; 256 does not exist. */
    private fun seedMappedEntities(db: TestDatabase) {
        db.execute("""
            INSERT INTO PRD_EXPORT_LEGAL_ENTITY VALUES (248, 'Synthetic baseline versus current', 'Active'),
              (249, 'Synthetic Howard case', 'Active'), (250, 'Synthetic tie case', 'Active'),
              (251, 'Synthetic inactive case', 'Inactive'), (252, 'Synthetic key without path', 'Active'),
              (253, 'Synthetic mixed mapping', 'Active'), (254, 'Synthetic shared key A', 'Active'),
              (255, 'Synthetic shared key B', 'Active');
            INSERT INTO T_CRDS_BOOKING_SYSTEM VALUES (20, 'Synthetic system without cRDS ID', NULL);
        """.trimIndent())
        // 248: one current parent, while the baseline also counts a parent reached by an inactive link.
        seedBooking(db, 1, 248, "CURRENT"); seedBooking(db, 2, 248, "HISTORICAL")
        seedReviewPath(db, 1, "CURRENT", 11, 100)
        seedReviewPath(db, 2, "HISTORICAL", 12, 200, accountStatus = "INACTIVE")
        // 249: the Howard case. Three codes, reporting-level Salesforce rows, a blocked routing and bank identity.
        seedBooking(db, 3, 249, "FCOMMERWTS", 300); seedBooking(db, 4, 249, "FPNBEDELF1", 301)
        seedBooking(db, 5, 249, "FPNBEDELF2", 301)
        seedReviewPath(db, 3, "FCOMMERWTS", 300, 300)
        seedReviewPath(db, 4, "FPNBEDELF1", 301, 400)
        seedReviewPath(db, 5, "FPNBEDELF2", 301, 400)
        db.execute("""
            INSERT INTO PRD_EXPORT_CLIENT_REP_HIERARCHY_V6 (crds_id, name, legal_ultimate_parent_crds_id, rep_group_crds_id, is_reporting_level, l1_crds_id, l3_crds_id)
              VALUES ('300', 'Synthetic Group A', '300', '999', 1, '300', '300'), ('301', 'Synthetic Group B', '400', '999', 1, '400', '301');
            INSERT INTO PRD_EXPORT_ACCOUNT VALUES (50, 249);
            INSERT INTO PRD_EXPORT_SETTLEMENT_ROUTING VALUES (1, 249, 'FCOMMERWTS', 10, 3, 'Active', 50, 'BLOCK', TIMESTAMP '2026-01-01 00:00:00', TIMESTAMP '2025-01-01 00:00:00');
            INSERT INTO CRDS_DIF_PARTY_IDENTIFIERS VALUES (300, 'SYNTHETIC-LEI', 'LEI', TIMESTAMP '2020-01-01 00:00:00', NULL, TIMESTAMP '2027-01-01 00:00:00', TIMESTAMP '2026-01-01 00:00:00');
            INSERT INTO T_CRDS_PARTY_LOCAL_CACHE VALUES (300, 'SYNTHETIC-LEI', 'Synthetic group', 'DE', 'SYNTHETICBIC', 'ACTIVE', TIMESTAMP '2026-01-01 00:00:00');
            INSERT INTO CRDS_DIF_PARTY_ADDRESS VALUES (300, 'LEGAL', 'Synthetic street', NULL, NULL, NULL, '00000', 'DE');
            INSERT INTO PS_TRADE VALUES ('dummy');
        """.trimIndent())
        // 250: two current paths with equal recency; the lowest parent ID is selected.
        seedBooking(db, 6, 250, "TIE")
        seedReviewPath(db, 6, "TIE", 13, 600)
        seedReviewPath(db, 7, "TIE", 14, 500)
        // 251: an Inactive entity whose paths are historical (ended hierarchy, inactive relationship).
        seedBooking(db, 7, 251, "ENDED"); seedBooking(db, 8, 251, "INACTIVE-BR")
        seedReviewPath(db, 8, "ENDED", 15, 700, ended = true)
        seedReviewPath(db, 9, "INACTIVE-BR", 16, 800, relationshipStatus = "INACTIVE")
        // 252: a mapped booking with no cRDS path.
        seedBooking(db, 9, 252, "NO-PATH")
        // 253: one mapped booking with a path, one on a system row without a cRDS ID, one on an unknown system.
        seedBooking(db, 10, 253, "MAPPED")
        seedReviewPath(db, 10, "MAPPED", 17, 900)
        db.execute("""
            INSERT INTO PRD_EXPORT_BOOKING_CODE (id, le_id, booking_code, settlement_system_id, settlement_method, crds_id, status)
              VALUES (11, 253, 'NO-CRDS-ID', 20, 1, '17', 'Active'), (12, 253, 'UNKNOWN-SYSTEM', 99, 1, '17', 'Active');
        """.trimIndent())
        // 254 and 255 book the same key.
        seedBooking(db, 13, 254, "SHARED"); seedBooking(db, 14, 255, "SHARED")
        seedReviewPath(db, 11, "SHARED", 18, 1000)
    }

    private fun corpusExport() = export(RuleCorpus.icms, RuleCorpus.references, RuleCorpus.review, RuleCorpus.requestedIds)

    private fun sqlExport(db: TestDatabase, ids: List<String>, pageSize: Int = 1000): EvidenceBundle {
        val executor = JdbcQueryExecutor("test", "", db.connections, QueryLimits(pageSize = pageSize),
            adapter = "h2-test", clock = TEST_CLOCK)
        return export(OracleIcmsSource(executor), OracleIcmsReferenceSource(executor), OracleReviewDataSource { executor }, ids)
    }

    private fun export(icms: IcmsSource, references: IcmsReferenceSource, review: ReviewDataSource?, ids: List<String>) =
        ExportService(icms, references, TEST_PRODUCER, clock = TEST_CLOCK, runId = { "characterization" },
            reviewSource = review).extract(ExportRequest(ids.map(::entityId)))

    private fun assertMatchesSnapshot(name: String, bundle: EvidenceBundle) {
        assertReferencesResolve(bundle)
        val actual = snapshot(EvidenceBundleWriter().write(bundle, temporary), bundle.queries)
        val expected = javaClass.getResource("/characterization/$name.txt")?.readText()
        if (actual == expected) return
        val written = Path.of("build", "characterization", "$name.txt")
        Files.createDirectories(written.parent)
        Files.writeString(written, actual)
        fail<Unit>("${firstDifference(expected, actual)} New output: ${written.toAbsolutePath()}")
    }

    /** Every evidence, query-run and issue reference points at a record of the same bundle. */
    private fun assertReferencesResolve(bundle: EvidenceBundle) {
        val review = bundle.review
        val origins = with(bundle.facts) {
            entities.map { it.origin } + bookingRecords.map { it.origin } + bookingSystems.map { it.origin } +
                settlementMethods.map { it.origin }
        } + review?.facts?.let { f ->
            listOf(f.paths, f.currentBookings, f.parties, f.salesforce, f.routings, f.sharedKeys, f.identities,
                f.assignments, f.routingLineage, f.platformNames, f.platformNativeBookings, f.allStatusPaths,
                f.usageEvidence.contacts, f.usageEvidence.confirmations, f.usageEvidence.trading).flatten().map { it.origin }
        }.orEmpty()
        val evidence = origins.map { it.evidenceId }.toSet()
        val runs = bundle.queries.map { it.queryRunId }.toSet()
        val issues = bundle.issues.map { it.issueId }.toSet()
        val links = buildList {
            bundle.issues.forEach { add(it.evidenceIds to it.queryRunIds) }
            review?.entities?.forEach { add(it.evidenceIds to it.queryRunIds) }
            review?.bookings?.forEach { add(it.evidenceIds to it.queryRunIds) }
            review?.parents?.forEach { add(it.evidenceIds to it.queryRunIds) }
            review?.relationships?.forEach { add(it.evidenceIds to it.queryRunIds) }
            review?.identitySelections?.forEach { add(it.evidenceIds to it.queryRunIds) }
            review?.platformNames?.entities?.forEach { add(it.evidenceIds to it.queryRunIds) }
            review?.platformNames?.assessments?.forEach { add(it.nativeEvidenceIds + it.platformEvidenceId to it.queryRunIds) }
            review?.themeB6?.bookings?.forEach { add(it.evidenceIds to it.queryRunIds) }
            review?.themeB6?.rhpSummaries?.forEach { add(it.evidenceIds to it.queryRunIds) }
            review?.themeB6?.parentSummaries?.forEach { add(it.evidenceIds to it.queryRunIds) }
            review?.usage?.contacts?.forEach { add(it.evidenceIds to it.queryRunIds) }
            review?.usage?.bookings?.forEach { add(it.evidenceIds to it.queryRunIds) }
        }
        fun assertKnown(kind: String, references: List<String>, known: Set<String>) {
            val unknown = references.filterNot { it in known }.distinct()
            assertTrue(unknown.isEmpty(), "Unresolved $kind references: $unknown")
        }
        assertKnown("evidence", links.flatMap { it.first }, evidence)
        assertKnown("query run", links.flatMap { it.second } + origins.map { it.queryRunId } +
            bundle.entities.flatMap { it.queryRunIds }, runs)
        assertKnown("issue", bundle.entities.flatMap { it.issueIds } + bundle.bookings.flatMap { it.issueIds }, issues)
    }

    /**
     * All written artifacts in manifest order. CSV byte order marks and CRLF line ends are shown as plain text,
     * and JSON is re-wrapped so that short values stay on one line; the manifest's byte counts pin the exact files.
     * Artifact hashes change with every generated query-run ID, so they are the one masked manifest field.
     */
    private fun snapshot(directory: Path, queryRuns: List<QueryRun>): String {
        val manifest = EvidenceJson.format.decodeFromString<RunManifest>(Files.readString(directory.resolve("run-manifest.json")))
        val text = (manifest.artifacts.map { it.filename } + "run-manifest.json").joinToString("") { file ->
            val content = Files.readString(directory.resolve(file))
            val shown = if (file.endsWith(".json")) wrap(EvidenceJson.format.parseToJsonElement(content))
                else content.removePrefix("﻿").replace("\r\n", "\n").trimEnd('\n')
            "=== $file\n$shown\n"
        }.replace(ARTIFACT_HASH, "\"sha256\":\"(hash of the artifact as written)\"")
        val generated = queryRuns.map { it.queryRunId }.filter { GENERATED_ID.matches(it) }.distinct()
        val tokens = generated.withIndex().associate { (index, id) -> id to "query-run-${index + 1}" }
        return GENERATED_ID.replace(text) { match -> tokens[match.value] ?: match.value }
    }

    /**
     * One record per line: each object in a list is printed compactly on its own line, and any other object
     * longer than [JSON_WIDTH] characters is split into one member per line.
     */
    private fun wrap(element: JsonElement, indent: String = ""): String {
        val inner = "$indent  "
        return when {
            element is JsonArray && element.isNotEmpty() && element.all { it is JsonObject } ->
                element.joinToString(",\n", "[\n", "\n$indent]") { "$inner$it" }
            element is JsonObject && indent.length + element.toString().length > JSON_WIDTH ->
                element.entries.joinToString(",\n", "{\n", "\n$indent}") { (key, value) ->
                    "$inner${JsonPrimitive(key)}:${wrap(value, inner)}"
                }
            else -> element.toString()
        }
    }

    private fun firstDifference(expected: String?, actual: String): String {
        if (expected == null) return "No accepted snapshot exists yet."
        val before = expected.lines()
        val after = actual.lines()
        val line = (0 until maxOf(before.size, after.size)).first { before.getOrNull(it) != after.getOrNull(it) }
        return "Snapshot differs at line ${line + 1}: expected <${before.getOrNull(line)}> but was <${after.getOrNull(line)}>."
    }

    private fun resource(path: String): String = checkNotNull(javaClass.getResource(path)) { "Missing $path" }.readText()

    private companion object {
        const val JSON_WIDTH = 160
        /** Shape of the random UUIDs that the JDBC and fixture adapters give each query run. */
        val GENERATED_ID = Regex("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")
        val ARTIFACT_HASH = Regex("\"sha256\":\"[0-9a-f]{64}\"")
    }
}
