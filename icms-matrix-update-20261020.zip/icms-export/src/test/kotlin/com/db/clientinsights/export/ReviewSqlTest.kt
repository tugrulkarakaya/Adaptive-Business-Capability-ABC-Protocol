package com.db.clientinsights.export

import com.db.clientinsights.export.adapters.icms.*
import com.db.clientinsights.export.adapters.bundle.EvidenceBundleWriter
import com.db.clientinsights.export.adapters.serialization.EvidenceJson
import com.db.clientinsights.export.application.ExportService
import com.db.clientinsights.export.domain.*
import java.nio.file.Files
import java.nio.file.Path
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.io.TempDir

class ReviewSqlTest {
    @TempDir lateinit var temporary: Path

    @Test fun `baseline selection excludes single-parent cases while current rule excludes historical paths`() {
        TestDatabase().use { db ->
            installReviewSchema(db)
            db.execute("INSERT INTO PRD_EXPORT_LEGAL_ENTITY VALUES (248, 'Synthetic historical case', 'Active'), (300, 'Synthetic clean case', 'Active')")
            seedBooking(db, 1, 248, "CURRENT"); seedBooking(db, 2, 248, "HISTORICAL")
            seedBooking(db, 3, 300, "SINGLE")
            seedReviewPath(db, 1, "CURRENT", 11, 100)
            seedReviewPath(db, 2, "HISTORICAL", 12, 200, accountStatus = "INACTIVE")
            seedReviewPath(db, 3, "SINGLE", 13, 100)
            val executor = JdbcQueryExecutor("test", "", db.connections, QueryLimits(pageSize = 1), adapter = "h2-test")
            db.connections.open().use { connection ->
                connection.prepareStatement(SqlTemplate("review-cohort").render("", 0, 2)).use { statement ->
                    statement.setNull(1, java.sql.Types.NUMERIC); statement.setNull(2, java.sql.Types.NUMERIC)
                    statement.executeQuery().close()
                }
            }
            val selection = OracleReviewCohortSource(executor).discoverFlaggedEntities(null, 1)
            assertEquals(FetchStatus.COMPLETE, selection.query.status, selection.query.toString())
            assertEquals(listOf(entityId("248")), selection.entityIds)
            assertNull(selection.nextAfterId)
            val bundle = reviewService(executor).extract(ExportRequest(listOf(entityId("248"))))
            assertTrue(bundle.queries.all { it.status == FetchStatus.COMPLETE }, bundle.queries.filter { it.status != FetchStatus.COMPLETE }.toString())
            val review = checkNotNull(bundle.review)
            val entity = review.entities.single()
            assertEquals(2, entity.reportParentCount)
            assertEquals(1, entity.currentParentCount)
            assertEquals(false, entity.flaggedByCurrentRule)
            assertEquals("NO_CURRENT_PATH", review.bookings.single { it.bookingRecordId == "2" }.resolution)
            assertTrue(review.parents.single { it.parentId == "200" }.signals.contains("ONLY_INACTIVE_LINKS"))
            assertTrue(review.findings.any { it.ruleId == "BASELINE_CURRENT_DIFFERENCE" })
        }
    }

    @Test fun `Howard three codes resolve reporting-level self groups and preserve all source evidence`() {
        TestDatabase().use { db ->
            installReviewSchema(db)
            db.execute("INSERT INTO PRD_EXPORT_LEGAL_ENTITY VALUES (248, 'Synthetic Howard case', 'Active')")
            val codes = listOf("FCOMMERWTS", "FPNBEDELF1", "FPNBEDELF2")
            codes.forEachIndexed { i, code -> seedBooking(db, i + 1, 248, code, if (i == 0) 100 else 101) }
            seedReviewPath(db, 1, codes[0], 100, 100)
            seedReviewPath(db, 2, codes[1], 101, 200)
            seedReviewPath(db, 3, codes[2], 101, 200)
            db.execute("""
                INSERT INTO PRD_EXPORT_CLIENT_REP_HIERARCHY_V6 (crds_id, name, legal_ultimate_parent_crds_id, rep_group_crds_id, is_reporting_level, l1_crds_id, l3_crds_id)
                  VALUES ('100', 'Synthetic Group A', '100', '999', 1, '100', '100'), ('101', 'Synthetic Group B', '200', '999', 1, '200', '101');
                INSERT INTO PRD_EXPORT_ACCOUNT VALUES (50, 248);
                INSERT INTO PRD_EXPORT_SETTLEMENT_ROUTING VALUES (1, 248, 'FCOMMERWTS', 10, 1, 'Active', 50, 'BLOCK', TIMESTAMP '2026-01-01 00:00:00', TIMESTAMP '2025-01-01 00:00:00');
                INSERT INTO CRDS_DIF_PARTY_IDENTIFIERS VALUES (100, 'SYNTHETIC-LEI', 'LEI', TIMESTAMP '2020-01-01 00:00:00', NULL, TIMESTAMP '2027-01-01 00:00:00', TIMESTAMP '2026-01-01 00:00:00');
                INSERT INTO T_CRDS_PARTY_LOCAL_CACHE VALUES (100, 'SYNTHETIC-LEI', 'Synthetic group', 'DE', 'SYNTHETICBIC', 'ACTIVE', TIMESTAMP '2026-01-01 00:00:00');
                INSERT INTO CRDS_DIF_PARTY_ADDRESS VALUES (100, 'LEGAL', 'Synthetic street', NULL, NULL, NULL, '00000', 'DE');
                INSERT INTO PS_TRADE VALUES ('dummy');
            """.trimIndent())
            val bundle = reviewService(JdbcQueryExecutor("test", "", db.connections, QueryLimits(pageSize = 2), adapter = "h2-test"))
                .extract(ExportRequest(listOf(entityId("248"))))
            assertTrue(bundle.queries.all { it.status == FetchStatus.COMPLETE }, bundle.queries.filter { it.status != FetchStatus.COMPLETE }.toString())
            val review = checkNotNull(bundle.review)
            assertEquals(listOf("100", "101", "101"), review.bookings.map { it.reportingGroupId }, review.bookings.toString() + review.facts.salesforce.toString())
            assertEquals(listOf("SAME_AS_ULTIMATE", "SAME_AS_RHP", "SAME_AS_RHP"), review.bookings.map { it.reportingGroupCheck })
            assertTrue(review.bookings.all { it.reportingLevel == true })
            assertEquals(3, review.facts.identities.size)
            assertEquals("HAS_ROWS", review.facts.activityAvailability.first().accessibility)
            assertTrue(review.bookings.all { it.unused.level == "NOT_DETERMINED" })
            assertEquals(1L, review.bookings.first().lineage?.matchingAssignmentIdCount)
            val directory = EvidenceBundleWriter().write(bundle, temporary)
            assertEquals(3, readCsv(directory.resolve("booking-review.csv")).size)
            val salesforce = readCsv(directory.resolve("salesforce-hierarchy.csv")).first()
            assertEquals("100", salesforce["l1_crds_id"])
            assertEquals("", salesforce["l2_crds_id"])
            assertEquals("100", salesforce["l3_crds_id"])
            val manifest = EvidenceJson.format.decodeFromString<RunManifest>(Files.readString(directory.resolve("run-manifest.json")))
            assertEquals(33, manifest.artifacts.size)
            assertTrue(manifest.artifacts.all { Files.exists(directory.resolve(it.filename)) })
        }
    }

    private fun reviewService(executor: JdbcQueryExecutor) = ExportService(OracleIcmsSource(executor),
        OracleIcmsReferenceSource(executor), TEST_PRODUCER, reviewSource = OracleReviewDataSource { executor })

    @Test fun `ended hierarchy and inactive relationship paths remain historical and cannot qualify an inactive entity`() {
        TestDatabase().use { db ->
            installReviewSchema(db)
            db.execute("INSERT INTO PRD_EXPORT_LEGAL_ENTITY VALUES (248, 'Synthetic inactive case', 'Inactive')")
            seedBooking(db, 1, 248, "ENDED"); seedBooking(db, 2, 248, "INACTIVE-BR")
            seedReviewPath(db, 1, "ENDED", 11, 100, ended = true)
            seedReviewPath(db, 2, "INACTIVE-BR", 12, 200, relationshipStatus = "INACTIVE")
            val review = checkNotNull(reviewService(JdbcQueryExecutor("test", "", db.connections))
                .extract(ExportRequest(listOf(entityId("248")))).review)
            assertEquals("NOT_APPLICABLE", review.entities.single().currentRuleStatus)
            assertEquals(false, review.entities.single().flaggedByCurrentRule)
            assertEquals(true, review.entities.single().flaggedByBaselineReport)
            assertTrue(review.bookings.all { it.resolution == "NO_CURRENT_PATH" })
        }
    }

    @Test fun `current paths choose most recent then lowest parent and RHP while retaining hidden candidates`() {
        TestDatabase().use { db ->
            installReviewSchema(db)
            db.execute("INSERT INTO PRD_EXPORT_LEGAL_ENTITY VALUES (248, 'Synthetic tie case', 'Active')")
            seedBooking(db, 1, 248, "TIE")
            seedReviewPath(db, 1, "TIE", 11, 200)
            seedReviewPath(db, 2, "TIE", 12, 100)
            val review = checkNotNull(reviewService(JdbcQueryExecutor("test", "", db.connections))
                .extract(ExportRequest(listOf(entityId("248")))).review)
            assertEquals("100", review.bookings.single().ultimateParentId)
            assertEquals(2L, review.bookings.single().currentParentsOnKey)
            assertEquals(setOf("100", "200"), review.parents.map { it.parentId }.toSet())
            assertTrue("HIDDEN_BY_REPORT" in review.parents.single { it.parentId == "200" }.signals)
            assertEquals(1, review.entities.single().keysWithSeveralCurrentParents)
        }
    }

    @Test fun `failed optional lookups are unavailable rather than no groups no routings or no trading`() {
        TestDatabase().use { db ->
            installReviewSchema(db)
            db.execute("INSERT INTO PRD_EXPORT_LEGAL_ENTITY VALUES (248, 'Synthetic unavailable sources', 'Active')")
            seedBooking(db, 1, 248, "ONE"); seedReviewPath(db, 1, "ONE", 11, 100)
            db.execute("DROP TABLE PRD_EXPORT_CLIENT_REP_HIERARCHY_V6; DROP TABLE PRD_EXPORT_SETTLEMENT_ROUTING; DROP TABLE PS_TRADE")
            val bundle = reviewService(JdbcQueryExecutor("test", "", db.connections)).extract(ExportRequest(listOf(entityId("248"))))
            val review = checkNotNull(bundle.review)
            assertEquals(FetchStatus.PARTIAL, bundle.extractionStatus)
            assertEquals("UNAVAILABLE", review.bookings.single().reportingGroupCheck)
            assertNull(review.bookings.single().settlementRoutingCount)
            assertEquals("NOT_DETERMINED", review.bookings.single().unused.level)
            assertNull(review.bookings.single().unused.ifNoRecentTrading)
            assertEquals("UNAVAILABLE", review.facts.activityAvailability.first().accessibility)
            assertFalse(review.findings.any { it.ruleId == "NO_SETTLEMENT_ROUTING" })
            assertEquals("ONE_PARENT", review.entities.single().currentRuleStatus)
        }
    }

    @Test fun `non-reporting-level rows never guess a reporting group from the legal ultimate or L1-L25`() {
        TestDatabase().use { db ->
            installReviewSchema(db)
            db.execute("INSERT INTO PRD_EXPORT_LEGAL_ENTITY VALUES (248, 'Synthetic empty reporting group', 'Active')")
            seedBooking(db, 1, 248, "ONE"); seedReviewPath(db, 1, "ONE", 11, 100)
            db.execute("INSERT INTO PRD_EXPORT_CLIENT_REP_HIERARCHY_V6 (crds_id, name, legal_ultimate_parent_crds_id, is_reporting_level, l1_crds_id) VALUES ('11', 'Synthetic reporting row', '100', 0, '100')")
            db.execute("INSERT INTO PRD_EXPORT_CLIENT_REP_HIERARCHY_V6 (crds_id, name) VALUES ('NON_NUMERIC_SOURCE_ROW', 'Unrelated synthetic row')")
            val review = checkNotNull(reviewService(JdbcQueryExecutor("test", "", db.connections))
                .extract(ExportRequest(listOf(entityId("248")))).review)
            assertNull(review.bookings.single().reportingGroupId)
            assertEquals("NO_REPORTING_GROUP", review.bookings.single().reportingGroupCheck)
        }
    }

    @Test fun `core cRDS failure leaves current parent counts unknown instead of zero`() {
        TestDatabase().use { db ->
            installReviewSchema(db)
            db.execute("INSERT INTO PRD_EXPORT_LEGAL_ENTITY VALUES (248, 'Synthetic missing cRDS', 'Active')")
            seedBooking(db, 1, 248, "ONE")
            db.execute("DROP TABLE CRDS_BR_ACCOUNT_XREF")
            val bundle = reviewService(JdbcQueryExecutor("test", "", db.connections)).extract(ExportRequest(listOf(entityId("248"))))
            val entity = checkNotNull(bundle.review).entities.single()
            assertEquals("UNKNOWN", entity.currentRuleStatus)
            assertNull(entity.currentParentCount)
            assertNull(entity.flaggedByCurrentRule)
            assertNull(entity.flaggedByBaselineReport)
            assertEquals(CheckStatus.ERROR, bundle.entities.single().parentReviewStatus)
        }
    }
}
