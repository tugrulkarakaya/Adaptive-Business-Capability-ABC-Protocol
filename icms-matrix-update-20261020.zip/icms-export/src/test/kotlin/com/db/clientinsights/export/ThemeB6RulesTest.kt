package com.db.clientinsights.export

import com.db.clientinsights.export.domain.*
import com.db.clientinsights.export.rules.CheckResults
import com.db.clientinsights.export.rules.ThemeB6Rules
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test

class ThemeB6RulesTest {
    private val rules = ThemeB6Rules()

    @Test fun `all twelve source matrix rows have their own category confidence`() {
        data class Case(val row: Int, val rhp: String?, val parent: String?, val booking: String?,
                        val settlement: Boolean?, val confirmation: Boolean?, val trading: Boolean,
                        val category: String, val confidence: String)
        val cases = listOf(
            Case(1, "INACTIVE", "ACTIVE", null, null, null, false, ThemeB6Rules.INACTIVE_PARTY, "MEDIUM_HIGH"),
            Case(2, "INACTIVE", "ACTIVE", null, null, null, true, ThemeB6Rules.INACTIVE_PARTY, "MEDIUM"),
            Case(3, "DELETED", "IN_LIQUIDATION", null, null, null, false, ThemeB6Rules.INACTIVE_PARTY, "HIGH"),
            Case(4, "DELETED", "IN_LIQUIDATION", null, null, null, true, ThemeB6Rules.INACTIVE_PARTY, "MEDIUM"),
            Case(5, null, null, "SUSPENDED", null, null, false, ThemeB6Rules.INACTIVE_BOOKING, "HIGH"),
            Case(6, null, null, "SUSPENDED", null, null, true, ThemeB6Rules.INACTIVE_BOOKING, "MEDIUM"),
            Case(7, null, null, null, false, false, false, ThemeB6Rules.ROUTING, "HIGH"),
            Case(8, null, null, null, false, false, true, ThemeB6Rules.ROUTING, "LOW"),
            Case(9, null, null, null, true, false, false, ThemeB6Rules.ROUTING, "MEDIUM_HIGH"),
            Case(10, null, null, null, true, true, false, ThemeB6Rules.ROUTING, "MEDIUM"),
            Case(11, null, null, null, true, false, true, ThemeB6Rules.ROUTING, "LOW"),
            Case(12, null, null, null, true, true, true, ThemeB6Rules.ROUTING, "LOW"),
        )
        cases.forEach { c ->
            val assessment = rules.assess(c.rhp, c.parent, c.booking, c.settlement, c.confirmation, c.trading)
                .single { it.category == c.category }
            assertEquals("APPLIES", assessment.result, "row ${c.row}")
            assertEquals(c.confidence, assessment.confidence, "row ${c.row}")
            assertEquals(listOf(c.row), assessment.matrixRows, "row ${c.row}")
        }
    }

    @Test fun `in formation and reactivating are accepted without weakening current parent selection`() {
        val result = rules.assess(" in_formation ", "INACTIVE", "REACTIVATING", null, null, null)
        assertEquals("NO_SIGNAL", result[0].result)
        assertEquals("NO_SIGNAL", result[1].result)
        assertEquals("NOT_DETERMINED", result[2].result)
    }

    @Test fun `missing trading keeps final confidence unknown and exposes both conditional outcomes`() {
        val result = rules.assess("INACTIVE", "ACTIVE", "INACTIVE", false, null, null)
        assertEquals(listOf("MEDIUM_HIGH", "HIGH", "HIGH"), result.map { it.ifNoRecentTrading })
        assertEquals(listOf("MEDIUM", "MEDIUM", "LOW"), result.map { it.ifRecentTrading })
        assertTrue(result.all { it.confidence == null && it.result == "NOT_DETERMINED" })
        assertTrue(result.all { it.missingInputs == listOf("RECENT_TRADING") })
    }

    @Test fun `trading does not reduce inactive categories to routing low confidence`() {
        val result = rules.assess("ABANDONED", "INACTIVE", "DELETED", true, null, true)
        assertEquals(listOf("MEDIUM", "MEDIUM", "LOW"), result.map { it.confidence })
        assertEquals(listOf(11, 12), result[2].matrixRows)
    }

    @Test fun `conflicting zero settlement and verified confirmation evidence stays unknown`() {
        listOf<Boolean?>(false, true, null).forEach { trading ->
            val category = rules.assess("ACTIVE", "ACTIVE", "ACTIVE", false, true, trading).last()
            assertEquals("NOT_DETERMINED", category.result)
            assertNull(category.confidence)
            assertEquals(listOf("ROUTING_EVIDENCE_CONFLICT"), category.missingInputs)
        }
    }

    @Test fun `unknown or unlisted statuses are not presumed inactive`() {
        val result = rules.assess(null, "ACTIVE", "UNKNOWN_NEW_STATUS", null, null, false)
        assertTrue(result.all { it.result == "NOT_DETERMINED" && it.confidence == null })
    }

    @Test fun `every listed inactive party status and booking status is recognized`() {
        ThemeB6Rules.INACTIVE_PARTY_STATUSES.forEach { status ->
            assertEquals("MEDIUM_HIGH", rules.assess(status, "IN_FORMATION", "ACTIVE", null, null, false)[0].confidence)
        }
        ThemeB6Rules.INACTIVE_BOOKING_STATUSES.forEach { status ->
            assertEquals("HIGH", rules.assess("ACTIVE", "ACTIVE", status, null, null, false)[1].confidence)
        }
    }

    @Test fun `parent counts deduplicate duplicate paths and preserve conflicting status evidence`() {
        val core = core(listOf("1", "2"))
        val facts = ReviewFacts(allStatusPaths = listOf(
            row(AllStatusBookingPath("p1", "150", "CODE", "100", "200", "ACTIVE", null), "p1"),
            row(AllStatusBookingPath("p2", "150", "CODE", "100", "200", "ACTIVE", null, pathCount = 20), "p2"),
            row(AllStatusBookingPath("p3", "150", "CODE", "100", "200", "INACTIVE", null), "p3"),
        ), queries = listOf(run("ALL_BOOKING_STATUS_PATHS", listOf("248"))))
        val result = rules.evaluate(core, facts, emptyList())
        val summary = result.parentSummaries.single()
        assertEquals(2, summary.bookingRecordCount)
        assertEquals(1, summary.distinctBookingCodeCount)
        assertEquals(mapOf("AMBIGUOUS" to 2), summary.statusCounts)
        assertEquals(listOf("ACTIVE", "INACTIVE"), summary.observedStatuses)
        assertEquals(0, summary.currentSelectedRecordCount)
        assertEquals(6, result.bookings.size)
    }

    @Test fun `an unconfigured or failed source cannot become zero or a confident status outcome`() {
        val core = core(listOf("1"))
        val missing = rules.evaluate(core, ReviewFacts(), emptyList())
        assertEquals(1, missing.bookings.size)
        assertEquals(FetchStatus.NOT_CONFIGURED, missing.bookings.single().sourceStatus)
        assertNull(missing.bookings.single().pathEvidenceId)
        assertTrue(missing.bookings.single().assessments.all { it.confidence == null })
        val path = row(AllStatusBookingPath("p", "150", "CODE", "100", "200", "INACTIVE", null), "p")
        val failed = rules.evaluate(core, ReviewFacts(allStatusPaths = listOf(path),
            queries = listOf(run("ALL_BOOKING_STATUS_PATHS", listOf("248"), FetchStatus.PARTIAL))), emptyList())
        val booking = failed.bookings.single()
        assertEquals("INACTIVE", booking.crdsBookingStatus)
        assertEquals("NOT_DETERMINED", booking.assessments[1].result)
        assertTrue("ALL_BOOKING_STATUS_PATHS" in booking.assessments[1].missingInputs)
    }

    @Test fun `ambiguous system mapping must not attach raw paths by an arbitrary mapped system`() {
        val core = core(listOf("1")).copy(knownSystemMappings = emptySet())
        val facts = ReviewFacts(allStatusPaths = listOf(
            row(AllStatusBookingPath("p", "150", "CODE", "100", "200", "ACTIVE", null), "p")))
        assertNull(rules.evaluate(core, facts, emptyList()).bookings.single().pathEvidenceId)
    }

    @Test fun `validated usage is consumed and incomplete party lookup never selects an arbitrary status`() {
        val facts = ReviewFacts(allStatusPaths = listOf(
            row(AllStatusBookingPath("p", "150", "CODE", "100", "200", "INACTIVE", "2026-01-01"), "p")),
            parties = listOf(
                row(PartyFact("r", "100", null, "RHP", null, "INACTIVE", "2026-01-01", "200", "200"), "r"),
                row(PartyFact("u", "200", null, "Parent", null, "ACTIVE", "2026-01-01", null, null), "u")),
            queries = listOf(run("ALL_BOOKING_STATUS_PATHS", listOf("248")), run("CRDS_PARTIES", listOf("100", "200"))))
        val usage = UsageReview(bookings = listOf(BookingUsageReview(IcmsEntityId("248"), "1", true,
            listOf("CTM"), true, "2026-10-19", "2024-10-20", "2026-10-20", emptyList(), listOf("trade-e"), listOf("trade-q"))))
        val result = rules.evaluate(core(listOf("1")), facts, emptyList(), usage).bookings.single()
        assertEquals(listOf("MEDIUM", "MEDIUM", "LOW"), result.assessments.map { it.confidence })
        assertTrue("trade-e" in result.evidenceIds)
        assertTrue("trade-q" in result.queryRunIds)
        val failedParties = facts.copy(queries = facts.queries.map {
            if (it.dataset == "CRDS_PARTIES") it.copy(status = FetchStatus.PARTIAL) else it
        })
        val partial = rules.evaluate(core(listOf("1")), failedParties, emptyList(), usage)
        assertEquals("NOT_DETERMINED", partial.bookings.single().assessments.first().result)
        assertTrue(partial.rhpSummaries.single().hasUnknownStatus)
        val ambiguous = rules.evaluate(core(listOf("1")), facts.copy(parties = facts.parties +
            row(PartyFact("r2", "100", null, "RHP", null, "ACTIVE", "2026-02-01", "200", "200"), "r2")), emptyList(), usage)
        assertNull(ambiguous.bookings.single().rhpIndustryStatus)
        assertEquals(listOf("ACTIVE", "INACTIVE"), ambiguous.rhpSummaries.single().statuses)
        assertTrue(ambiguous.rhpSummaries.single().hasUnknownStatus)
        assertTrue(ambiguous.rhpSummaries.single().hasNonActiveStatus)
    }

    @Test fun `positive legacy routing total cannot be attributed to a settlement method but zero can`() {
        fun review(count: Long) = BookingReview(
            entityId = IcmsEntityId("248"), bookingRecordId = "1", resolution = "NO_CRDS_PATH",
            assignedCrdsIdCheck = "MISSING", rhpId = null, rhpName = null, ultimateParentId = null,
            ultimateParentName = null, currentParentsOnKey = null, reportingGroupId = null,
            reportingGroupName = null, reportingGroupCheck = "NO_RHP", reportingLevel = null,
            nameSignal = null, settlementRoutingCount = count, routingAccountTypes = emptyList(),
            lastRoutingChange = null, unused = UnusedAssessment("NOT_DETERMINED", null, emptyList()),
            statuses = emptyMap(), rhpIndustryStatus = null, rhpIndustryStatusDate = null,
            parentIndustryStatus = null, parentIndustryStatusDate = null, activatedDbLeId = null,
            overrideSource = null, lineage = null, evidenceIds = listOf("settlement-evidence"),
            queryRunIds = listOf("settlement-query"))
        val usage = UsageReview(bookings = listOf(BookingUsageReview(IcmsEntityId("248"), "1", false,
            emptyList(), false, null, "2024-10-20", "2026-10-21", emptyList(), emptyList(), emptyList())))
        val positive = rules.evaluate(core(listOf("1")), ReviewFacts(), listOf(review(10)), usage)
            .bookings.single().assessments.last()
        assertNull(positive.confidence)
        assertEquals("NOT_DETERMINED", positive.result)
        assertTrue("SETTLEMENT_METHOD_ROUTING_ATTRIBUTION" in positive.missingInputs)
        val zeroReview = rules.evaluate(core(listOf("1")),
            ReviewFacts(queries = listOf(run("SETTLEMENT_ROUTINGS", listOf("248")))), listOf(review(0)), usage)
            .bookings.single()
        val zero = zeroReview.assessments.last()
        assertEquals("HIGH", zero.confidence)
        assertEquals(listOf(7), zero.matrixRows)
        assertTrue("settlement-evidence" in zeroReview.evidenceIds)
        assertTrue("settlement-query" in zeroReview.queryRunIds)
        assertTrue("q-SETTLEMENT_ROUTINGS" in zeroReview.queryRunIds)
        val traded = rules.evaluate(core(listOf("1")), ReviewFacts(), listOf(review(10)),
            usage.copy(bookings = usage.bookings.map { it.copy(recentTrading = true) }))
            .bookings.single().assessments.last()
        assertEquals("LOW", traded.confidence)
        assertTrue("SETTLEMENT_METHOD_ROUTING_ATTRIBUTION" in traded.missingInputs)
    }

    private fun core(ids: List<String>): CheckResults {
        val entity = IcmsEntityId("248")
        val bookings = ids.map { id -> ResolvedBooking(
            row(BookingRecord(id, entity, "CODE", IcmsSettlementSystemId("10"), id, null, "Active"), id),
            row(BookingSystem(IcmsSettlementSystemId("10"), "Synthetic", CrdsSystemId("150")), "s"),
            null, FetchStatus.COMPLETE, CheckStatus.PASS, emptyList()) }
        return CheckResults(emptyList(), bookings, emptyList(), setOf(IcmsSettlementSystemId("10")))
    }
    private fun <T> row(data: T, key: String) = SourceRow(data, RecordOrigin("e-$key", "test", "synthetic", key, "q-$key"))
    private fun run(dataset: String, keys: List<String>, status: FetchStatus = FetchStatus.COMPLETE) = QueryRun(
        "q-$dataset", "test", "test", dataset, dataset, "hash", keys, QueryLimits(), "2026-10-20T00:00:00Z",
        "2026-10-20T00:00:00Z", status, 0, 1)
}
