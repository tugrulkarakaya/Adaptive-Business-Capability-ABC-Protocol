package com.db.clientinsights.export

import com.db.clientinsights.export.adapters.fixture.FixtureData
import com.db.clientinsights.export.adapters.fixture.FixtureSources
import com.db.clientinsights.export.application.ExportService
import com.db.clientinsights.export.domain.*
import com.db.clientinsights.export.ports.UsageEvidenceSource
import com.db.clientinsights.export.rules.ExtractionChecks
import com.db.clientinsights.export.rules.CheckResults
import com.db.clientinsights.export.rules.UsageEvidenceRules
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test

class UsageEvidenceRulesTest {
    private val id = entityId("248")
    private val request = ExportRequest(listOf(id))
    private val source = FixtureSources(FixtureData(entities = listOf(IcmsEntity(id, "Synthetic client", "Active")),
        bookingRecords = listOf(BookingRecord("1", id, "SYNTHETIC", null, null, null, "Active")),
        bookingSystems = emptyList(), settlementMethods = emptyList()), TEST_CLOCK)
    private val core: CheckResults get() {
        val entities = source.fetchEntities(request.entityIds)
        val bookings = source.fetchBookingRecords(request.entityIds, "Active")
        return ExtractionChecks().evaluate(request, ExtractedFacts(entities.rows, bookings.rows, emptyList(), emptyList()),
            entities.queries + bookings.queries)
    }
    private fun query(dataset: String, status: FetchStatus = FetchStatus.COMPLETE) = QueryRun(dataset, "synthetic", "fixture",
        dataset, "synthetic-query", "synthetic-hash", listOf("248"), QueryLimits(),
        TEST_CLOCK.instant().toString(), TEST_CLOCK.instant().toString(), status, 1, 1)
    private fun <T> row(data: T, dataset: String, suffix: String = "1") = SourceRow(data,
        RecordOrigin("$dataset:$suffix", "synthetic", dataset, suffix, dataset))
    private fun trade(count: Long = 1, last: String? = "2026-10-01", start: String = "2024-10-19",
                      end: String = "2026-10-20", complete: Boolean = true, linked: Boolean = true) =
        BookingTradingFact("1", id, "1", start, end, count, last, complete, linked)
    private fun result(facts: UsageEvidenceFacts) = UsageEvidenceRules(TEST_CLOCK).evaluate(request, core, facts)

    @Test fun `missing sources never become zero contacts or no trading`() {
        val result = result(UsageEvidenceFacts())
        assertNull(result.contacts.single().activeContactCount)
        assertNull(result.bookings.single().recentTrading)
        assertNull(result.bookings.single().confirmationRoutings)
        assertEquals(1, result.entityTrading.single().unknownRecords)
        assertEquals(0, result.entityTrading.single().confirmedTradingRecords)
    }

    @Test fun `contacts count distinct active people and group only CUSTOMER platform names`() {
        val dataset = "ACTIVE_CONTACT_PEOPLE"
        val contacts = listOf(
            ContactPersonFact("1", id, "P1", "ACTIVE", "Bloomberg CDS", "Synthetic Bank CUSTOMER"),
            ContactPersonFact("2", id, "P1", "ACTIVE", "Bloomberg ETF", "Synthetic Bank CUSTOMER"),
            ContactPersonFact("3", id, "P2", "Active", "Autobahn", "Synthetic Bank CUSTOMER"),
            ContactPersonFact("4", id, "P3", "INACTIVE", "MarketAxess", "Old Bank CUSTOMER"),
            ContactPersonFact("5", id, "P2", "Active", "MarketAxess", "Other Bank FIRM"),
        )
        val actual = result(UsageEvidenceFacts(contacts = contacts.map { row(it, dataset, it.rowId) }, queries = listOf(query(dataset))))
            .contacts.single()
        assertEquals(2, actual.activeContactCount)
        assertEquals(listOf(ContactPlatformName("Synthetic Bank", listOf("Autobahn", "Bloomberg"))), actual.names)
        assertNull(UsageEvidenceRules.customerName("CUSTOMER"))
        assertNull(UsageEvidenceRules.customerName("Bank Customer Services"))
        assertEquals("Bank", UsageEvidenceRules.customerName("Bank (CUSTOMER)"))
        assertEquals("Bank", UsageEvidenceRules.customerName("Bank_CUSTOMER"))
    }

    @Test fun `only completed contact query establishes zero and partial evidence is not a total`() {
        assertEquals(0, result(UsageEvidenceFacts(queries = listOf(query("ACTIVE_CONTACT_PEOPLE")))).contacts.single().activeContactCount)
        assertNull(result(UsageEvidenceFacts(queries = listOf(query("ACTIVE_CONTACT_PEOPLE", FetchStatus.PARTIAL)))).contacts.single().activeContactCount)
        val dataset = "ACTIVE_CONTACT_PEOPLE"
        val person = ContactPersonFact("1", id, "P1", "ACTIVE", "Bloomberg", "Bank CUSTOMER")
        listOf(listOf(person.copy(contactId = " ")), listOf(person, person.copy(status = "INACTIVE"))).forEach { people ->
            assertNull(result(UsageEvidenceFacts(contacts = people.mapIndexed { i, p -> row(p, dataset, "$i") },
                queries = listOf(query(dataset)))).contacts.single().activeContactCount)
        }
    }

    @Test fun `completed contact lookup cannot establish zero or positive count for an unverified ICMS entity`() {
        val known = core.entities.single()
        val invalid = listOf(
            core.copy(entities = emptyList()),
            core.copy(entities = listOf(known, known)),
        ) + listOf(EntityPresence.NOT_FOUND, EntityPresence.UNKNOWN, EntityPresence.AMBIGUOUS).map {
            core.copy(entities = listOf(known.copy(presence = it)))
        } + listOf(FetchStatus.PARTIAL, FetchStatus.FAILED, FetchStatus.NOT_CONFIGURED).map {
            core.copy(entities = listOf(known.copy(entityReadStatus = it)))
        }
        val dataset = "ACTIVE_CONTACT_PEOPLE"
        val empty = UsageEvidenceFacts(queries = listOf(query(dataset)))
        val positive = empty.copy(contacts = listOf(row(ContactPersonFact("1", id, "P1", "ACTIVE", "Bloomberg", "Bank CUSTOMER"), dataset)))
        invalid.forEach { checked ->
            listOf(empty, positive).forEach { facts ->
                val actual = UsageEvidenceRules(TEST_CLOCK).evaluate(request, checked, facts).contacts.single()
                assertNull(actual.activeContactCount)
                assertEquals("NOT_DETERMINED", actual.status)
                assertTrue("ICMS_ENTITY_NOT_VERIFIED_FOUND" in actual.limitations)
            }
        }
        assertEquals(0, result(empty).contacts.single().activeContactCount)
        assertEquals(1, result(positive).contacts.single().activeContactCount)
    }

    @Test fun `verified contact counts do not imply that CUSTOMER platform names were checked`() {
        val dataset = "ACTIVE_CONTACT_PEOPLE"
        val person = ContactPersonFact("1", id, "P1", "ACTIVE", null, null)
        val actual = result(UsageEvidenceFacts(contacts = listOf(row(person, dataset)), queries = listOf(query(dataset))))
            .contacts.single()
        assertEquals(1, actual.activeContactCount)
        assertEquals("COMPLETE", actual.status)
        assertTrue(actual.names.isEmpty())
        assertEquals(listOf("ACTIVE_CONTACT_CUSTOMER_PLATFORM_NAMES_NOT_VALIDATED_OR_INCOMPLETE"), actual.limitations)
        val zero = result(UsageEvidenceFacts(queries = listOf(query(dataset)))).contacts.single()
        assertEquals(0, zero.activeContactCount)
        assertTrue(zero.limitations.isEmpty())
    }

    @Test fun `usage covers every fetched booking while entity trading denominator is Active only`() {
        val original = core.bookings.single()
        val allRecords = listOf("Active", "Inactive", "Deleted").mapIndexed { index, status ->
            original.copy(booking = original.booking.copy(data = original.booking.data.copy(id = "${index + 1}", status = status)))
        }
        val allCore = core.copy(bookings = allRecords,
            entities = core.entities.map { it.copy(exportedBookingCount = 3) })
        val dataset = "BOOKING_TRADING_24_MONTHS"
        val facts = UsageEvidenceFacts(trading = allRecords.map { booking ->
            val recordId = booking.booking.data.id
            row(trade(0, null).copy(rowId = recordId, bookingRecordId = recordId), dataset, recordId)
        }, queries = listOf(query(dataset)))
        val actual = UsageEvidenceRules(TEST_CLOCK).evaluate(request.copy(bookingStatus = null), allCore, facts)
        assertEquals(listOf("1", "2", "3"), actual.bookings.map { it.bookingRecordId })
        assertTrue(actual.bookings.all { it.recentTrading == false })
        val summary = actual.entityTrading.single()
        assertEquals(1, summary.observedActiveBookingRecords)
        assertEquals(1, summary.confirmedNoTradingRecords)
        assertEquals(0, summary.unknownRecords)
        assertTrue(summary.bookingCoverageComplete)
        assertEquals(0.0, summary.confirmedTradingPercent)
        val inactiveOnly = UsageEvidenceRules(TEST_CLOCK).evaluate(request.copy(bookingStatus = "Inactive"),
            allCore.copy(bookings = allRecords.filter { it.booking.data.status == "Inactive" }), facts)
        assertEquals(listOf("2"), inactiveOnly.bookings.map { it.bookingRecordId })
        assertEquals(0, inactiveOnly.entityTrading.single().observedActiveBookingRecords)
        assertFalse(inactiveOnly.entityTrading.single().bookingCoverageComplete)
        assertNull(inactiveOnly.entityTrading.single().confirmedTradingPercent)
    }

    @Test fun `dated verified full coverage distinguishes trading from no trading`() {
        val dataset = "BOOKING_TRADING_24_MONTHS"
        fun assess(fact: BookingTradingFact, status: FetchStatus = FetchStatus.COMPLETE) = result(UsageEvidenceFacts(
            trading = listOf(row(fact, dataset)), queries = listOf(query(dataset, status)))).bookings.single()
        assertEquals(true, assess(trade()).recentTrading)
        assertEquals("2026-10-01", assess(trade()).lastTradeDate)
        assertEquals(false, assess(trade(0, null)).recentTrading)
        listOf(trade(complete = false), trade(linked = false), trade(start = "2025-01-01"),
            trade(end = "2026-10-19"), trade(last = "2027-01-01"), trade(last = "bad-date"),
            trade(-1), trade(0, "2026-01-01"), trade(start = "bad-date")).forEach {
            assertNull(assess(it).recentTrading, it.toString())
        }
        assertNull(assess(trade(), FetchStatus.PARTIAL).recentTrading)
    }

    @Test fun `confirmation account links require verification and complete empty query can establish absence`() {
        val dataset = "CONFIRMATION_ROUTINGS"
        val raw = ConfirmationRoutingFact("1", id, "1", "CTM")
        fun assess(fact: ConfirmationRoutingFact) = result(UsageEvidenceFacts(confirmations = listOf(row(fact, dataset)),
            queries = listOf(query(dataset)))).bookings.single()
        assertNull(assess(raw).confirmationRoutings)
        assertEquals(true, assess(raw.copy(verifiedAccountLink = true)).confirmationRoutings)
        assertEquals(listOf("CTM"), assess(raw.copy(verifiedAccountLink = true)).confirmationPlatforms)
        assertEquals(false, result(UsageEvidenceFacts(queries = listOf(query(dataset)))).bookings.single().confirmationRoutings)
    }

    @Test fun `usage source feeds versioned evidence and rejects out of scope or untraceable rows`() {
        val dataset = "BOOKING_TRADING_24_MONTHS"
        val facts = UsageEvidenceFacts(trading = listOf(row(trade(), dataset)), queries = listOf(query(dataset)))
        fun export(usage: UsageEvidenceFacts) = ExportService(source, source, TEST_PRODUCER, clock = TEST_CLOCK,
            usageEvidenceSource = UsageEvidenceSource { _, _ -> usage }).extract(request)
        val bundle = export(facts)
        assertEquals("1.4.0", bundle.schemaVersion)
        assertEquals(true, bundle.review!!.usage.bookings.single().recentTrading)
        assertTrue(bundle.queries.any { it.dataset == dataset })
        assertThrows(SourceContractException::class.java) { export(facts.copy(trading = listOf(row(trade().copy(bookingRecordId = "99"), dataset)))) }
        assertThrows(SourceContractException::class.java) { export(facts.copy(queries = emptyList())) }
        assertThrows(SourceContractException::class.java) { export(facts.copy(queries = listOf(query(dataset).copy(requestedKeys = listOf("999"))))) }
    }

    @Test fun `IN FORMATION parent remains visible without inactive warning`() {
        com.db.clientinsights.export.TestDatabase().use { db ->
            installReviewSchema(db)
            db.execute("INSERT INTO PRD_EXPORT_LEGAL_ENTITY VALUES (248, 'Synthetic client', 'Active')")
            seedBooking(db, 1, 248, "FORMATION")
            seedReviewPath(db, 1, "FORMATION", 11, 100)
            db.execute("UPDATE CRDS_DIF_PARTY_BASE SET party_industry_status = 'IN_FORMATION' WHERE party_id = 100")
            val executor = com.db.clientinsights.export.adapters.icms.JdbcQueryExecutor("test", "", db.connections,
                adapter = "h2-test", clock = TEST_CLOCK)
            val bundle = ExportService(com.db.clientinsights.export.adapters.icms.OracleIcmsSource(executor),
                com.db.clientinsights.export.adapters.icms.OracleIcmsReferenceSource(executor), TEST_PRODUCER,
                clock = TEST_CLOCK, reviewSource = com.db.clientinsights.export.adapters.icms.OracleReviewDataSource { executor }).extract(request)
            val review = checkNotNull(bundle.review)
            assertEquals(1, review.entities.single().currentParentCount)
            assertEquals("IN_FORMATION", review.parents.single().partyStatus)
            assertFalse("PARTY_INACTIVE" in review.parents.single().signals)
        }
    }

    @Test fun `usage evidence cannot reuse a core query ID for another source dataset`() {
        val service = ExportService(source, source, TEST_PRODUCER, clock = TEST_CLOCK,
            usageEvidenceSource = UsageEvidenceSource { _, coreFacts ->
                val original = coreFacts.bookingRecords.single().origin
                val dataset = "BOOKING_TRADING_24_MONTHS"
                UsageEvidenceFacts(trading = listOf(row(trade(), dataset).let {
                    it.copy(origin = it.origin.copy(queryRunId = original.queryRunId))
                }), queries = listOf(query(dataset).copy(queryRunId = original.queryRunId)))
            })
        assertThrows(SourceContractException::class.java) { service.extract(request) }
    }
}
