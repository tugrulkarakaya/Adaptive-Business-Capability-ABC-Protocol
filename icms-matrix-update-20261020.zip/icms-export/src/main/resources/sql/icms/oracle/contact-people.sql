SELECT cp.id, cp.le_id, cp.status
FROM {{schema}}t_contact_person cp
JOIN {{schema}}prd_export_legal_entity le ON le.id = cp.le_id
WHERE le.id IN ({{keys}})
  AND (? IS NULL OR cp.id > ?)
-- Keep all observed statuses: application rules count distinct Active people.
-- No platform/name join is asserted until its foreign-key chain is validated.
ORDER BY cp.id
FETCH FIRST {{page_size}} ROWS ONLY
