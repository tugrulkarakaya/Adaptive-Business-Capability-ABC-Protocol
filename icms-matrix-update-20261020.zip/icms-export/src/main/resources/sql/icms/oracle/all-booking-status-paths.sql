WITH RequestedKeys AS (
    SELECT DISTINCT bc.booking_code, cbs.crds_system_id AS system_id
    FROM {{schema}}prd_export_booking_code bc
    JOIN {{schema}}prd_export_legal_entity le ON le.id = bc.le_id
    JOIN {{schema}}t_crds_booking_system cbs ON cbs.id = bc.settlement_system_id
    WHERE bc.le_id IN ({{keys}}) AND bc.status = 'Active'
), StatusEvidence AS (
    -- Separate from CurrentPaths: retain inactive links and absent party/hierarchy records.
    -- The supported-system scope and TEMP_LE exclusion match the existing parent queries.
    SELECT psx.systemid AS system_id, ax.systemaccountid AS booking_code,
           brp.holderpartyid AS rhp_id, h.ultimate_parent_id AS hierarchy_parent_id,
           ax.accountxrefstatus AS xref_status,
           TO_CHAR(ax.accountxrefstatusdate, 'YYYY-MM-DD') AS xref_status_date,
           psx.productsystemstatus AS product_system_status,
           pa.productadoptionstatus AS product_adoption_status,
           ae.adoptionentitystatus AS adoption_entity_status,
           al.adoptionlocationstatus AS adoption_location_status,
           brp.status AS business_relationship_status,
           h.party_hierarchy_status_code AS hierarchy_status,
           CASE WHEN h.party_id IS NULL THEN NULL
                WHEN h.party_hierarchy_end_date < SYSTIMESTAMP THEN 'Y' ELSE 'N' END AS hierarchy_ended
    FROM {{schema}}crds_br_account_xref ax
    JOIN {{schema}}crds_br_product_system psx ON ax.brps_id = psx.productsystemuniqueid
    LEFT JOIN {{schema}}crds_br_product_adoption pa ON pa.productadoptionuniqueid = psx.brpa_id
    LEFT JOIN {{schema}}crds_br_adoption_entity ae ON ae.adoptionentityuniqueid = pa.bre_id
    LEFT JOIN {{schema}}crds_br_adoption_location al ON al.adoptionlocationuniqueid = ae.brl_id
    LEFT JOIN {{schema}}crds_business_relationship brp ON brp.id = al.brid
    LEFT JOIN {{schema}}crds_dif_party_hierarchy h ON h.party_id = brp.holderpartyid AND h.primary_flag = 'Y'
    WHERE ax.systemaccountid != 'TEMP_LE'
      AND psx.systemid IN (136, 140, 138, 150, 234, 237, 239, 308, 553, 554, 555, 205, 219,
                           196, 206, 227, 228, 229, 230, 452, 473, 474, 475, 598, 679, 289, 625)
      AND EXISTS (SELECT 1 FROM RequestedKeys k
                  WHERE k.booking_code = ax.systemaccountid AND k.system_id = psx.systemid)
), GroupedEvidence AS (
    -- Identical status observations share one evidence row and retain their multiplicity.
    SELECT system_id, booking_code, rhp_id, hierarchy_parent_id, xref_status, xref_status_date,
           product_system_status, product_adoption_status, adoption_entity_status,
           adoption_location_status, business_relationship_status, hierarchy_status, hierarchy_ended,
           COUNT(*) AS path_count
    FROM StatusEvidence
    GROUP BY system_id, booking_code, rhp_id, hierarchy_parent_id, xref_status, xref_status_date,
             product_system_status, product_adoption_status, adoption_entity_status,
             adoption_location_status, business_relationship_status, hierarchy_status, hierarchy_ended
), ReviewRows AS (
    -- All grouping fields participate in the order; pagination never breaks an equal-key group.
    SELECT ROW_NUMBER() OVER (ORDER BY system_id, booking_code, rhp_id, hierarchy_parent_id,
               xref_status, xref_status_date, product_system_status, product_adoption_status,
               adoption_entity_status, adoption_location_status, business_relationship_status,
               hierarchy_status, hierarchy_ended) AS id, g.*
    FROM GroupedEvidence g
)
SELECT * FROM ReviewRows
WHERE (? IS NULL OR id > ?)
ORDER BY id
FETCH FIRST {{page_size}} ROWS ONLY
