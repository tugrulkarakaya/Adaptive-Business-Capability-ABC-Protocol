package com.db.clientinsights.export.domain

import kotlinx.serialization.Serializable

@Serializable
data class UnusedAssessment(val level: String, val ifNoRecentTrading: String?, val missingInputs: List<String>)

@Serializable
data class BookingReview(
    val entityId: IcmsEntityId, val bookingRecordId: String, val resolution: String,
    val assignedCrdsIdCheck: String, val rhpId: String?, val rhpName: String?,
    val ultimateParentId: String?, val ultimateParentName: String?, val currentParentsOnKey: Long?,
    val reportingGroupId: String?, val reportingGroupName: String?, val reportingGroupCheck: String,
    val reportingLevel: Boolean?, val nameSignal: String?, val settlementRoutingCount: Long?,
    val routingAccountTypes: List<String>, val lastRoutingChange: String?, val unused: UnusedAssessment,
    val statuses: Map<String, String?>, val rhpIndustryStatus: String?, val rhpIndustryStatusDate: String?,
    val parentIndustryStatus: String?, val parentIndustryStatusDate: String?,
    val activatedDbLeId: String?, val overrideSource: String?, val lineage: RoutingLineage?,
    val evidenceIds: List<String>, val queryRunIds: List<String>,
)

/**
 * Entity-level totals and flags of one requested entity. Each one is null (unknown) unless every read it depends on
 * completed for this entity; null never means zero or false. Since evidence schema 1.3.0 every total may be null.
 */
@Serializable
data class EntityReview(
    val entityId: IcmsEntityId, val currentRuleStatus: String, val currentParentCount: Int?,
    val flaggedByCurrentRule: Boolean?, val reportParentCount: Int?, val flaggedByBaselineReport: Boolean?,
    val activeLinkParentCount: Int?, val allPathParentCount: Int?, val matchedKeyCount: Int?,
    val keysWithoutPath: Int?, val keysWithSeveralParents: Int?, val tiedReportKeys: Int?,
    val sharedKeyCount: Int?, val currentRecords: Int?, val activeBookingRecords: Int?,
    val keysWithSeveralCurrentParents: Int?, val evidenceIds: List<String>, val queryRunIds: List<String>,
)

@Serializable
data class ParentCandidate(
    val entityId: IcmsEntityId, val parentId: String, val name: String?, val standardName: String?,
    val keyCount: Int, val keySharePercent: Double, val activeLinkKeyCount: Int, val reportKeyCount: Int,
    val sharedKeyCount: Int, val currentRecordCount: Int, val currentBookingCodeCount: Int,
    val partyStatus: String?, val partyStatusDate: String?, val survivingEntityId: String?,
    val ownUltimateParentIds: List<String>, val ownImmediateParentIds: List<String>,
    val linkStatuses: List<String>, val signals: List<String>, val evidenceIds: List<String>, val queryRunIds: List<String>,
)

@Serializable
data class ParentRelationship(
    val entityId: IcmsEntityId, val firstParentId: String, val secondParentId: String,
    val type: String, val source: String, val detail: String,
    val evidenceIds: List<String>, val queryRunIds: List<String>,
)

@Serializable
data class DeterministicReview(
    val ruleVersion: String = "1.0.0", val facts: ReviewFacts,
    val entities: List<EntityReview>, val bookings: List<BookingReview>, val parents: List<ParentCandidate>,
    val relationships: List<ParentRelationship>, val findings: List<DataIssue>,
    val identitySelections: List<BankIdentitySelection> = emptyList(),
    val platformNames: PlatformNameReview = PlatformNameReview(),
    val themeB6: ThemeB6Review = ThemeB6Review(),
    val usage: UsageReview = UsageReview(),
)

@Serializable
data class BankIdentitySelection(val partyId: String, val lei: String?, val status: String,
    val warnings: List<String>, val evidenceIds: List<String>, val queryRunIds: List<String>)
