package com.db.clientinsights.export.workbook

/** Additive source evidence. It copies the export's assessments; it never makes a combined decision. */
internal object ConfluenceEvidenceSheets {
    private val companyHeaders = listOf("Client ID", "Client name", "Active contact people (count)", "Contact count read",
        "Active-person CUSTOMER platform names", "Contact names coverage", "RHP statuses (all paths)",
        "Parent booking/status evidence (all paths, not current counts)", "Missing or provisional evidence", "Human review")
    private val matrixHeaders = listOf("Client ID", "Booking record ID", "Booking code", "cRDS system ID", "Settlement method ID",
        "RHP ID", "RHP status", "Parent ID", "Parent status", "cRDS booking status", "Same party pair as current path",
        "Inactive party check (WIP)", "Inactive booking check (WIP)", "Routings and trading check (WIP)",
        "Missing inputs", "Path read", "Evidence IDs", "Query-run IDs", "Human review",
        "RHP status date", "Parent status date", "cRDS booking status date")

    fun company(collection: CollectionData, review: ReviewData): Sheet {
        val contacts = rows(collection, "active-contact-review.csv").associateBy { it["entity_id"] }
        val availability = rows(collection, "theme-b6-source-availability.csv").groupBy { it["entity_id"] }
        val rhps = rows(collection, "theme-b6-rhp-summary.csv").groupBy { it["entity_id"] }
        val parents = rows(collection, "theme-b6-parent-status-summary.csv").groupBy { it["entity_id"] }
        val body = review.companies.mapIndexed { index, company ->
            val contact = contacts[company.id]
            val scoped = availability[company.id].orEmpty()
            val nameRead = scoped.singleOrNull { it["requirement"] == "ACTIVE_CONTACT_CUSTOMER_PLATFORM_NAMES" }
            val missing = (scoped + availability[""].orEmpty()).filter { it["status"] != "COMPLETE" }
                .joinToString("; ") { "${it["requirement"]}: ${it["status"]}" }
            val rhpText = rhps[company.id].orEmpty().joinToString("; ") {
                "${it["rhp_id"]}: ${known(it["industry_statuses"])}; dates ${known(it["status_dates"])}" +
                    if (it["has_unknown_status"] == "true") " (incomplete or unknown status evidence)" else ""
            }
            val parentText = parents[company.id].orEmpty().joinToString("; ") {
                "${it["parent_id"]}: ${it["booking_record_count"]} records / ${it["distinct_booking_code_count"]} codes; " +
                    "${known(it["booking_status_counts"])} [${it["source_status"]}]"
            }
            val names = contact?.get("customer_platform_names")?.takeIf { it.isNotEmpty() }
                ?: if (nameRead?.get("status") == "COMPLETE") "None recorded" else null
            val values = listOf(company.id, company.entity["entity_name"], contact?.get("active_contact_count"),
                contact?.get("status"), names, nameRead?.get("status"),
                rhpText, parentText, missing.ifEmpty { "New source coverage not supplied in this export" },
                "Evidence only. No parent is chosen; no booking is deactivated. Matrix categories remain WIP/TBC.")
            Row(index + 2, 0, false, 72.0, values.mapIndexed { column, value ->
                if (column == 2) Cell.integer(column + 1, WorkbookLayout.S_TABLE_INT, value, "active_contact_count")
                else Cell.text(column + 1, WorkbookLayout.S_DETAIL_TEXT, known(value))
            })
        }
        return Sheet.of(WorkbookLayout.COMPANY_EVIDENCE_SHEET, listOf(header(companyHeaders)) + body,
            listOf(10.0, 28.0, 14.0, 20.0, 45.0, 22.0, 42.0, 60.0, 65.0, 55.0), 2, 1)
    }

    fun matrix(collection: CollectionData): Sheet {
        val grouped = rows(collection, "theme-b6-booking-assessments.csv").groupBy {
            listOf(it["entity_id"], it["booking_record_id"], it["path_evidence_id"])
        }
        val bookings = rows(collection, "booking-records.csv").associateBy { it["entity_id"] to it["booking_record_id"] }
        for (assessments in grouped.values) {
            val first = assessments.first()
            val record = bookings[first["entity_id"] to first["booking_record_id"]]
            checkWorkbook(record != null && first["booking_code"] == record["booking_code"] &&
                (first["crds_system_id"].isEmpty() || first["crds_system_id"] == record["crds_system_id"]) &&
                first["settlement_method_id"] == record["settlement_method_id"]) {
                "${WorkbookLayout.MATRIX_SHEET} evidence does not match its exported booking record"
            }
        }
        checkWorkbook(grouped.size.toLong() + 1 <= WorkbookLayout.MAX_SHEET_ROWS) {
            "${WorkbookLayout.MATRIX_SHEET} exceeds Excel's row limit; evidence is not truncated"
        }
        return Sheet(WorkbookLayout.MATRIX_SHEET, grouped.size + 1,
            listOf(10.0, 14.0, 18.0, 12.0, 14.0, 12.0, 20.0, 12.0, 20.0, 18.0, 16.0,
                52.0, 52.0, 52.0, 56.0, 20.0, 36.0, 36.0, 55.0, 14.0, 14.0, 14.0), 3, 1) {
            sequence {
                yield(header(matrixHeaders))
                grouped.values.forEachIndexed { index, assessments ->
                    val first = assessments.first()
                    checkWorkbook(assessments.map { it["category"] }.distinct().size == assessments.size) {
                        "${WorkbookLayout.MATRIX_SHEET} has duplicate categories for one booking/path"
                    }
                    val categories = assessments.associateBy { it["category"] }
                    val missing = assessments.flatMap { it["missing_inputs"].split('|') }.filter { it.isNotBlank() }.distinct()
                    val values = listOf(first["entity_id"], first["booking_record_id"], first["booking_code"],
                        first["crds_system_id"], first["settlement_method_id"], first["rhp_id"], first["rhp_industry_status"],
                        first["ultimate_parent_id"], first["parent_industry_status"], first["crds_booking_status"],
                        first["matches_current_party_pair"], assessment(categories["INACTIVE_CRDS_LEGAL_ENTITY"]),
                        assessment(categories["INACTIVE_CRDS_BOOKING_CODE"]), assessment(categories["ROUTINGS_AND_TRADING"]),
                        missing.joinToString(" | ").ifEmpty { "None recorded" }, first["source_status"],
                        first["evidence_ids"], first["query_run_ids"],
                        "Three separate suggested checks; no overall score or automatic action. Historical paths can appear.",
                        first["rhp_status_date"], first["parent_status_date"], first["crds_booking_status_date"])
                    yield(Row(index + 2, 0, false, 84.0, values.mapIndexed { column, value ->
                        Cell.text(column + 1, WorkbookLayout.S_DETAIL_TEXT, known(value))
                    }))
                }
            }
        }
    }

    private fun assessment(row: CsvRow?): String {
        if (row == null) return "Unknown: category evidence not supplied"
        val result = when (row["result"]) {
            "NOT_DETERMINED" -> "Unknown"
            "NO_SIGNAL" -> "No concern under this category"
            "APPLIES" -> "Review signal"
            else -> known(row["result"])
        }
        return buildString {
            append(result)
            if (row["confidence"].isNotEmpty()) append("; actual level: ${row["confidence"]}")
            if (row["if_no_recent_trading"].isNotEmpty()) append("; IF no recent trading: ${row["if_no_recent_trading"]}")
            if (row["if_recent_trading"].isNotEmpty()) append("; IF recent trading: ${row["if_recent_trading"]}")
            append(". ${row["explanation"]}")
        }
    }

    private fun rows(collection: CollectionData, file: String): List<CsvRow> =
        collection.batches.flatMap { it.tables[file]?.rows.orEmpty() }
    private fun header(headers: List<String>) = Row(1, 0, false, 54.0,
        headers.mapIndexed { index, text -> Cell.text(index + 1, WorkbookLayout.S_HEADER, text) })
    private fun known(value: String?): String = value?.takeIf { it.isNotEmpty() } ?: "Unknown / not supplied"
}
