package com.db.clientinsights.export.domain

import kotlinx.serialization.Serializable

/** All relevant cRDS paths, including inactive links; never a replacement for current parent selection. */
@Serializable
data class AllStatusBookingPath(
    val rowId: String, val systemId: String?, val bookingCode: String?, val rhpId: String?,
    val ultimateParentId: String?, val bookingStatus: String?, val bookingStatusDate: String?,
    val statuses: Map<String, String?> = emptyMap(), val pathCount: Long = 1,
)

/** Independent suggested matrix category. No cross-category winning confidence has been approved. */
@Serializable
data class ThemeB6CategoryAssessment(
    val category: String, val result: String, val confidence: String?,
    val ifNoRecentTrading: String?, val ifRecentTrading: String?, val matrixRows: List<Int>,
    val missingInputs: List<String>, val explanation: String,
)

@Serializable
data class ThemeB6BookingAssessment(
    val entityId: IcmsEntityId, val bookingRecordId: String, val systemId: String?, val bookingCode: String?,
    val settlementMethodId: String?, val pathEvidenceId: String?, val rhpId: String?,
    val rhpIndustryStatus: String?, val rhpIndustryStatusDate: String?, val ultimateParentId: String?,
    val parentIndustryStatus: String?, val parentIndustryStatusDate: String?, val crdsBookingStatus: String?,
    val crdsBookingStatusDate: String?, val matchesCurrentPartyPair: Boolean, val sourceStatus: FetchStatus,
    val assessments: List<ThemeB6CategoryAssessment>, val evidenceIds: List<String>, val queryRunIds: List<String>,
)

@Serializable
data class ThemeB6RhpSummary(
    val entityId: IcmsEntityId, val partyId: String, val statuses: List<String>, val statusDates: List<String>,
    val hasNonActiveStatus: Boolean, val hasUnknownStatus: Boolean, val bookingRecordCount: Int,
    val evidenceIds: List<String>, val queryRunIds: List<String>,
)

/**
 * Counts associations in all-status evidence, including historical paths. They are not current-parent counts.
 * Each ICMS record is counted once per parent. Mixed path statuses use one AMBIGUOUS bucket.
 */
@Serializable
data class ThemeB6ParentSummary(
    val entityId: IcmsEntityId, val parentId: String, val bookingRecordCount: Int,
    val distinctBookingCodeCount: Int, val currentSelectedRecordCount: Int, val statusCounts: Map<String, Int>,
    val observedStatuses: List<String>, val sourceStatus: FetchStatus,
    val evidenceIds: List<String>, val queryRunIds: List<String>,
    val evidenceScope: String = "ALL_STATUS_PATH_ASSOCIATIONS_INCLUDING_HISTORICAL",
)

@Serializable
data class ThemeB6Review(
    val bookings: List<ThemeB6BookingAssessment> = emptyList(),
    val rhpSummaries: List<ThemeB6RhpSummary> = emptyList(),
    val parentSummaries: List<ThemeB6ParentSummary> = emptyList(),
    val sourceUrl: String = "https://confluence.intranet.db.com/pages/viewpage.action?pageId=2238185661",
    val sourceStatus: String = "WIP",
    val policyNotes: List<String> = listOf(
        "Suggested matrix, transcribed 20 October 2026; categories are independent human-review signals.",
        "Placement of inactive-party and inactive-booking checks in Theme B #6 or Theme A #1 remains TBC.",
        "No cross-category confidence precedence, automatic deactivation or bank data update is implemented.",
        "All-status path associations can be historical and do not change current parent resolution or counts.",
        "Unknown confirmation or trading evidence is never treated as no routing or no trading.",
    ),
)
