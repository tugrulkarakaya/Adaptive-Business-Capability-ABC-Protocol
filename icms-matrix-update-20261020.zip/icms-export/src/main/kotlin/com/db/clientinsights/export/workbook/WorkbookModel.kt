package com.db.clientinsights.export.workbook

import java.nio.file.Path

// ---------------------------------------------------------------- input: one export collection, integrity-checked

/**
 * One CSV row, stored compactly (one array per row, a shared header index) so large collections fit in memory.
 * get() returns the exported text, "" when the export wrote nothing; asking for a column the table lacks is a bug
 * (required headers are checked when the table is read).
 */
internal class CsvRow(private val index: Map<String, Int>, private val values: Array<String>) {
    operator fun get(column: String): String = values[index[column] ?: error("no CSV column $column")]
}

/** One batch CSV parsed with its header order. */
internal class CsvTable(val file: String, val headers: List<String>, val rows: List<CsvRow>)

/** One batch folder of the collection, after its run-manifest SHA-256 and every consumed CSV were checked. */
internal class BatchData(
    val number: Int,
    val folder: String,
    val manifestSha256: String,
    val runId: String?,
    val extractionStatus: String?,
    val requestedIds: List<String>,
    val tables: Map<String, CsvTable>,
    val fileHashes: Map<String, String>,
) {
    val label: String get() = "B$number"
}

/**
 * The manifest fields the workbook uses, and the batches in manifest order. inputKind says what was read:
 * "collection" (a collection manifest with its batches) or "single-run" (one batch folder read through its
 * run-manifest.json); manifestName and manifestSha256 describe that primary manifest.
 */
internal class CollectionData(
    val dir: Path,
    val inputKind: String,
    val manifestName: String,
    val manifestSha256: String,
    val runId: String?,
    val startedAt: String?,
    val finishedAt: String?,
    val extractionStatus: String?,
    val discoveryStatus: String?,
    val selection: String?,
    val crossSourceAtomicSnapshot: Boolean,
    val exportedBookingCount: Long,
    /** "Active" for an Active-only run; null or another value when other statuses were exported. */
    val bookingStatus: String?,
    val producerVersion: String?,
    val producerRevision: String?,
    val producerDirty: String?,
    val evidenceSchema: String,
    /** requestedEntityIds (or the discovery pages) in collection order. */
    val cohort: List<String>,
    val batches: List<BatchData>,
) {
    /**
     * Every file actually read, each once, with its SHA-256: the primary manifest, then per batch its run-manifest.json
     * (collections only; for a single run it is the primary manifest) and its consumed CSVs.
     */
    fun consumedHashes(): Map<String, String> = buildMap {
        put(manifestName, manifestSha256)
        for (b in batches) {
            if (inputKind == KIND_COLLECTION) put("${b.label}/run-manifest.json", b.manifestSha256)
            b.fileHashes.forEach { (file, hash) -> put("${b.label}/$file", hash) }
        }
    }

    val consumedFileCount: Int get() = consumedHashes().size

    companion object {
        const val KIND_COLLECTION = "collection"
        const val KIND_SINGLE_RUN = "single-run"

        /** Batch files the workbook reads. Everything else in a batch folder is left untouched. */
        val OPTIONAL_FILES = listOf("active-contact-review.csv", "theme-b6-booking-assessments.csv",
            "theme-b6-rhp-summary.csv", "theme-b6-parent-status-summary.csv", "theme-b6-source-availability.csv")
        val CONSUMED_FILES = listOf("entities.csv", "entity-review.csv", "parent-candidates.csv",
            "parent-relationships.csv", "data-issues.csv", "source-status.csv", "booking-records.csv",
            "booking-review.csv", "booking-platform-names.csv")
    }
}

// ---------------------------------------------------------------- joined review data

/** One parent-relationships.csv row seen from one candidate: label is plain text; other is the other parent ID. */
internal data class Relationship(
    val label: String,
    val source: String,
    val firstParentId: String,
    val secondParentId: String,
    val detail: String,
    val otherParentId: String,
)

/** Stored platform names of one booking, grouped by the export's link status (blank when none). */
internal data class PlatformNames(val verified: String, val keyOnly: String, val other: String)

/** One booking-records.csv row with its booking-review.csv row (null when the export reviewed no such booking). */
internal class Booking(val record: CsvRow, val review: CsvRow?, val platform: PlatformNames) {
    /** booking-review ultimate_parent_id, or "" when there is none (also when there is no review row). */
    val selectedParent: String get() = review?.get("ultimate_parent_id").orEmpty()
}

/**
 * One parent-candidates.csv row. evidence is null when every read the row depends on completed. selected holds the
 * bookings whose booking-review ultimate_parent_id is this parent, in booking-records.csv order; its size equals the
 * row's current_records (checked by ReviewJoin).
 */
internal class Candidate(
    val row: CsvRow,
    val relationships: List<Relationship>,
    val evidence: String?,
    val selected: List<Booking>,
) {
    val parentId: String get() = row["parent_id"]
    val signals: List<String> get() = row["signals"].split('|').filter { it.isNotBlank() }
}

/**
 * One requested company. bookings: every booking-records.csv row of the company, in source order. unassigned: the
 * bookings with no selected parent (no booking-review row, or a blank ultimate_parent_id), in source order.
 * completeness is the v3.1 text ("complete" or "INCOMPLETE: ..." plus other-read notes); issues is the data-issue
 * summary text ("None" or "N (n review, ...): Plain rule ×n, ...").
 */
internal class Company(
    val id: String,
    val batch: Int,
    val entity: CsvRow,
    val review: CsvRow,
    val candidates: List<Candidate>,
    val complete: Boolean,
    val completeness: String,
    val issues: String,
    val issueCount: Int,
    val bookings: List<Booking>,
    val unassigned: List<Booking>,
)

/** The joined, checked review data of one collection. */
internal class ReviewData(
    val companies: List<Company>,
    val unknownSignals: Map<String, Int>,
    val unknownRelationshipTypes: Map<String, Int>,
    /** Data issues with a blank entity_id: batch label, severity, rule ID, message. */
    val globalIssues: List<List<String>>,
    /** Source reads that did not complete: batch label, dataset, status, row count. */
    val batchLimitations: List<List<String>>,
) {
    val candidateCount: Int get() = companies.sumOf { it.candidates.size }
    val bookingCount: Int get() = companies.sumOf { it.bookings.size }
}

// ---------------------------------------------------------------- workbook model (what the writer writes)

/**
 * One cell: text, number (canonical decimal string), styled blank, or the one allowlisted formula (formula holds the
 * formula text without "=", number holds its cached value). Column is 1-based.
 */
internal data class Cell(val column: Int, val style: Int, val text: String?, val number: String?, val formula: String?) {
    companion object {
        fun text(column: Int, style: Int, value: String?): Cell =
            Cell(column, style, value?.takeIf { it.isNotEmpty() }, null, null)
        fun blank(column: Int, style: Int): Cell = Cell(column, style, null, null, null)
        fun number(column: Int, style: Int, value: Long): Cell = Cell(column, style, null, value.toString(), null)
        /** A whole number from a CSV value: blank stays a blank cell (unknown is never 0). */
        fun integer(column: Int, style: Int, value: String?, field: String): Cell = when {
            value.isNullOrEmpty() -> blank(column, style)
            else -> Cell(column, style, null, (value.toLongOrNull()
                ?: throw WorkbookCheckFailure("column $field has a non-integer value")).toString(), null)
        }
        /** A decimal from a CSV value, kept exactly: blank stays a blank cell. */
        fun decimal(column: Int, style: Int, value: String?, field: String): Cell = when {
            value.isNullOrEmpty() -> blank(column, style)
            else -> Cell(column, style, null, (value.toBigDecimalOrNull()
                ?: throw WorkbookCheckFailure("column $field has a non-numeric value")).toPlainString(), null)
        }
        fun formula(column: Int, style: Int, formula: String, cached: String): Cell =
            Cell(column, style, null, cached, formula)
    }
}

/** level 0 = visible; level > 0 = outline child, written hidden. collapsed = this row's children start hidden. */
internal data class Row(val number: Int, val level: Int, val collapsed: Boolean, val height: Double?, val cells: List<Cell>)

/**
 * One worksheet. Rows come from a re-iterable source so the large Bookings tab is generated row by row (bounded
 * memory) each time the writer or the verifier walks it; every call must yield the same rows 1..lastRow in order.
 */
internal class Sheet(
    val name: String,
    val lastRow: Int,
    val widths: List<Double>,
    val frozenColumns: Int,
    val frozenRows: Int,
    private val rowSource: () -> Sequence<Row>,
) {
    fun rows(): Sequence<Row> = rowSource()

    companion object {
        /** A small sheet whose rows are already built. */
        fun of(name: String, rows: List<Row>, widths: List<Double>, frozenColumns: Int, frozenRows: Int): Sheet =
            Sheet(name, rows.size, widths, frozenColumns, frozenRows) { rows.asSequence() }
    }
}

/**
 * A Company review link cell (column M_BOOKINGS on a client or parent row). It jumps to the defined name `name`,
 * whose formula (WorkbookLayout.jumpFormula) finds the first Bookings row whose key column holds `key` in the current
 * sort order, so the jump stays right after a reviewer sorts the Bookings tab. parentId is null for a client link.
 */
internal data class Jump(
    val row: Int,
    val name: String,
    val keyColumn: Int,
    val key: String,
    val entityId: String,
    val parentId: String?,
) {
    val cellRef: String get() = columnName(WorkbookLayout.M_BOOKINGS) + row
}

/** The Summary table behind the chart: labels in column A, counts in column B, starting at firstRow (header above). */
internal data class Chart(
    val headerRow: Int,
    val firstRow: Int,
    val labels: List<String>,
    val values: List<Long>,
    /** 0-based anchor of the chart's top-left corner (column D = 3). */
    val anchorColumn: Int,
    val anchorRow: Int,
) {
    val lastRow: Int get() = firstRow + labels.size - 1
}

/**
 * Everything the writer and the verifier need. Row numbers are 1-based worksheet rows.
 * - companyRowOf / companyDetailRowOf: per company ID, its client row and its client details row on Company review.
 * - parentRowsOf / parentDetailRowsOf: per company ID, its parent rows and parent details rows, in candidate order.
 * - reviewRows: the Company review rows that carry the four reviewer inputs (client and parent rows), ascending.
 * - bookingRowsOf: per company ID, its Bookings rows in tab order (candidate groups, then unassigned).
 * - jumps: the link cells with their names, in Company review row order.
 * - progressRow: the Summary row whose column B holds the progress formula.
 */
internal class WorkbookModel(
    val summary: Sheet,
    val main: Sheet,
    val bookings: Sheet,
    val rules: Sheet,
    val companyRowOf: Map<String, Int>,
    val companyDetailRowOf: Map<String, Int>,
    val parentRowsOf: Map<String, List<Int>>,
    val parentDetailRowsOf: Map<String, List<Int>>,
    val reviewRows: List<Int>,
    val bookingRowsOf: Map<String, List<Int>>,
    val jumps: List<Jump>,
    val progressRow: Int,
    val chart: Chart,
    val decisionOptions: List<String>,
    val companyEvidence: Sheet = emptySupplementary(WorkbookLayout.COMPANY_EVIDENCE_SHEET),
    val matrix: Sheet = emptySupplementary(WorkbookLayout.MATRIX_SHEET),
) {
    val sheets: List<Sheet> get() = listOf(summary, main, bookings, rules, companyEvidence, matrix)
}

private fun emptySupplementary(name: String): Sheet = Sheet.of(name,
    listOf(Row(1, 0, false, 30.0, listOf(Cell.text(1, WorkbookLayout.S_HEADER, "Evidence not supplied")))),
    listOf(60.0), 0, 1)
