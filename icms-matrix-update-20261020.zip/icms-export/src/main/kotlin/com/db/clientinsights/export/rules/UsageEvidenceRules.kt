package com.db.clientinsights.export.rules

import com.db.clientinsights.export.domain.*
import java.time.Clock
import java.time.LocalDate
import java.time.ZoneOffset
import java.util.Locale

/** Prepares optional contact, confirmation and dated trade facts without inventing source coverage. */
class UsageEvidenceRules(private val clock: Clock = Clock.systemUTC()) {
    fun evaluate(request: ExportRequest, core: CheckResults, facts: UsageEvidenceFacts): UsageReview {
        val runs = facts.queries.flatMap { q -> q.requestedKeys.map { (q.dataset to it) to q } }
            .groupBy({ it.first }, { it.second })
        fun complete(dataset: String, entity: IcmsEntityId): Boolean = runs[dataset to entity.value]
            ?.let { it.isNotEmpty() && it.all { q -> q.status == FetchStatus.COMPLETE && !q.truncated } } == true
        fun queries(dataset: String, entity: IcmsEntityId) = runs[dataset to entity.value].orEmpty().map { it.queryRunId }
        val coreEntities = core.entities.groupBy { it.entityId }
        val contacts = facts.contacts.groupBy { it.data.entityId }
        val confirmations = facts.confirmations.groupBy { it.data.entityId to it.data.bookingRecordId }
        val trading = facts.trading.groupBy { it.data.entityId to it.data.bookingRecordId }
        val today = LocalDate.ofInstant(clock.instant(), ZoneOffset.UTC)
        val start = today.minusMonths(24)
        val end = today.plusDays(1)
        val contactReviews = request.entityIds.map { entity ->
            val rows = contacts[entity].orEmpty()
            val coreEntity = coreEntities[entity]?.singleOrNull()
            val entityVerified = coreEntity?.presence == EntityPresence.FOUND &&
                coreEntity.entityReadStatus == FetchStatus.COMPLETE
            val conflictingPeople = rows.groupBy { it.data.contactId }.values.any { personRows ->
                personRows.map { it.data.status?.trim()?.uppercase(Locale.ROOT) }.distinct().size > 1
            }
            val valid = entityVerified && complete("ACTIVE_CONTACT_PEOPLE", entity) && !conflictingPeople &&
                rows.all { !it.data.status.isNullOrBlank() && it.data.contactId.isNotBlank() }
            val active = rows.filter { it.data.status?.trim()?.uppercase(Locale.ROOT) == "ACTIVE" }
            val names = if (!valid) emptyList() else active.mapNotNull { row ->
                customerName(row.data.nameOnPlatform)?.let { it to platformFamily(row.data.platformName) }
            }.filter { it.second != null }.groupBy({ it.first }, { checkNotNull(it.second) })
                .toSortedMap().map { (name, platforms) -> ContactPlatformName(name, platforms.distinct().sorted()) }
            ContactReview(entity, if (valid) active.map { it.data.contactId }.distinct().size else null, names,
                if (valid) "COMPLETE" else "NOT_DETERMINED",
                buildList {
                    if (!entityVerified) add("ICMS_ENTITY_NOT_VERIFIED_FOUND")
                    if (!valid) add("ACTIVE_CONTACT_PEOPLE_NOT_VALIDATED_OR_INCOMPLETE")
                    if (!valid || active.any { it.data.platformName.isNullOrBlank() || it.data.nameOnPlatform.isNullOrBlank() })
                        add("ACTIVE_CONTACT_CUSTOMER_PLATFORM_NAMES_NOT_VALIDATED_OR_INCOMPLETE")
                },
                rows.map { it.origin.evidenceId }.distinct(),
                (queries("ACTIVE_CONTACT_PEOPLE", entity) + coreEntity?.queryRunIds.orEmpty()).distinct())
        }
        // Optional evidence belongs to each explicitly fetched record, regardless of its ICMS status.
        val bookingReviews = core.bookings.map { booking ->
            val record = booking.booking.data
            val key = record.entityId to record.id
            val routes = confirmations[key].orEmpty()
            val trades = trading[key].orEmpty()
            val confirmed = if (complete("CONFIRMATION_ROUTINGS", record.entityId) &&
                routes.all { it.data.verifiedAccountLink }) routes.isNotEmpty() else null
            val trade = trades.singleOrNull()?.data
            val last = trade?.lastTradeDate?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
            val validTrade = complete("BOOKING_TRADING_24_MONTHS", record.entityId) && trade != null &&
                trade.coverageComplete && trade.verifiedBookingLink && trade.tradeCount >= 0 &&
                runCatching { LocalDate.parse(trade.windowStartInclusive) <= start &&
                    LocalDate.parse(trade.windowEndExclusive) >= end }.getOrDefault(false) &&
                ((trade.tradeCount == 0L && trade.lastTradeDate == null) ||
                    (trade.tradeCount > 0 && last != null && last >= start && last < end))
            val recent = if (validTrade) checkNotNull(trade).tradeCount > 0 else null
            val origins = routes.map { it.origin } + trades.map { it.origin }
            BookingUsageReview(record.entityId, record.id, confirmed,
                if (confirmed == true) routes.mapNotNull { platformFamily(it.data.platformName) }.distinct().sorted() else emptyList(),
                recent, if (recent == true) last?.toString() else null, start.toString(), end.toString(),
                buildList {
                    if (confirmed == null) add("CONFIRMATION_ROUTINGS_NOT_VALIDATED_OR_INCOMPLETE")
                    if (recent == null) add("DATED_24_MONTH_TRADE_COVERAGE_NOT_VALIDATED_OR_INCOMPLETE")
                }, origins.map { it.evidenceId }.distinct(),
                (queries("CONFIRMATION_ROUTINGS", record.entityId) + queries("BOOKING_TRADING_24_MONTHS", record.entityId)).distinct())
        }
        // The company-level Confluence denominator is the Active cohort, not every fetched status.
        val activeRecordKeys = core.bookings.filter { it.booking.data.status.equals("Active", true) }
            .map { it.booking.data.entityId to it.booking.data.id }.toSet()
        val bookingsByEntity = bookingReviews.filter { (it.entityId to it.bookingRecordId) in activeRecordKeys }
            .groupBy { it.entityId }
        val summaries = request.entityIds.map { entity ->
            val rows = bookingsByEntity[entity].orEmpty()
            val includesActiveScope = request.bookingStatus == null || request.bookingStatus.equals("Active", true)
            val covered = includesActiveScope && coreEntities[entity]?.singleOrNull()?.let {
                it.presence == EntityPresence.FOUND && it.bookingReadStatus == FetchStatus.COMPLETE
            } == true
            val withTrading = rows.count { it.recentTrading == true }
            EntityTradingSummary(entity, rows.size, covered, withTrading,
                rows.count { it.recentTrading == false }, rows.count { it.recentTrading == null },
                if (covered && rows.isNotEmpty()) 100.0 * withTrading / rows.size else null)
        }
        return UsageReview(contactReviews, bookingReviews, summaries)
    }

    companion object {
        /** Only terminal CUSTOMER role labels are removed. FIRM names and unsuffixed names are not promoted. */
        fun customerName(raw: String?): String? {
            val value = raw?.trim()?.takeIf { it.isNotEmpty() } ?: return null
            val match = Regex("(?i)(?:[\\s_:\\-]+CUSTOMER|\\s*[\\[(]CUSTOMER[\\])])$").find(value) ?: return null
            return value.substring(0, match.range.first).trim().takeIf { it.isNotEmpty() }
        }

        fun platformFamily(raw: String?): String? = raw?.trim()?.takeIf { it.isNotEmpty() }?.let {
            if (Regex("(?i)Bloomberg(?:\\s+(?:CDS|ETF|Swaps))?").matches(it)) "Bloomberg" else it
        }
    }
}
