package com.db.clientinsights.export.rules

import com.db.clientinsights.export.domain.ParentCandidate
import com.db.clientinsights.export.rules.ReviewRules.Companion.NULL_PARENT
import com.db.clientinsights.export.rules.ReviewRules.Companion.compareIds
import kotlin.math.round

/** Builds, signals and ranks the parent candidates of one entity. Signals are review clues, never decisions. */
internal class ParentCandidateRules(private val names: NameSignals, private val parties: PartyDirectory) {
    /** Every candidate of the entity in review order, with MAIN_PARENT on the leader if there is one. */
    fun rank(e: EntityEvidence): List<ParentCandidate> {
        val ranked = e.allParentIds.map { candidate(e, CandidateEvidence(it, e, parties)) }.sortedWith(REVIEW_ORDER)
        val main = mainParent(ranked)
        return ranked.map { if (it === main) it.copy(signals = it.signals + "MAIN_PARENT") else it }
    }

    /**
     * MAIN_PARENT as implemented today: the first-ranked candidate when it has Active-link keys and more of them
     * than the second-ranked candidate. Finding A3 records that this can differ from "most Active-link keys".
     */
    private fun mainParent(ranked: List<ParentCandidate>): ParentCandidate? = ranked.firstOrNull()?.takeIf {
        it.activeLinkKeyCount > 0 && (ranked.size == 1 || it.activeLinkKeyCount > ranked[1].activeLinkKeyCount)
    }

    private fun candidate(e: EntityEvidence, c: CandidateEvidence) = ParentCandidate(
        entityId = e.id,
        parentId = c.parent,
        name = c.name,
        standardName = c.party?.standardName,
        keyCount = c.keys.size,
        keySharePercent = c.keySharePercent,
        activeLinkKeyCount = c.activeLinkKeys.size,
        reportKeyCount = c.baselineKeys.size,
        sharedKeyCount = c.keys.count { it in e.sharedKeys },
        currentRecordCount = c.currentRecords.size,
        currentBookingCodeCount = c.currentRecords.map { it.booking.data.bookingCode }.distinct().size,
        partyStatus = c.party?.industryStatus,
        partyStatusDate = c.party?.industryStatusDate,
        survivingEntityId = c.party?.survivingEntityId?.takeIf { it != c.parent },
        ownUltimateParentIds = c.ownUltimateParentIds,
        ownImmediateParentIds = c.ownImmediateParentIds,
        linkStatuses = c.paths.flatMap { it.data.linkStatuses }.distinct(),
        signals = signals(e, c),
        evidenceIds = c.origins.map { it.evidenceId },
        queryRunIds = c.origins.map { it.queryRunId }.distinct(),
    )

    /**
     * Review signals, in their published order:
     * - CURRENT_PARENT or NOT_CURRENT: whether the current path of any Active booking ends at this parent.
     * - HIDDEN_BY_REPORT: the baseline report selects this parent for none of its keys.
     * - ONLY_INACTIVE_LINKS: no key reaches this parent through an Active account link.
     * - ONLY_SHARED_KEYS: every key of this parent is also booked by another ICMS entity.
     * - MINOR_SHARE: one of several candidates, holding under 10% of the entity's matched keys.
     * - SAME_AS_ENTITY or NAME_LIKE_ENTITY: the parent's name equals or resembles the entity's name.
     * - PARENT_IS_DEUTSCHE_BANK: a name heuristic only (finding A4), not an identity check.
     * - NAME_MISSING, PARTY_INACTIVE, MERGED_INTO_OTHER_PARTY, NOT_TOP_OF_OWN_HIERARCHY: from the cRDS party row.
     * - TIED_SELECTION: one of this parent's keys has a tied baseline selection.
     * - INCOMPLETE_EVIDENCE: the path or current-path evidence of the entity is incomplete.
     */
    private fun signals(e: EntityEvidence, c: CandidateEvidence): List<String> = buildList {
        add(if (c.currentRecords.isEmpty()) "NOT_CURRENT" else "CURRENT_PARENT")
        if (c.baselineKeys.isEmpty()) add("HIDDEN_BY_REPORT")
        if (c.activeLinkKeys.isEmpty()) add("ONLY_INACTIVE_LINKS")
        if (c.keys.isNotEmpty() && c.keys.all { it in e.sharedKeys }) add("ONLY_SHARED_KEYS")
        if (e.allParentIds.size > 1 && c.keySharePercent < 10) add("MINOR_SHARE")
        if (c.name != null) {
            names.compare(names.entityVariants(e.entity.name), listOf(c.name))
                ?.let { add(if (it == "SAME_NAME") "SAME_AS_ENTITY" else "NAME_LIKE_ENTITY") }
            if (names.canonical(c.name) == "deutsche bank") add("PARENT_IS_DEUTSCHE_BANK")
        }
        if (c.party == null) add("NAME_MISSING")
        if (c.party?.industryStatus != null && c.party.industryStatus.trim().uppercase(java.util.Locale.ROOT) !in setOf("ACTIVE", "IN_FORMATION")) {
            add("PARTY_INACTIVE")
        }
        if (c.party?.survivingEntityId != null && c.party.survivingEntityId != c.parent) add("MERGED_INTO_OTHER_PARTY")
        if (c.ownUltimateParentIds.isNotEmpty() && c.parent !in c.ownUltimateParentIds) add("NOT_TOP_OF_OWN_HIERARCHY")
        if (c.keys.any { it in e.tiedKeys }) add("TIED_SELECTION")
        if (!e.pathEvidenceComplete || !e.currentEvidenceComplete) add("INCOMPLETE_EVIDENCE")
    }

    private companion object {
        /** Most current records first, then most Active-link keys, then most keys, then the lowest parent ID. */
        val REVIEW_ORDER: Comparator<ParentCandidate> = compareByDescending<ParentCandidate> { it.currentRecordCount }
            .thenByDescending { it.activeLinkKeyCount }
            .thenByDescending { it.keyCount }
            .thenComparator { a, b -> compareIds(a.parentId, b.parentId) }
    }
}

/** What one entity's evidence says about one of its parents. */
private class CandidateEvidence(val parent: String, e: EntityEvidence, parties: PartyDirectory) {
    val paths = e.pathsByParent[parent].orEmpty()
    val keys = paths.mapNotNull { it.data.crdsKey() }.toSet()
    val activeLinkKeys = paths.filter { it.data.activeLinkPaths > 0 }.mapNotNull { it.data.crdsKey() }.toSet()

    /** Keys for which the baseline report selects this parent. */
    val baselineKeys = paths
        .filter { (it.data.reportParentId ?: NULL_PARENT) == e.baselineParentByKey[it.data.crdsKey()] }
        .mapNotNull { it.data.crdsKey() }.toSet()
    val currentRecords = e.currentRecordsByParent[parent].orEmpty()
    val keySharePercent = if (e.pathsByKey.isEmpty()) 0.0 else round(1000.0 * keys.size / e.pathsByKey.size) / 10

    private val partyRows = parties.partyRows(parent)
    val party = parties.party(parent)
    val name = parties.name(parent)
    val ownUltimateParentIds = partyRows.mapNotNull { it.data.ultimateParentId }.distinct()
    val ownImmediateParentIds = partyRows.mapNotNull { it.data.immediateParentId }.distinct()

    /** The parent's path rows and cRDS party rows. */
    val origins = (paths.map { it.origin } + partyRows.map { it.origin }).distinct()
}
