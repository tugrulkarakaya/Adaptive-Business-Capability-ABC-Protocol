package com.db.clientinsights.export.workbook.input

import com.db.clientinsights.export.workbook.CsvTable
import com.db.clientinsights.export.workbook.checkWorkbook

/**
 * Columns each consumed CSV must have. They are checked when the batch is read, so the join and the workbook content
 * can read any of them from a CsvRow without a missing-column error.
 */
internal object RequiredColumns {
    val BY_FILE: Map<String, List<String>> = linkedMapOf(
        "active-contact-review.csv" to listOf("entity_id", "active_contact_count", "status", "customer_platform_names", "limitations"),
        "theme-b6-booking-assessments.csv" to listOf("entity_id", "booking_record_id", "crds_system_id", "booking_code",
            "settlement_method_id", "path_evidence_id", "matches_current_party_pair", "rhp_id", "rhp_industry_status",
            "ultimate_parent_id", "parent_industry_status", "crds_booking_status", "rhp_status_date", "parent_status_date",
            "crds_booking_status_date", "source_status", "category", "result",
            "confidence", "if_no_recent_trading", "if_recent_trading", "missing_inputs", "explanation", "evidence_ids", "query_run_ids"),
        "theme-b6-rhp-summary.csv" to listOf("entity_id", "rhp_id", "industry_statuses", "status_dates", "has_unknown_status"),
        "theme-b6-parent-status-summary.csv" to listOf("entity_id", "parent_id", "booking_record_count",
            "distinct_booking_code_count", "booking_status_counts", "source_status"),
        "theme-b6-source-availability.csv" to listOf("entity_id", "requirement", "status", "limitation"),
        "entities.csv" to listOf("entity_id", "presence", "entity_name", "extraction_status"),
        "entity-review.csv" to listOf("entity_id", "current_rule_status") + ReviewVocabulary.TOTAL_FIELDS,
        "parent-candidates.csv" to listOf("entity_id", "parent_id", "name", "key_count", "key_share_percent",
            "active_link_keys", "baseline_keys", "shared_keys", "current_records", "current_booking_codes",
            "party_status", "status_date", "surviving_entity_id", "own_ultimate_parent_ids", "own_immediate_parent_ids",
            "link_statuses", "signals"),
        "parent-relationships.csv" to listOf("entity_id", "first_parent_id", "second_parent_id", "type", "source",
            "detail"),
        "data-issues.csv" to listOf("entity_id", "rule_id", "severity", "message"),
        "source-status.csv" to listOf("dataset", "requested_keys", "status"),
        "booking-records.csv" to listOf("booking_record_id", "entity_id", "booking_code", "source_status",
            "icms_settlement_system_id", "settlement_system_name", "crds_system_id", "settlement_method_id", "settlement_method_name",
            "assigned_crds_party_id", "reference_read_status", "data_quality_status"),
        "booking-review.csv" to listOf("entity_id", "booking_record_id", "resolution", "assigned_crds_id_check",
            "rhp_id", "rhp_name", "ultimate_parent_id", "ultimate_parent_name", "current_parents_on_key",
            "reporting_group_id", "reporting_group_name", "reporting_group_check", "settlement_routings",
            "account_types", "last_routing_change", "rhp_industry_status", "rhp_status_date"),
        "booking-platform-names.csv" to listOf("entity_id", "booking_record_id", "platform_name", "name_on_platform",
            "firm_name", "has_name", "link_status", "link_reason"))

    /** Fails naming the batch, file and first missing column. */
    fun check(label: String, table: CsvTable) {
        val present = table.headers.toSet()
        for (column in BY_FILE[table.file].orEmpty())
            checkWorkbook(column in present) { "$label ${table.file} has no column $column" }
    }
}
