package com.db.clientinsights.export.workbook.verify

import com.db.clientinsights.export.workbook.WorkbookLayout
import com.db.clientinsights.export.workbook.WorkbookLayout.NS_MAIN
import com.db.clientinsights.export.workbook.WorkbookLayout.NS_PKG_REL
import com.db.clientinsights.export.workbook.WorkbookLayout.NS_REL
import com.db.clientinsights.export.workbook.WorkbookModel
import com.db.clientinsights.export.workbook.checkWorkbook

/**
 * Checks of the package plumbing: content types, every relationship (exact ID, type and target, never TargetMode),
 * workbook.xml (4 sheets in order, 1900 date system, defined names, recalculation on load) and the fixed styles.
 */
internal object PackageChecks {
    private const val NS_CONTENT_TYPES = "http://schemas.openxmlformats.org/package/2006/content-types"
    private const val REL_TYPE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/"
    private const val CT = "application/vnd.openxmlformats-officedocument."
    private val DEFAULT_TYPES = mapOf("rels" to "application/vnd.openxmlformats-package.relationships+xml",
        "xml" to "application/xml")
    private val OVERRIDE_TYPES = buildMap {
        put("/xl/workbook.xml", CT + "spreadsheetml.sheet.main+xml")
        put("/xl/styles.xml", CT + "spreadsheetml.styles+xml")
        for (i in 1..WorkbookLayout.SHEETS.size) put("/xl/worksheets/sheet$i.xml", CT + "spreadsheetml.worksheet+xml")
        put("/xl/drawings/drawing1.xml", CT + "drawing+xml")
        put("/xl/charts/chart1.xml", CT + "drawingml.chart+xml")
    }

    /** Expected relationships per .rels part: ID -> (type suffix, target). */
    private val RELATIONSHIPS = mapOf(
        "_rels/.rels" to mapOf("rId1" to ("officeDocument" to "xl/workbook.xml")),
        "xl/_rels/workbook.xml.rels" to (1..WorkbookLayout.SHEETS.size).associate { "rId$it" to ("worksheet" to "worksheets/sheet$it.xml") } +
            mapOf("rId${WorkbookLayout.SHEETS.size + 1}" to ("styles" to "styles.xml")),
        "xl/worksheets/_rels/sheet1.xml.rels" to mapOf("rId1" to ("drawing" to "../drawings/drawing1.xml")),
        "xl/drawings/_rels/drawing1.xml.rels" to mapOf("rId1" to ("chart" to "../charts/chart1.xml")),
    )

    fun checkContentTypes(root: XNode) {
        val part = "[Content_Types].xml"
        checkWorkbook(root.namespace == NS_CONTENT_TYPES && root.name == "Types" && root.attributes.isEmpty()) {
            "$part root element differs"
        }
        val defaults = LinkedHashMap<String, String>()
        val overrides = LinkedHashMap<String, String>()
        for (child in root.children) {
            checkWorkbook(child.namespace == NS_CONTENT_TYPES && child.children.isEmpty()) { "$part has an unexpected element" }
            when (child.name) {
                "Default" -> {
                    checkWorkbook(child.attributes.keys == setOf("Extension", "ContentType")) { "$part Default attributes differ" }
                    checkWorkbook(defaults.put(child["Extension"]!!, child["ContentType"]!!) == null) { "$part repeats a Default" }
                }
                "Override" -> {
                    checkWorkbook(child.attributes.keys == setOf("PartName", "ContentType")) { "$part Override attributes differ" }
                    checkWorkbook(overrides.put(child["PartName"]!!, child["ContentType"]!!) == null) { "$part repeats an Override" }
                }
                else -> checkWorkbook(false) { "$part has an unexpected element" }
            }
        }
        checkWorkbook(defaults == DEFAULT_TYPES) { "$part default content types differ" }
        checkWorkbook(overrides == OVERRIDE_TYPES) { "$part part content types differ" }
    }

    /** Every relationship exactly: ID, type, target; attributes only Id/Type/Target (so never TargetMode). */
    fun checkRelationships(trees: Map<String, XNode>) {
        checkWorkbook(trees.keys == RELATIONSHIPS.keys) { "relationship parts differ" }
        for ((part, expected) in RELATIONSHIPS) {
            val root = trees.getValue(part)
            checkWorkbook(root.namespace == NS_PKG_REL && root.name == "Relationships" && root.attributes.isEmpty()) {
                "$part root element differs"
            }
            val written = LinkedHashMap<String, Pair<String, String>>()
            for (rel in root.children) {
                checkWorkbook(rel.namespace == NS_PKG_REL && rel.name == "Relationship" && rel.children.isEmpty()) {
                    "$part has an unexpected element"
                }
                checkWorkbook(rel.attributes.keys == setOf("Id", "Type", "Target")) {
                    "$part a relationship has attributes other than Id, Type and Target (for example TargetMode)"
                }
                val type = rel["Type"]!!
                checkWorkbook(type.startsWith(REL_TYPE)) { "$part a relationship type is not an OOXML package type" }
                checkWorkbook(written.put(rel["Id"]!!, type.removePrefix(REL_TYPE) to rel["Target"]!!) == null) {
                    "$part repeats a relationship ID"
                }
            }
            checkWorkbook(written == expected) { "$part relationships differ from the expected IDs, types or targets" }
        }
    }

    /** The styles part is exactly WorkbookLayout.STYLES_XML. */
    fun checkStyles(bytes: ByteArray, tree: XNode) {
        checkWorkbook(String(bytes, Charsets.UTF_8) == WorkbookLayout.STYLES_XML) { "xl/styles.xml differs from the fixed styles" }
        checkWorkbook(tree.namespace == NS_MAIN && tree.name == "styleSheet") { "xl/styles.xml root element differs" }
    }

    /**
     * workbook.xml: allowed elements only; 1900 date system; Summary opens first; 4 sheets in order; defined names
     * exactly _FilterDatabase plus one per jump with the allowlisted formula text; fullCalcOnLoad. Returns the number
     * of defined names.
     */
    fun checkWorkbook(root: XNode, model: WorkbookModel): Int {
        val part = "xl/workbook.xml"
        checkWorkbook(root.namespace == NS_MAIN && root.name == "workbook" && root.attributes.isEmpty()) {
            "$part root element differs"
        }
        val order = listOf("workbookPr", "bookViews", "sheets", "definedNames", "calcPr")
        var position = -1
        for (child in root.children) {
            val index = order.indexOf(child.name)
            checkWorkbook(child.namespace == NS_MAIN && index > position) { "$part has an unexpected or misplaced element" }
            position = index
        }
        root.all("workbookPr").firstOrNull()?.let {
            checkWorkbook(it["date1904"] in setOf(null, "0", "false")) { "$part uses the 1904 date system" }
        }
        root.all("bookViews").firstOrNull()?.let { views ->
            for (view in views.children) {
                checkWorkbook(view.name == "workbookView" && view["activeTab"] in setOf(null, "0") &&
                    view["firstSheet"] in setOf(null, "0")) { "$part does not open on the Summary tab" }
            }
        }
        checkSheets(root.one("sheets", part), part)
        val names = checkDefinedNames(root.one("definedNames", part), model, part)
        val calc = root.one("calcPr", part)
        checkWorkbook(calc["fullCalcOnLoad"] == "1" && calc.children.isEmpty()) { "$part does not recalculate on load" }
        return names
    }

    private fun checkSheets(sheets: XNode, part: String) {
        checkWorkbook(sheets.children.size == WorkbookLayout.SHEETS.size) { "$part does not have the agreed number of sheets" }
        sheets.children.forEachIndexed { i, sheet ->
            checkWorkbook(sheet.namespace == NS_MAIN && sheet.name == "sheet" && sheet.children.isEmpty() &&
                sheet.attributes == mapOf("name" to WorkbookLayout.SHEETS[i], "sheetId" to "${i + 1}",
                    qualified(NS_REL, "id") to "rId${i + 1}")) { "$part sheet ${i + 1} name, order, ID or state differs" }
        }
    }

    private fun checkDefinedNames(names: XNode, model: WorkbookModel, part: String): Int {
        val last = model.bookings.lastRow
        val expected = listOf(Triple("_xlnm._FilterDatabase", WorkbookLayout.filterDatabaseFormula(last),
            mapOf("localSheetId" to "2", "hidden" to "1"))) +
            model.jumps.map { Triple(it.name, WorkbookLayout.jumpFormula(it, last), emptyMap()) }
        checkWorkbook(names.children.size == expected.size) { "$part does not have exactly one defined name per jump plus the filter" }
        val seen = HashSet<String>()
        names.children.zip(expected).forEachIndexed { i, (written, want) ->
            val (name, formula, extra) = want
            checkWorkbook(written.namespace == NS_MAIN && written.name == "definedName" && written.children.isEmpty()) {
                "$part defined name ${i + 1} is not a definedName element"
            }
            checkWorkbook(DEFINED_NAME.matches(name) && seen.add(name.lowercase())) {
                "$part defined name ${i + 1} has invalid characters or repeats another name"
            }
            checkWorkbook(written.attributes == mapOf("name" to name) + extra) { "$part defined name ${i + 1} attributes differ" }
            checkWorkbook(written.text == formula) { "$part defined name ${i + 1} formula differs from the allowlisted text" }
            checkRanges(formula) { "$part defined name ${i + 1} has an empty or inverted range" }
        }
        return expected.size
    }

    private val DEFINED_NAME = Regex("[A-Za-z_][A-Za-z0-9_.]*")
}
