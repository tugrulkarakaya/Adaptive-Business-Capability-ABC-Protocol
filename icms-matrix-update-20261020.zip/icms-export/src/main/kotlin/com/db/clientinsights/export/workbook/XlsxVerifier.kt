package com.db.clientinsights.export.workbook

import com.db.clientinsights.export.workbook.WorkbookLayout.S_INPUT
import com.db.clientinsights.export.workbook.WorkbookLayout.S_INPUT_DATE
import com.db.clientinsights.export.workbook.verify.BookingsChecks
import com.db.clientinsights.export.workbook.verify.CellKind
import com.db.clientinsights.export.workbook.verify.ChartChecks
import com.db.clientinsights.export.workbook.verify.CompanyReviewChecks
import com.db.clientinsights.export.workbook.verify.PackageChecks
import com.db.clientinsights.export.workbook.verify.PackageReader
import com.db.clientinsights.export.workbook.verify.SafeXml
import com.db.clientinsights.export.workbook.verify.SheetFeatures
import com.db.clientinsights.export.workbook.verify.WorksheetChecks
import com.db.clientinsights.export.workbook.verify.WorksheetFacts
import com.db.clientinsights.export.workbook.verify.WorksheetStream
import com.db.clientinsights.export.workbook.verify.WrittenRow
import java.nio.file.Path
import java.security.MessageDigest
import java.util.Locale

/**
 * Re-reads the written workbook, independently of the writer, and refuses it (WorkbookCheckFailure) when anything
 * differs from the model or breaks a safety rule. Small parts are parsed with DOM (DOCTYPE refused); worksheets are
 * streamed with StAX and compared row by row with the model's row sequences, so the Bookings tab is checked in
 * bounded memory. Every part's bytes are scanned for MAIN_PARENT. Returns counts only (for the receipt).
 */
internal object XlsxVerifier {
    private const val TEAM_DECISION_CELLS = 8
    private val RELATIONSHIP_PARTS = listOf("_rels/.rels", "xl/_rels/workbook.xml.rels",
        "xl/worksheets/_rels/sheet1.xml.rels", "xl/drawings/_rels/drawing1.xml.rels")

    /** Re-reads the written file and checks it against the model and the source; returns counts for the receipt. */
    fun verify(file: Path, model: WorkbookModel, review: ReviewData, collection: CollectionData): Map<String, Any?> {
        checkWorkbook(model.sheets.map { it.name } == WorkbookLayout.SHEETS) { "model tabs differ from the agreed review and evidence tabs" }
        checkWorkbook(review.companies.map { it.id } == collection.cohort) { "client order differs from the collection" }
        PackageReader.open(file).use { pkg ->
            val small = (listOf("[Content_Types].xml", "xl/workbook.xml", "xl/styles.xml", "xl/drawings/drawing1.xml",
                "xl/charts/chart1.xml") + RELATIONSHIP_PARTS).associateWith { pkg.bytes(it) }
            val trees = small.mapValues { (part, bytes) -> SafeXml.parseSmall(bytes, part) }
            PackageChecks.checkContentTypes(trees.getValue("[Content_Types].xml"))
            PackageChecks.checkRelationships(RELATIONSHIP_PARTS.associateWith { trees.getValue(it) })
            val definedNames = PackageChecks.checkWorkbook(trees.getValue("xl/workbook.xml"), model)
            PackageChecks.checkStyles(small.getValue("xl/styles.xml"), trees.getValue("xl/styles.xml"))

            val summaryRows = HashMap<Int, WrittenRow>()
            val mainRows = HashMap<Int, WrittenRow>()
            val rulesRows = HashMap<Int, WrittenRow>()
            val bookings = BookingsChecks(model, review)
            val facts = listOf(
                stream(pkg, model.summary, 1) { noInputStyle(it, model.summary.name); summaryRows[it.number] = it },
                stream(pkg, model.main, 2) { mainRows[it.number] = it },
                stream(pkg, model.bookings, 3) { noInputStyle(it, model.bookings.name); bookings.onRow(it) },
                stream(pkg, model.rules, 4) { rulesRows[it.number] = it },
                stream(pkg, model.companyEvidence, 5) { noInputStyle(it, model.companyEvidence.name) },
                stream(pkg, model.matrix, 6) { noInputStyle(it, model.matrix.name) },
            )
            pkg.checkAllScanned()
            val features = model.sheets.mapIndexed { i, sheet ->
                WorksheetChecks(model, sheet, partOf(i + 1)).check(facts[i].elements)
            }

            val chart = ChartChecks(model, review, summaryRows)
            val formulaCells = chart.checkProgressCell(model.sheets.zip(facts).associate { (s, f) -> s.name to f.formulaRefs })
            chart.checkTable()
            chart.checkDrawing(trees.getValue("xl/drawings/drawing1.xml"))
            val chartReferences = chart.checkChart(trees.getValue("xl/charts/chart1.xml"))

            val company = CompanyReviewChecks(model, review, mainRows).check()
            bookings.finish(collection.exportedBookingCount)
            val jumpsChecked = bookings.checkJumps(mainRows)
            val teamCells = checkTeamCells(rulesRows)
            checkWorkbook(jumpsChecked == features[1].hyperlinks && definedNames == 1 + jumpsChecked) {
                "links, jumps and defined names do not match one to one"
            }

            return linkedMapOf(
                "sheets" to WorkbookLayout.SHEETS,
                "companyRows" to company.companyRows,
                "companyDetailRows" to company.companyDetailRows,
                "candidateRows" to company.candidateRows,
                "parentDetailRows" to company.parentDetailRows,
                "companiesWithoutCandidates" to review.companies.count { it.candidates.isEmpty() },
                "bookingTableRows" to bookings.dataRows,
                "companiesWithoutBookings" to review.companies.count { it.bookings.isEmpty() },
                "unassignedBookings" to bookings.unassignedRows,
                "currentRecordsReconciled" to company.currentRecordsReconciled,
                "reviewInputRows" to company.reviewInputRows,
                "blankReviewerCells" to company.blankReviewerCells,
                "blankTeamDecisionCells" to teamCells,
                "cellsRoundTripped" to facts.sumOf { it.cellsCompared },
                "worksheetFormulaCells" to formulaCells,
                "definedNames" to definedNames,
                "hyperlinks" to features.sumOf(SheetFeatures::hyperlinks),
                "dataValidations" to features.sumOf(SheetFeatures::dataValidations),
                "conditionalFormats" to features.sumOf(SheetFeatures::conditionalFormats),
                "chartReferences" to chartReferences,
                "autoFilters" to features.sumOf(SheetFeatures::autoFilters),
                "ignoredErrorRanges" to features.sumOf(SheetFeatures::ignoredErrorRanges),
                "mainParentTokens" to 0,
                "unknownSignals" to review.unknownSignals,
                "unknownRelationshipTypes" to review.unknownRelationshipTypes,
                "companyOrderSha256" to sha256(company.companyOrder.joinToString("\n")),
            )
        }
    }

    private fun partOf(sheetNumber: Int) = "xl/worksheets/sheet$sheetNumber.xml"

    private fun stream(pkg: PackageReader, sheet: Sheet, number: Int, onRow: (WrittenRow) -> Unit): WorksheetFacts {
        val part = partOf(number)
        return pkg.stream(part) { WorksheetStream(part, sheet, onRow).read(it) }
    }

    /** Summary and Bookings carry no reviewer or team input cells. */
    private fun noInputStyle(row: WrittenRow, sheet: String) {
        checkWorkbook(row.cells.none { it.style == S_INPUT || it.style == S_INPUT_DATE }) {
            "$sheet row ${row.number} has input-cell styling"
        }
    }

    /** Rules and assumptions: exactly 8 team input cells, all blank; no date inputs. */
    private fun checkTeamCells(rows: Map<Int, WrittenRow>): Int {
        val inputs = rows.values.flatMap { row -> row.cells.filter { it.style == S_INPUT || it.style == S_INPUT_DATE } }
        checkWorkbook(inputs.size == TEAM_DECISION_CELLS && inputs.all { it.style == S_INPUT && it.kind == CellKind.BLANK }) {
            "${WorkbookLayout.RULES_SHEET} does not have exactly 8 blank team decision cells"
        }
        return inputs.size
    }

    private fun sha256(text: String): String =
        MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8)).joinToString("") { String.format(Locale.ROOT, "%02x", it) }
}
