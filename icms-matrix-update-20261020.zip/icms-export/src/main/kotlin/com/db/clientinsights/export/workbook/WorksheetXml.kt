package com.db.clientinsights.export.workbook

import com.db.clientinsights.export.workbook.WorkbookLayout.DATE_MAX
import com.db.clientinsights.export.workbook.WorkbookLayout.DATE_MIN
import com.db.clientinsights.export.workbook.WorkbookLayout.MAIN_HEADERS
import com.db.clientinsights.export.workbook.WorkbookLayout.MAX_HYPERLINKS
import com.db.clientinsights.export.workbook.WorkbookLayout.MAX_SHEET_ROWS
import com.db.clientinsights.export.workbook.WorkbookLayout.M_DATE
import com.db.clientinsights.export.workbook.WorkbookLayout.M_DECISION
import com.db.clientinsights.export.workbook.WorkbookLayout.M_SHARE
import com.db.clientinsights.export.workbook.WorkbookLayout.NS_MAIN
import com.db.clientinsights.export.workbook.WorkbookLayout.NS_REL
import com.db.clientinsights.export.workbook.WorkbookLayout.STYLE_COUNT
import java.io.Writer
import java.math.BigDecimal

/**
 * Writes one worksheet part, streaming its rows. Elements follow the CT_Worksheet order Excel requires: sheetPr,
 * dimension, sheetViews, sheetFormatPr, cols, sheetData, autoFilter, conditionalFormatting, dataValidations,
 * hyperlinks, pageMargins, pageSetup, ignoredErrors, drawing. Which optional blocks a tab gets is fixed by the tab:
 * outline, conditional formats, validations and links on Company review; AutoFilter on Bookings; the chart on Summary.
 */
internal object WorksheetXml {
    const val JUMP_TOOLTIP = "Go to the first of these bookings on the Bookings tab (clear filters first; this does not filter)"
    const val DECISION_ERROR = "Choose one of the listed options, or leave the cell empty."
    const val DATE_ERROR = "Enter a date, for example 2026-10-21, or leave the cell empty."

    /** Input message of the decision dropdown: the draft list says it is a draft; a team list (--decision-options) does not. */
    fun decisionPrompt(options: List<String>): String =
        if (options == WorkbookLayout.DRAFT_DECISION_OPTIONS) "Draft options until your team confirms them. Leave empty if not reviewed yet."
        else "Choose your team's decision. Leave empty if not reviewed yet."
    private val NUMBER = Regex("-?[0-9]+(\\.[0-9]+)?")
    private const val MAX_COLUMN = 16_384
    private const val MAX_OUTLINE_LEVEL = 7

    fun write(out: Writer, model: WorkbookModel, sheet: Sheet) {
        val isSummary = sheet === model.summary
        val isMain = sheet === model.main
        val isBookings = sheet === model.bookings
        val isEvidence = sheet === model.companyEvidence || sheet === model.matrix
        val last = sheet.lastRow
        out.write(XlsxWriter.XML_DECLARATION)
        out.write("<worksheet xmlns=\"$NS_MAIN\" xmlns:r=\"$NS_REL\">")
        if (isMain) out.write("<sheetPr><outlinePr summaryBelow=\"0\" summaryRight=\"1\"/></sheetPr>")
        out.write("<dimension ref=\"A1:${columnName(sheet.widths.size)}$last\"/>")
        writeSheetView(out, sheet, selected = isSummary)
        out.write("<sheetFormatPr defaultRowHeight=\"13.2\"${if (isMain) " outlineLevelRow=\"2\"" else ""}/>")
        writeColumns(out, sheet.widths)
        writeSheetData(out, sheet)
        if (isBookings) out.write("<autoFilter ref=\"${WorkbookLayout.bookingsFilterRef(last)}\"/>")
        if (isEvidence) out.write("<autoFilter ref=\"A1:${columnName(sheet.widths.size)}$last\"/>")
        // Ranges from row 2 are omitted when the tab has no data rows: never an inverted range such as A2:A1.
        if (isMain && last >= 2) writeConditionalFormats(out, last)
        if (isMain && model.reviewRows.isNotEmpty()) writeDataValidations(out, model.reviewRows, model.decisionOptions)
        if (isMain) writeHyperlinks(out, model.jumps)
        out.write("<pageMargins left=\"0.4\" right=\"0.4\" top=\"0.5\" bottom=\"0.5\" header=\"0.3\" footer=\"0.3\"/>")
        out.write("<pageSetup orientation=\"landscape\" fitToWidth=\"1\" fitToHeight=\"0\"/>")
        if (isMain && last >= 2) writeIgnoredErrors(out, WorkbookLayout.mainIdRanges(last))
        if (isBookings && last >= 2) writeIgnoredErrors(out, WorkbookLayout.bookingIdRanges(last))
        if (isSummary) out.write("<drawing r:id=\"rId1\"/>")
        out.write("</worksheet>")
    }

    /** Gridlines off; Summary is the selected tab; frozen header rows and ID columns as the sheet asks. */
    private fun writeSheetView(out: Writer, sheet: Sheet, selected: Boolean) {
        out.write("<sheetViews><sheetView showGridLines=\"0\"${if (selected) " tabSelected=\"1\"" else ""} workbookViewId=\"0\">")
        val columns = sheet.frozenColumns
        val rows = sheet.frozenRows
        if (columns > 0 || rows > 0) {
            val topLeft = columnName(columns + 1) + (rows + 1)
            val pane = when {
                columns > 0 && rows > 0 -> "bottomRight"
                rows > 0 -> "bottomLeft"
                else -> "topRight"
            }
            out.write("<pane")
            if (columns > 0) out.write(" xSplit=\"$columns\"")
            if (rows > 0) out.write(" ySplit=\"$rows\"")
            out.write(" topLeftCell=\"$topLeft\" activePane=\"$pane\" state=\"frozen\"/>")
            if (pane == "bottomRight") out.write("<selection pane=\"topRight\"/><selection pane=\"bottomLeft\"/>")
            out.write("<selection pane=\"$pane\" activeCell=\"$topLeft\" sqref=\"$topLeft\"/>")
        }
        out.write("</sheetView></sheetViews>")
    }

    private fun writeColumns(out: Writer, widths: List<Double>) {
        out.write("<cols>")
        widths.forEachIndexed { i, width ->
            out.write("<col min=\"${i + 1}\" max=\"${i + 1}\" width=\"${decimal(width)}\" customWidth=\"1\"/>")
        }
        out.write("</cols>")
    }

    /** Rows must come 1..lastRow without gaps, cells in ascending columns; anything else stops the build. */
    private fun writeSheetData(out: Writer, sheet: Sheet) {
        out.write("<sheetData>")
        var expected = 1
        for (row in sheet.rows()) {
            checkWorkbook(row.number == expected && row.number <= MAX_SHEET_ROWS) {
                "${sheet.name} row ${row.number} is out of order (expected row $expected)"
            }
            expected++
            writeRow(out, sheet.name, row)
        }
        checkWorkbook(expected - 1 == sheet.lastRow) {
            "${sheet.name} has ${expected - 1} rows but declares ${sheet.lastRow}"
        }
        out.write("</sheetData>")
    }

    private fun writeRow(out: Writer, sheetName: String, row: Row) {
        checkWorkbook(row.level in 0..MAX_OUTLINE_LEVEL) { "$sheetName row ${row.number} has an invalid outline level" }
        out.write("<row r=\"${row.number}\"")
        if (row.level > 0) out.write(" hidden=\"1\" outlineLevel=\"${row.level}\"")
        if (row.collapsed) out.write(" collapsed=\"1\"")
        row.height?.let {
            checkWorkbook(it > 0.0) { "$sheetName row ${row.number} has an invalid height" }
            out.write(" ht=\"${decimal(it)}\" customHeight=\"1\"")
        }
        out.write(">")
        var previousColumn = 0
        for (cell in row.cells) {
            val ref = columnName(cell.column) + row.number
            checkWorkbook(cell.column in (previousColumn + 1)..MAX_COLUMN) { "$sheetName $ref is out of column order" }
            previousColumn = cell.column
            writeCell(out, sheetName, ref, cell)
        }
        out.write("</row>")
    }

    /** Text as a literal inline string; numbers as values; the one formula with its cached value; styled blanks. */
    private fun writeCell(out: Writer, sheetName: String, ref: String, cell: Cell) {
        checkWorkbook(cell.style in 0 until STYLE_COUNT) { "$sheetName $ref has an unknown style" }
        val number = cell.number
        val text = cell.text
        checkWorkbook(number == null || (text == null && NUMBER.matches(number))) {
            "$sheetName $ref is not a plain number"
        }
        when {
            cell.formula != null -> {
                checkWorkbook(number != null) { "$sheetName $ref formula has no cached value" }
                out.write("<c r=\"$ref\" s=\"${cell.style}\"><f>${xmlEscape(cell.formula)}</f><v>$number</v></c>")
            }
            number != null -> out.write("<c r=\"$ref\" s=\"${cell.style}\"><v>$number</v></c>")
            text != null -> {
                checkCellText(text, sheetName, ref)
                out.write("<c r=\"$ref\" s=\"${cell.style}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">")
                out.write(xmlEscape(ooxmlLiteral(text)))
                out.write("</t></is></c>")
            }
            else -> out.write("<c r=\"$ref\" s=\"${cell.style}\"/>")
        }
    }

    /** (a) grey row once a reviewer status is recorded (dxf 0); (b) data bar on the key share (0 to 100). */
    private fun writeConditionalFormats(out: Writer, last: Int) {
        val share = columnName(M_SHARE)
        out.write("<conditionalFormatting sqref=\"A2:${columnName(MAIN_HEADERS.size)}$last\">")
        out.write("<cfRule type=\"expression\" dxfId=\"0\" priority=\"1\">")
        out.write("<formula>${xmlEscape(WorkbookLayout.recordedStatusFormula())}</formula></cfRule></conditionalFormatting>")
        out.write("<conditionalFormatting sqref=\"${share}2:$share$last\"><cfRule type=\"dataBar\" priority=\"2\">")
        out.write("<dataBar minLength=\"0\" maxLength=\"100\"><cfvo type=\"num\" val=\"0\"/><cfvo type=\"num\" val=\"100\"/>")
        out.write("<color rgb=\"FF9BC2E6\"/></dataBar></cfRule></conditionalFormatting>")
    }

    /** (1) reviewer decision list; (2) review date between DATE_MIN and DATE_MAX. Both on the reviewer rows only. */
    private fun writeDataValidations(out: Writer, reviewRows: List<Int>, options: List<String>) {
        out.write("<dataValidations count=\"2\">")
        out.write("<dataValidation type=\"list\" allowBlank=\"1\" showInputMessage=\"1\" showErrorMessage=\"1\"")
        out.write(" errorTitle=\"Reviewer decision\" error=\"${xmlEscape(DECISION_ERROR)}\"")
        out.write(" promptTitle=\"Reviewer decision\" prompt=\"${xmlEscape(decisionPrompt(options))}\"")
        out.write(" sqref=\"${WorkbookLayout.cellList(M_DECISION, reviewRows)}\">")
        out.write("<formula1>${xmlEscape(WorkbookLayout.decisionListFormula(options))}</formula1></dataValidation>")
        out.write("<dataValidation type=\"date\" operator=\"between\" allowBlank=\"1\" showErrorMessage=\"1\"")
        out.write(" errorTitle=\"Review date\" error=\"${xmlEscape(DATE_ERROR)}\"")
        out.write(" sqref=\"${WorkbookLayout.cellList(M_DATE, reviewRows)}\">")
        out.write("<formula1>$DATE_MIN</formula1><formula2>$DATE_MAX</formula2></dataValidation>")
        out.write("</dataValidations>")
    }

    /** In-workbook links to the jump names (location only, no relationship); omitted when there are none. */
    private fun writeHyperlinks(out: Writer, jumps: List<Jump>) {
        if (jumps.isEmpty()) return
        checkWorkbook(jumps.size <= MAX_HYPERLINKS) {
            "Company review needs ${jumps.size} links; a worksheet holds at most $MAX_HYPERLINKS (not truncated)"
        }
        out.write("<hyperlinks>")
        for (jump in jumps) {
            out.write("<hyperlink ref=\"${jump.cellRef}\" location=\"${xmlEscape(jump.name)}\"")
            out.write(" tooltip=\"${xmlEscape(JUMP_TOOLTIP)}\"/>")
        }
        out.write("</hyperlinks>")
    }

    /** Suppresses only the "number stored as text" indicator, only on the ID and code ranges. */
    private fun writeIgnoredErrors(out: Writer, sqref: String) {
        out.write("<ignoredErrors><ignoredError sqref=\"$sqref\" numberStoredAsText=\"1\"/></ignoredErrors>")
    }

    /** 54.0 -> "54", 13.2 -> "13.2" (never exponent notation). */
    private fun decimal(value: Double): String = BigDecimal.valueOf(value).stripTrailingZeros().toPlainString()
}
