package com.db.clientinsights.export.adapters.csv

import com.db.clientinsights.export.domain.*
import java.nio.file.Path

/** Separate views for decisions and raw evidence. Full records remain in evidence.json as well. */
class ReviewCsvExports(private val csv: CsvExports) {
    fun write(review: DeterministicReview, directory: Path): Map<String, Int> {
        val counts = linkedMapOf<String, Int>()
        fun table(name: String, headers: List<String>, rows: List<List<Any?>>) {
            counts[name] = csv.writeTable(directory.resolve(name), headers, rows)
        }
        table("entity-review.csv", listOf("entity_id", "current_rule_status", "current_parent_count", "flagged_current",
            "baseline_parent_count", "flagged_baseline", "active_link_parent_count", "all_path_parent_count", "matched_keys",
            "keys_without_path", "keys_with_several_parents", "tied_baseline_keys", "shared_keys", "current_records", "active_records",
            "keys_with_several_current_parents", "evidence_ids", "query_run_ids"), review.entities.map {
            listOf(it.entityId.value, it.currentRuleStatus, it.currentParentCount, it.flaggedByCurrentRule, it.reportParentCount,
                it.flaggedByBaselineReport, it.activeLinkParentCount, it.allPathParentCount, it.matchedKeyCount, it.keysWithoutPath,
                it.keysWithSeveralParents, it.tiedReportKeys, it.sharedKeyCount, it.currentRecords, it.activeBookingRecords,
                it.keysWithSeveralCurrentParents, it.evidenceIds.joinToString("|"), it.queryRunIds.joinToString("|"))
        })
        table("booking-review.csv", listOf("entity_id", "booking_record_id", "resolution", "assigned_crds_id_check", "rhp_id", "rhp_name",
            "ultimate_parent_id", "ultimate_parent_name", "current_parents_on_key", "reporting_group_id", "reporting_group_name",
            "reporting_group_check", "is_reporting_level", "name_signal", "settlement_routings", "account_types", "last_routing_change",
            "unused_confidence", "if_no_recent_trading", "missing_activity_inputs", "rhp_industry_status", "rhp_status_date",
            "parent_industry_status", "parent_status_date", "activated_db_le_id", "override_source", "crds_path_statuses",
            "evidence_ids", "query_run_ids"), review.bookings.map {
            listOf(it.entityId.value, it.bookingRecordId, it.resolution, it.assignedCrdsIdCheck, it.rhpId, it.rhpName,
                it.ultimateParentId, it.ultimateParentName, it.currentParentsOnKey, it.reportingGroupId, it.reportingGroupName,
                it.reportingGroupCheck, it.reportingLevel, it.nameSignal, it.settlementRoutingCount, it.routingAccountTypes.joinToString("|"),
                it.lastRoutingChange, it.unused.level, it.unused.ifNoRecentTrading, it.unused.missingInputs.joinToString("|"),
                it.rhpIndustryStatus, it.rhpIndustryStatusDate, it.parentIndustryStatus, it.parentIndustryStatusDate,
                it.activatedDbLeId, it.overrideSource, it.statuses.entries.joinToString("|") { (key, value) -> "$key=${value.orEmpty()}" },
                it.evidenceIds.joinToString("|"), it.queryRunIds.joinToString("|"))
        })
        table("parent-candidates.csv", listOf("entity_id", "parent_id", "name", "standard_name", "key_count", "key_share_percent",
            "active_link_keys", "baseline_keys", "shared_keys", "current_records", "current_booking_codes", "party_status", "status_date",
            "surviving_entity_id", "own_ultimate_parent_ids", "own_immediate_parent_ids", "link_statuses", "signals", "evidence_ids", "query_run_ids"), review.parents.map {
            listOf(it.entityId.value, it.parentId, it.name, it.standardName, it.keyCount, it.keySharePercent, it.activeLinkKeyCount,
                it.reportKeyCount, it.sharedKeyCount, it.currentRecordCount, it.currentBookingCodeCount, it.partyStatus, it.partyStatusDate,
                it.survivingEntityId, it.ownUltimateParentIds.joinToString("|"), it.ownImmediateParentIds.joinToString("|"),
                it.linkStatuses.joinToString("|"), it.signals.joinToString("|"), it.evidenceIds.joinToString("|"), it.queryRunIds.joinToString("|"))
        })
        table("parent-relationships.csv", listOf("entity_id", "first_parent_id", "second_parent_id", "type", "source", "detail", "evidence_ids", "query_run_ids"),
            review.relationships.map { listOf(it.entityId.value, it.firstParentId, it.secondParentId, it.type, it.source, it.detail,
                it.evidenceIds.joinToString("|"), it.queryRunIds.joinToString("|")) })
        val f = review.facts
        table("bank-lei-selection.csv", listOf("party_id", "recorded_lei", "selection_status", "warnings", "evidence_ids", "query_run_ids"), review.identitySelections.map {
            listOf(it.partyId, it.lei, it.status, it.warnings.joinToString("|"), it.evidenceIds.joinToString("|"), it.queryRunIds.joinToString("|"))
        })
        table("parent-paths.csv", listOf("crds_system_id", "booking_code", "hierarchy_parent_id", "baseline_parent_id", "path_count",
            "active_link_paths", "baseline_rank_paths", "tie_at_baseline_rank", "link_statuses", "evidence_id", "query_run_id"), f.paths.map { row ->
            val p = row.data
            listOf(p.systemId, p.bookingCode, p.hierarchyParentId, p.reportParentId, p.pathCount, p.activeLinkPaths,
                p.reportRankPaths, p.tieAtReportRank, p.linkStatuses.joinToString("|"), row.origin.evidenceId, row.origin.queryRunId)
        })
        table("party-facts.csv", listOf("party_id", "standard_name", "legal_name", "surviving_entity_id", "industry_status", "status_date",
            "ultimate_parent_id", "immediate_parent_id", "evidence_id", "query_run_id"), f.parties.map { row ->
            val p = row.data
            listOf(p.partyId, p.standardName, p.legalName, p.survivingEntityId, p.industryStatus, p.industryStatusDate,
                p.ultimateParentId, p.immediateParentId, row.origin.evidenceId, row.origin.queryRunId)
        })
        table("salesforce-hierarchy.csv", listOf("party_id", "name", "legal_ultimate_parent_id", "legal_immediate_parent_id", "explicit_group_id",
            "is_reporting_level", "resolved_group_id") + (1..25).map { "l${it}_crds_id" } + listOf("evidence_id", "query_run_id"), f.salesforce.map { row ->
            val p = row.data
            listOf(p.partyId, p.name, p.legalUltimateParentId, p.legalImmediateParentId, p.reportingGroupId, p.reportingLevel,
                p.resolvedReportingGroupId()) + (0..24).map { p.pathIds.getOrNull(it) } + listOf(row.origin.evidenceId, row.origin.queryRunId)
        })
        val identityFields = listOf("lei", "valid_from", "valid_to", "expiry_date", "updated_at", "db_le_name", "country", "bic", "status",
            "address_type", "address_line1", "address_line2", "address_line3", "address_line4", "postal_code")
        table("bank-identity-evidence.csv", listOf("party_id", "kind") + identityFields + listOf("evidence_id", "query_run_id"), f.identities.map { row ->
            listOf(row.data.partyId, row.data.kind) + identityFields.map { row.data.fields[it] } + listOf(row.origin.evidenceId, row.origin.queryRunId)
        })
        table("settlement-routings.csv", listOf("entity_id", "booking_code", "icms_system_id", "routing_count", "block_count", "fund_count", "last_change", "evidence_id", "query_run_id"), f.routings.map { row ->
            val r = row.data
            listOf(r.entityId.value, r.bookingCode, r.settlementSystemId, r.count, r.blockCount, r.count - r.blockCount,
                r.lastChangeDate, row.origin.evidenceId, row.origin.queryRunId)
        })
        table("shared-booking-keys.csv", listOf("entity_id", "booking_code", "icms_system_id", "other_entity_id", "other_entity_name", "evidence_id", "query_run_id"), f.sharedKeys.map { row ->
            val s = row.data
            listOf(s.entityId.value, s.bookingCode, s.settlementSystemId, s.otherEntityId.value, s.otherEntityName, row.origin.evidenceId, row.origin.queryRunId)
        })
        table("assignment-lineage.csv", listOf("booking_record_id", "entity_id", "booking_code", "icms_system_id", "assigned_crds_party_id", "source_status",
            "activated_db_le_id", "override_source", "evidence_id", "query_run_id"), f.assignments.map { row ->
            listOf(row.data.recordId, row.data.entityId.value, row.data.bookingCode, row.data.settlementSystemId, row.data.assignedCrdsPartyId, row.data.status,
                row.data.activatedDbLeId, row.data.overrideSource, row.origin.evidenceId, row.origin.queryRunId)
        })
        table("assignment-key-summary.csv", listOf("entity_id", "booking_code", "icms_system_id", "assignment_count", "active_assignment_count",
            "distinct_direct_crds_ids", "missing_direct_crds_ids", "with_activated_db_le", "override_assignments", "source_status", "evidence_ids", "query_run_ids"),
            f.assignments.groupBy { Triple(it.data.entityId, it.data.bookingCode, it.data.settlementSystemId) }.map { (key, rows) ->
                val queries = f.queries.filter { it.dataset == "ASSIGNMENT_LINEAGE" && key.first.value in it.requestedKeys }
                listOf(key.first.value, key.second, key.third, rows.size, rows.count { it.data.status == "Active" },
                    rows.mapNotNull { it.data.assignedCrdsPartyId }.distinct().size, rows.count { it.data.assignedCrdsPartyId == null },
                    rows.count { it.data.activatedDbLeId != null }, rows.count { it.data.overrideSource == "1" },
                    if (queries.isEmpty()) FetchStatus.NOT_CONFIGURED else combineFetchStatuses(queries.map { it.status }),
                    rows.joinToString("|") { it.origin.evidenceId }, rows.map { it.origin.queryRunId }.distinct().joinToString("|"))
            })
        table("routing-lineage.csv", listOf("entity_id", "booking_code", "icms_system_id", "route_count", "active_route_count", "matching_assignment_ids",
            "account_count", "requested_entity_accounts", "missing_accounts", "other_entity_routes", "evidence_id", "query_run_id"), f.routingLineage.map { row ->
            val r = row.data
            listOf(r.entityId.value, r.bookingCode, r.settlementSystemId, r.routeCount, r.activeRouteCount, r.matchingAssignmentIdCount,
                r.accountCount, r.requestedEntityAccountCount, r.missingAccountCount, r.otherEntityRouteCount, row.origin.evidenceId, row.origin.queryRunId)
        })
        table("activity-readiness.csv", listOf("source", "accessibility", "recent_trading", "limitation"), f.activityAvailability.map {
            listOf(it.source, it.accessibility, it.recentTrading, it.limitation)
        })
        counts.putAll(PlatformCsvExports(csv).write(review, directory))
        counts.putAll(ThemeB6CsvExports(csv).write(review, directory))
        counts.putAll(UsageCsvExports(csv).write(review, directory))
        return counts
    }
}
