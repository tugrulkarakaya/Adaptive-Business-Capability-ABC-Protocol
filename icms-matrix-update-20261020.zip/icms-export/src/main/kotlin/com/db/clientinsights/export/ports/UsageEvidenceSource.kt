package com.db.clientinsights.export.ports

import com.db.clientinsights.export.domain.*

/** Independent read-only source boundary. Wire only after its joins and trade coverage are validated. */
fun interface UsageEvidenceSource {
    fun fetch(request: ExportRequest, facts: ExtractedFacts): UsageEvidenceFacts
}
