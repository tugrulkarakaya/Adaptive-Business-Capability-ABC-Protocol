package com.db.clientinsights.export.rules

import com.db.clientinsights.export.domain.*
import java.util.Locale

/** Implements each suggested Confluence row separately, with no unapproved combined decision. */
class ThemeB6Rules {
    fun assess(rhpIndustryStatus: String?, parentIndustryStatus: String?, crdsBookingStatus: String?,
               settlementRoutings: Boolean?, confirmationRoutings: Boolean?,
               recentTrading: Boolean?): List<ThemeB6CategoryAssessment> = listOf(
        inactiveParty(normalize(rhpIndustryStatus), normalize(parentIndustryStatus), recentTrading),
        inactiveBooking(normalize(crdsBookingStatus), recentTrading),
        routing(settlementRoutings, confirmationRoutings, recentTrading),
    )

    fun evaluate(core: CheckResults, facts: ReviewFacts, bookings: List<BookingReview>,
                 usage: UsageReview = UsageReview()): ThemeB6Review {
        val paths = facts.allStatusPaths.groupBy { crdsBookingKey(it.data.systemId, it.data.bookingCode) }
        val parties = facts.parties.groupBy { it.data.partyId }
        val reviewed = bookings.associateBy { it.entityId to it.bookingRecordId }
        val usageByBooking = usage.bookings.associateBy { it.entityId to it.bookingRecordId }
        val runs = facts.queries.flatMap { run -> run.requestedKeys.map { (run.dataset to it) to run } }
            .groupBy({ it.first }, { it.second })
        fun sourceRuns(dataset: String, key: String) = runs[dataset to key].orEmpty()
        fun complete(dataset: String, key: String): Boolean = sourceRuns(dataset, key).let {
            it.isNotEmpty() && it.all { run -> run.status == FetchStatus.COMPLETE && !run.truncated }
        }
        fun status(dataset: String, key: String): FetchStatus = sourceRuns(dataset, key).let {
            if (it.isEmpty()) FetchStatus.NOT_CONFIGURED
            else combineFetchStatuses(it.map { run -> if (run.truncated) FetchStatus.PARTIAL else run.status })
        }
        val assessments = core.bookings.filter { it.booking.data.status.equals("Active", true) }.flatMap { booking ->
            val record = booking.booking.data
            val current = reviewed[record.entityId to record.id]
            val system = booking.bookingSystem?.data?.crdsSystemId?.value
                ?.takeIf { booking.bookingSystem.data.id in core.knownSystemMappings }
            val key = crdsBookingKey(system, record.bookingCode)
            val candidates = if (key == null) emptyList() else paths[key].orEmpty()
            val selected = candidates.map { it as SourceRow<AllStatusBookingPath>? }.ifEmpty { listOf(null) }
            selected.map { row ->
                val path = row?.data
                val rhpRows = parties[path?.rhpId].orEmpty()
                val parentRows = parties[path?.ultimateParentId].orEmpty()
                val rhpStatus = unique(rhpRows.map { it.data.industryStatus?.let(::normalize) })
                val parentStatus = unique(parentRows.map { it.data.industryStatus?.let(::normalize) })
                val readStatus = status("ALL_BOOKING_STATUS_PATHS", record.entityId.value)
                val rhpKnown = path?.rhpId?.let { complete("CRDS_PARTIES", it) } == true
                val parentKnown = path?.ultimateParentId?.let { complete("CRDS_PARTIES", it) } == true
                val activity = usageByBooking[record.entityId to record.id]
                val methodAttributionMissing = (current?.settlementRoutingCount ?: 0) > 0
                // A zero over the wider key proves zero for each method. A positive total does not identify which method.
                val settlementForRecord = if (current?.settlementRoutingCount == 0L) false else null
                val categories = assess(if (rhpKnown) rhpStatus else null, if (parentKnown) parentStatus else null,
                    path?.bookingStatus, settlementForRecord,
                    activity?.confirmationRoutings, activity?.recentTrading)
                    .map { category ->
                        if (category.category == ROUTING && methodAttributionMissing)
                            category.copy(missingInputs = (category.missingInputs + "SETTLEMENT_METHOD_ROUTING_ATTRIBUTION").distinct(),
                                explanation = category.explanation + " The positive legacy routing total is shared across settlement methods and cannot establish routing for this record.")
                        else if (category.category != ROUTING && (readStatus != FetchStatus.COMPLETE || path == null))
                            category.copy(result = "NOT_DETERMINED", confidence = null,
                                missingInputs = (category.missingInputs + "ALL_BOOKING_STATUS_PATHS").distinct())
                        else category
                    }
                val origins = listOfNotNull(booking.booking.origin, booking.bookingSystem?.origin, row?.origin) + rhpRows.map { it.origin } + parentRows.map { it.origin }
                ThemeB6BookingAssessment(record.entityId, record.id, system, record.bookingCode,
                    record.settlementMethodId, row?.origin?.evidenceId, path?.rhpId, rhpStatus,
                    unique(rhpRows.map { it.data.industryStatusDate }), path?.ultimateParentId, parentStatus,
                    unique(parentRows.map { it.data.industryStatusDate }), normalize(path?.bookingStatus),
                    path?.bookingStatusDate,
                    path != null && current?.resolution == "CURRENT_PATH" && path.rhpId == current.rhpId &&
                        path.ultimateParentId == current.ultimateParentId,
                    readStatus, categories, (origins.map { it.evidenceId } + current?.evidenceIds.orEmpty() +
                        activity?.evidenceIds.orEmpty()).distinct(),
                    (origins.map { it.queryRunId } + current?.queryRunIds.orEmpty() + activity?.queryRunIds.orEmpty() +
                        sourceRuns("CURRENT_BOOKING_PATHS", record.entityId.value).map { it.queryRunId } +
                        sourceRuns("SETTLEMENT_ROUTINGS", record.entityId.value).map { it.queryRunId } +
                        sourceRuns("ALL_BOOKING_STATUS_PATHS", record.entityId.value).map { it.queryRunId } +
                        listOfNotNull(path?.rhpId, path?.ultimateParentId).flatMap { id -> sourceRuns("CRDS_PARTIES", id).map { it.queryRunId } }).distinct())
            }
        }
        val rhpSummaries = assessments.filter { it.rhpId != null }.groupBy { it.entityId to checkNotNull(it.rhpId) }
            .map { (key, rows) ->
                val partyRows = parties[key.second].orEmpty()
                val statuses = partyRows.mapNotNull { normalize(it.data.industryStatus) }.distinct().sorted()
                ThemeB6RhpSummary(key.first, key.second, statuses,
                    partyRows.mapNotNull { it.data.industryStatusDate }.distinct().sorted(),
                    statuses.any { it !in ACTIVE_PARTY }, rows.any { it.rhpIndustryStatus == null } ||
                        !complete("CRDS_PARTIES", key.second) || rows.any { it.sourceStatus != FetchStatus.COMPLETE },
                    rows.map { it.bookingRecordId }.distinct().size,
                    rows.flatMap { it.evidenceIds }.distinct(), rows.flatMap { it.queryRunIds }.distinct())
            }
        val parentSummaries = assessments.filter { it.ultimateParentId != null }
            .groupBy { it.entityId to checkNotNull(it.ultimateParentId) }.map { (key, rows) ->
                val records = rows.groupBy { it.bookingRecordId }
                val counts = records.values.groupingBy { recordPaths ->
                    val statuses = recordPaths.map { it.crdsBookingStatus }.distinct()
                    when {
                        statuses.all { it == null } -> "UNKNOWN"
                        statuses.size > 1 -> "AMBIGUOUS"
                        else -> checkNotNull(statuses.single())
                    }
                }.eachCount().toSortedMap()
                ThemeB6ParentSummary(key.first, key.second, records.size,
                    rows.mapNotNull { it.bookingCode }.distinct().size,
                    rows.filter { it.matchesCurrentPartyPair }.map { it.bookingRecordId }.distinct().size,
                    counts, rows.mapNotNull { it.crdsBookingStatus }.distinct().sorted(),
                    status("ALL_BOOKING_STATUS_PATHS", key.first.value),
                    rows.flatMap { it.evidenceIds }.distinct(), rows.flatMap { it.queryRunIds }.distinct())
            }
        return ThemeB6Review(assessments, rhpSummaries, parentSummaries)
    }

    private fun inactiveParty(rhp: String?, parent: String?, trading: Boolean?): ThemeB6CategoryAssessment = when {
        rhp in ACTIVE_PARTY -> noSignal(INACTIVE_PARTY, "RHP is ACTIVE or IN_FORMATION; this matrix category does not apply.")
        rhp !in INACTIVE_PARTY_STATUSES -> unknown(INACTIVE_PARTY, listOf("RHP_INDUSTRY_STATUS"))
        parent in ACTIVE_PARTY -> conditional(INACTIVE_PARTY, "MEDIUM_HIGH", "MEDIUM", 1, 2, trading,
            "Inactive RHP with an active or in-formation parent. Human review must consider the status date and any trading.")
        parent in INACTIVE_PARTY_STATUSES -> conditional(INACTIVE_PARTY, "HIGH", "MEDIUM", 3, 4, trading,
            "RHP and ultimate parent have listed inactive industry statuses. Human review is required.")
        else -> unknown(INACTIVE_PARTY, listOf("ULTIMATE_PARENT_INDUSTRY_STATUS"))
    }

    private fun inactiveBooking(status: String?, trading: Boolean?): ThemeB6CategoryAssessment = when (status) {
        in ACTIVE_BOOKING -> noSignal(INACTIVE_BOOKING, "cRDS booking is ACTIVE or REACTIVATING; this category does not apply.")
        in INACTIVE_BOOKING_STATUSES -> conditional(INACTIVE_BOOKING, "HIGH", "MEDIUM", 5, 6, trading,
            "cRDS booking has a listed inactive status. This is a human-review signal, not an instruction to deactivate it.")
        else -> unknown(INACTIVE_BOOKING, listOf("CRDS_BOOKING_STATUS"))
    }

    private fun routing(settlement: Boolean?, confirmation: Boolean?, trading: Boolean?): ThemeB6CategoryAssessment {
        // A source contradiction must be investigated rather than hidden by the page's traversal assumption.
        if (settlement == false && confirmation == true)
            return ThemeB6CategoryAssessment(ROUTING, "NOT_DETERMINED", null, null, null, emptyList(),
                listOf("ROUTING_EVIDENCE_CONFLICT"),
                "Verified confirmation evidence conflicts with the zero settlement-routing count. Human review must resolve the sources before applying this category.")
        // No settlement route means there is no account traversal to confirmation routes, as the page assumes.
        val confirmed = if (settlement == false) false else confirmation
        if (trading == true) {
            val rows = when { settlement == false -> listOf(8); confirmed == false && settlement == true -> listOf(11)
                confirmed == true && settlement == true -> listOf(12); settlement == true -> listOf(11, 12)
                else -> listOf(8, 11, 12) }
            return ThemeB6CategoryAssessment(ROUTING, "APPLIES", "LOW", null, "LOW", rows, buildList {
                    if (settlement == null) add("SETTLEMENT_ROUTINGS")
                    else if (confirmed == null) add("CONFIRMATION_ROUTINGS")
                },
                "Validated recent trading gives LOW confidence of non-use in the routing category only.")
        }
        val missing = buildList {
            if (settlement == null) add("SETTLEMENT_ROUTINGS")
            else if (confirmed == null) add("CONFIRMATION_ROUTINGS")
        }
        if (missing.isNotEmpty()) return unknown(ROUTING, missing + if (trading == null) listOf("RECENT_TRADING") else emptyList())
        return when {
            settlement == false -> conditional(ROUTING, "HIGH", "LOW", 7, 8, trading, "No settlement routings; no confirmation traversal is possible.")
            confirmed == false -> conditional(ROUTING, "MEDIUM_HIGH", "LOW", 9, 11, trading, "Settlement routings exist but no confirmation routings were found.")
            else -> conditional(ROUTING, "MEDIUM", "LOW", 10, 12, trading, "Settlement and confirmation routings exist.")
        }
    }

    private fun conditional(category: String, no: String, yes: String, noRow: Int, yesRow: Int,
                            trading: Boolean?, explanation: String): ThemeB6CategoryAssessment =
        ThemeB6CategoryAssessment(category, if (trading == null) "NOT_DETERMINED" else "APPLIES",
            trading?.let { if (it) yes else no }, no, yes,
            when (trading) { true -> listOf(yesRow); false -> listOf(noRow); null -> listOf(noRow, yesRow) },
            if (trading == null) listOf("RECENT_TRADING") else emptyList(), explanation)

    private fun noSignal(category: String, explanation: String) = ThemeB6CategoryAssessment(category,
        "NO_SIGNAL", null, null, null, emptyList(), emptyList(), explanation)
    private fun unknown(category: String, missing: List<String>) = ThemeB6CategoryAssessment(category,
        "NOT_DETERMINED", null, null, null, emptyList(), missing,
        "Required validated evidence is missing or its status is outside the specified matrix; no conclusion is made.")
    private fun unique(values: List<String?>): String? = values.distinct().singleOrNull()
    private fun normalize(value: String?): String? = value?.trim()?.uppercase(Locale.ROOT)?.takeIf { it.isNotEmpty() }

    companion object {
        const val INACTIVE_PARTY = "INACTIVE_CRDS_LEGAL_ENTITY"
        const val INACTIVE_BOOKING = "INACTIVE_CRDS_BOOKING_CODE"
        const val ROUTING = "ROUTINGS_AND_TRADING"
        val ACTIVE_PARTY = setOf("ACTIVE", "IN_FORMATION")
        val INACTIVE_PARTY_STATUSES = setOf("IN_ADMINISTRATION", "IN_LIQUIDATION", "DELETED", "INACTIVE", "ABANDONED")
        val ACTIVE_BOOKING = setOf("ACTIVE", "REACTIVATING")
        val INACTIVE_BOOKING_STATUSES = setOf("DELETED", "INACTIVE", "SUSPENDED")
    }
}
