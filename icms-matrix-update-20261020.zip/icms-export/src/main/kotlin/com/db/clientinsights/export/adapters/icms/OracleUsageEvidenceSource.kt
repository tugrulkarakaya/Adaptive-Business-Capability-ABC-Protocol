package com.db.clientinsights.export.adapters.icms

import com.db.clientinsights.export.domain.*
import com.db.clientinsights.export.ports.UsageEvidenceSource

/** Only validated usage joins belong here. Missing confirmation/trade sources remain unconfigured. */
class OracleUsageEvidenceSource(private val executor: (String) -> JdbcQueryExecutor) : UsageEvidenceSource {
    override fun fetch(request: ExportRequest, facts: ExtractedFacts): UsageEvidenceFacts {
        val contacts = executor("contacts").fetch(CONTACT_PEOPLE, request.entityIds.map { it.value })
        return UsageEvidenceFacts(contacts = contacts.rows, queries = contacts.queries)
    }

    private companion object {
        val CONTACT_PEOPLE = QueryDefinition(SqlTemplate("contact-people"), "ACTIVE_CONTACT_PEOPLE", { row ->
            val id = checkNotNull(row.idText("id"))
            ContactPersonFact(id, IcmsEntityId.parse(checkNotNull(row.idText("le_id"))), id,
                row.getString("status"), platformName = null, nameOnPlatform = null)
        }, ContactPersonFact::rowId)
    }
}
