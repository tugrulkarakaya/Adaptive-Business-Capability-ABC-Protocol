package com.db.clientinsights.export.adapters.icms

import com.db.clientinsights.export.domain.QueryLimits
import com.db.clientinsights.export.domain.invalidInput
import java.nio.file.Files
import java.nio.file.Path
import java.sql.DriverManager
import java.time.Instant
import java.time.format.DateTimeParseException
import java.util.Properties

/**
 * Credentials never enter the facts, manifests, SQL resources or exception text.
 *
 * Invalid settings raise InvalidInputException; failures of the environment lookup itself propagate unchanged.
 */
class OracleSourceConfiguration private constructor(
    private val properties: Properties,
    private val environment: (String) -> String?,
) {
    val limits = configured("Invalid query limits.") {
        QueryLimits(
            integer("query.batch-size", 500), integer("query.page-size", 1000),
            integer("query.max-rows", 100000), integer("query.timeout-seconds", 60),
        )
    }

    fun executor(prefix: String): JdbcQueryExecutor {
        require(prefix in setOf("icms", "references", "cohort", "review", "parties", "salesforce", "identity", "routings", "activity",
            "platforms", "native-bookings", "contacts"))
        val inherited = if (prefix != "icms" && properties.getProperty("$prefix.jdbc.url") == null) "icms" else prefix
        fun value(suffix: String): String? = properties.getProperty("$prefix.$suffix")
            ?: properties.getProperty("$inherited.$suffix")
        val url = value("jdbc.url")?.trim()?.takeIf { it.isNotEmpty() }
        val sourceId = properties.getProperty("$prefix.source-id") ?: prefix
        val schema = value("schema")?.trim().orEmpty()
        val snapshotAt = value("snapshot-at")?.also { requireInstant(prefix, it) }
        val factory = url?.let {
            if (!it.startsWith("jdbc:oracle:")) invalidInput("Only Oracle JDBC URLs are supported by this adapter.")
            val username = value("username") ?: invalidInput("Missing $prefix.username.")
            val passwordVariable = passwordVariable(prefix, value("password-env"), separateUrl = inherited != "icms")
            val password = environment(passwordVariable)
                ?: invalidInput("Missing environment variable $passwordVariable.")
            val connectionTimeout = integer("connection.timeout-seconds", 15)
            if (connectionTimeout !in 1..3600) invalidInput("Connection timeout must be between 1 and 3600 seconds.")
            ConnectionFactory {
                val credentials = Properties().apply {
                    setProperty("user", username)
                    setProperty("password", password)
                    setProperty("oracle.net.CONNECT_TIMEOUT", (connectionTimeout * 1000).toString())
                    setProperty("oracle.jdbc.ReadTimeout", (limits.timeoutSeconds * 1000).toString())
                }
                val connection = DriverManager.getConnection(url, credentials)
                try {
                    connection.autoCommit = false
                    connection.createStatement().use { statement ->
                        statement.queryTimeout = limits.timeoutSeconds
                        statement.execute("SET TRANSACTION READ ONLY")
                    }
                    connection
                } catch (error: Exception) {
                    connection.close()
                    throw error
                }
            }
        }
        return configured("Invalid source-id or schema for the $prefix source profile.") {
            JdbcQueryExecutor(sourceId, schema, factory, limits, snapshotAt)
        }
    }

    /** Reports a value rejected by domain or adapter validation as a configuration error with a fixed [message]. */
    private inline fun <T> configured(message: String, create: () -> T): T = try {
        create()
    } catch (_: IllegalArgumentException) {
        invalidInput(message)
    }

    /** Snapshot metadata must be an ISO-8601 instant; an unreadable value is a configuration error. */
    private fun requireInstant(prefix: String, snapshotAt: String) {
        try {
            Instant.parse(snapshotAt)
        } catch (_: DateTimeParseException) {
            invalidInput("Invalid snapshot-at for the $prefix source profile; " +
                "use an ISO-8601 instant such as 2026-10-19T06:00:00Z.")
        }
    }

    /** A separate non-ICMS URL must name its password variable; only ICMS and profiles sharing its URL default. */
    private fun passwordVariable(prefix: String, configured: String?, separateUrl: Boolean): String {
        if (configured == null) {
            if (separateUrl) {
                invalidInput("Missing $prefix.password-env; " +
                    "a separate $prefix.jdbc.url must name its password variable.")
            }
            return DEFAULT_PASSWORD_VARIABLE
        }
        if (configured.isBlank()) invalidInput("Blank password-env for the $prefix source profile.")
        return configured
    }

    private fun integer(key: String, fallback: Int): Int = properties.getProperty(key)?.let {
        it.toIntOrNull() ?: invalidInput("Invalid integer for $key.")
    } ?: fallback

    companion object {
        private const val DEFAULT_PASSWORD_VARIABLE = "ICMS_DB_PASSWORD"

        fun load(path: Path, environment: (String) -> String? = System::getenv): OracleSourceConfiguration {
            val properties = Properties().apply { Files.newBufferedReader(path).use { load(it) } }
            return OracleSourceConfiguration(properties, environment)
        }
    }
}
