package com.db.clientinsights.export.workbook

/**
 * The fixed layout of the human review workbook: tab names, columns, styles and the allowlisted formula texts.
 *
 * The workbook presents an existing export collection for people to review. It adds no business rule, chooses no
 * parent, never shows MAIN_PARENT and leaves every reviewer cell blank. The writer and the verifier both build their
 * formula texts from the functions below, so the verifier can allowlist each formula exactly.
 */
internal object WorkbookLayout {
    const val MAX_CELL_TEXT = 32_767
    /** Excel worksheet limits: rows per sheet (including the header) and hyperlinks per sheet. */
    const val MAX_SHEET_ROWS = 1_048_576
    const val MAX_HYPERLINKS = 65_530

    const val SUMMARY_SHEET = "Summary"
    const val MAIN_SHEET = "Company review"
    const val BOOKINGS_SHEET = "Bookings"
    const val RULES_SHEET = "Rules and assumptions"
    const val COMPANY_EVIDENCE_SHEET = "Company evidence"
    const val MATRIX_SHEET = "Matrix review"
    val SHEETS = listOf(SUMMARY_SHEET, MAIN_SHEET, BOOKINGS_SHEET, RULES_SHEET, COMPANY_EVIDENCE_SHEET, MATRIX_SHEET)

    /** The team's draft reviewer statuses (register #29) until the team confirms them; a CLI option replaces them. */
    val DRAFT_DECISION_OPTIONS = listOf("Correct as is", "Needs correction", "Need more information")

    // Company review columns (1-based). Text: A-D, K, L, N, O. Numbers or blank: E-J. Date: P.
    val MAIN_HEADERS = listOf(
        "Client ID", "Parent ID", "Name", "Row", "Current parents (current rule)", "Parents (original selection check)",
        "Key share", "Matched keys", "Active-link keys", "Bookings (click the number)", "Evidence",
        "Summary and details (not a decision)", "Reviewer decision", "Reviewer comment", "Reviewer name", "Review date")
    const val M_CLIENT = 1
    const val M_PARENT = 2
    const val M_NAME = 3
    const val M_ROW = 4
    const val M_CURRENT = 5
    const val M_ORIGINAL = 6
    const val M_SHARE = 7
    const val M_KEYS = 8
    const val M_ACTIVE = 9
    const val M_BOOKINGS = 10
    const val M_EVIDENCE = 11
    const val M_TEXT = 12
    const val M_DECISION = 13
    const val M_COMMENT = 14
    const val M_REVIEWER = 15
    const val M_DATE = 16
    val REVIEW_INPUT_COLUMNS = listOf(M_DECISION, M_COMMENT, M_REVIEWER, M_DATE)
    val MAIN_WIDTHS = listOf(10.0, 10.0, 32.0, 22.0, 10.0, 10.0, 9.0, 9.0, 9.0, 11.0, 11.0, 60.0, 22.0, 32.0, 16.0, 12.0)
    const val MAIN_HEADER_HEIGHT = 54.0

    /** Column D values. The progress formula counts client rows through ROW_CLIENT. */
    const val ROW_CLIENT = "Client"
    const val ROW_CLIENT_DETAILS = "Client details"
    const val ROW_CURRENT = "Current parent"
    const val ROW_OTHER = "Other parent"
    const val ROW_NOT_OBSERVED = "Parent, current not observed"
    const val ROW_PARENT_DETAILS = "Parent details"

    // Bookings columns, one per fact, plus two literal jump keys used by the link names.
    val BOOKING_HEADERS = listOf(
        "Client ID", "Client name", "Booking record ID", "Booking code", "ICMS system ID", "ICMS system name",
        "cRDS system", "ICMS status", "Settlement method", "Selected parent ID (current-path rule)",
        "Selected parent name", "Eligible current parents on this key (count)", "Current-path result", "RHP ID",
        "RHP name", "RHP cRDS status", "RHP status date", "Assigned cRDS ID", "Assigned-ID check (comparison only)",
        "Salesforce reporting group ID", "Reporting group name", "Reporting group check", "Settlement routings (count)",
        "Routing account types", "Last routing change",
        "Platform names: verified booking ID (not proof of identity, ownership or use)",
        "Platform names: booking key only (not proof of identity, ownership or use)",
        "Platform names: other link status, with reason (not proof of identity, ownership or use)",
        "Reference lookup", "Data quality", "Client jump key (used by links; do not edit)",
        "Parent jump key (used by links; do not edit)")
    const val B_CLIENT = 1
    const val B_CLIENT_NAME = 2
    const val B_RECORD = 3
    const val B_CODE = 4
    const val B_SYSTEM_ID = 5
    const val B_SYSTEM_NAME = 6
    const val B_CRDS_SYSTEM = 7
    const val B_STATUS = 8
    const val B_METHOD = 9
    const val B_PARENT = 10
    const val B_PARENT_NAME = 11
    const val B_ON_KEY = 12
    const val B_RESULT = 13
    const val B_RHP = 14
    const val B_RHP_NAME = 15
    const val B_RHP_STATUS = 16
    const val B_RHP_DATE = 17
    const val B_ASSIGNED = 18
    const val B_ASSIGNED_CHECK = 19
    const val B_GROUP = 20
    const val B_GROUP_NAME = 21
    const val B_GROUP_CHECK = 22
    const val B_ROUTINGS = 23
    const val B_ACCOUNT_TYPES = 24
    const val B_ROUTING_CHANGE = 25
    const val B_NAMES_VERIFIED = 26
    const val B_NAMES_KEY_ONLY = 27
    const val B_NAMES_OTHER = 28
    const val B_REFERENCE = 29
    const val B_QUALITY = 30
    const val B_CLIENT_KEY = 31
    const val B_PARENT_KEY = 32
    val BOOKING_WIDTHS = listOf(10.0, 28.0, 12.0, 14.0, 10.0, 24.0, 14.0, 10.0, 18.0, 12.0, 28.0, 12.0, 36.0, 11.0,
        28.0, 12.0, 11.0, 11.0, 26.0, 12.0, 24.0, 16.0, 11.0, 18.0, 12.0, 36.0, 36.0, 40.0, 12.0, 12.0, 12.0, 12.0)
    const val BOOKING_HEADER_HEIGHT = 66.0
    /** Literal ID and code columns whose "number stored as text" indicator is suppressed (and nothing else). */
    val BOOKING_ID_COLUMNS = listOf(B_CLIENT, B_RECORD, B_CODE, B_SYSTEM_ID, B_CRDS_SYSTEM, B_PARENT, B_RHP,
        B_ASSIGNED, B_GROUP)

    /** Summary column widths and the chart size (EMU); the chart is anchored at column D. */
    val SUMMARY_WIDTHS = listOf(62.0, 12.0, 3.0, 70.0)
    val RULES_WIDTHS = listOf(30.0, 90.0, 20.0, 36.0)
    const val CHART_CX = 5_040_000L
    const val CHART_CY = 3_060_000L

    // Style indexes in STYLES_XML cellXfs. Company review and Bookings text styles do not wrap (one-line rows),
    // except S_DETAIL_TEXT on detail rows and the reviewer input cells.
    const val S_DEFAULT = 0
    const val S_HEADER = 1
    const val S_SUM_TEXT = 2
    const val S_SUM_INT = 3
    const val S_SUM_PCT = 4
    const val S_SUM_LINK = 5
    const val S_CHILD_TEXT = 6
    const val S_CHILD_INT = 7
    const val S_CHILD_PCT = 8
    const val S_CHILD_LINK = 9
    const val S_CHILD_MUTED = 10
    const val S_CURRENT = 11
    const val S_OTHER = 12
    const val S_INCOMPLETE = 13
    const val S_INPUT = 14
    const val S_INPUT_DATE = 15
    const val S_DETAIL_MUTED = 16
    const val S_DETAIL_LABEL = 17
    const val S_DETAIL_TEXT = 18
    const val S_DETAIL_BLANK = 19
    const val S_TITLE = 20
    const val S_SECTION = 21
    const val S_LABEL = 22
    const val S_TEXT = 23
    const val S_BOOK_TEXT = 24
    const val S_BOOK_INT = 25
    const val S_NOTE = 26
    const val S_FIGURE = 27
    const val S_TABLE_TEXT = 28
    const val S_TABLE_INT = 29
    const val STYLE_COUNT = 30

    /**
     * Arial 10; white-on-navy headers; light blue client rows; amber reviewer inputs; light orange "Incomplete";
     * blue underlined links; dxf 0 = light grey fill for rows with a recorded review status.
     */
    val STYLES_XML = """
        <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
        <styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
        <numFmts count="2"><numFmt numFmtId="164" formatCode="0.0&quot;%&quot;"/><numFmt numFmtId="165" formatCode="yyyy-mm-dd"/></numFmts>
        <fonts count="11">
        <font><sz val="10"/><name val="Arial"/><family val="2"/></font>
        <font><b/><sz val="10"/><name val="Arial"/><family val="2"/></font>
        <font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Arial"/><family val="2"/></font>
        <font><b/><sz val="14"/><name val="Arial"/><family val="2"/></font>
        <font><sz val="10"/><color rgb="FF595959"/><name val="Arial"/><family val="2"/></font>
        <font><i/><sz val="10"/><color rgb="FF404040"/><name val="Arial"/><family val="2"/></font>
        <font><u/><sz val="10"/><color rgb="FF0563C1"/><name val="Arial"/><family val="2"/></font>
        <font><b/><u/><sz val="10"/><color rgb="FF0563C1"/><name val="Arial"/><family val="2"/></font>
        <font><sz val="10"/><color rgb="FF7F7F7F"/><name val="Arial"/><family val="2"/></font>
        <font><b/><sz val="10"/><color rgb="FFC65911"/><name val="Arial"/><family val="2"/></font>
        <font><sz val="10"/><color rgb="FF404040"/><name val="Arial"/><family val="2"/></font>
        </fonts>
        <fills count="7">
        <fill><patternFill patternType="none"/></fill>
        <fill><patternFill patternType="gray125"/></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FF1F3864"/><bgColor indexed="64"/></patternFill></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFEAF0F8"/><bgColor indexed="64"/></patternFill></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFFFF2CC"/><bgColor indexed="64"/></patternFill></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFD9E1F2"/><bgColor indexed="64"/></patternFill></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFFCE4D6"/><bgColor indexed="64"/></patternFill></fill>
        </fills>
        <borders count="2">
        <border><left/><right/><top/><bottom/><diagonal/></border>
        <border><left style="thin"><color rgb="FFD9D9D9"/></left><right style="thin"><color rgb="FFD9D9D9"/></right><top style="thin"><color rgb="FFD9D9D9"/></top><bottom style="thin"><color rgb="FFD9D9D9"/></bottom><diagonal/></border>
        </borders>
        <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
        <cellXfs count="30">
        <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
        <xf numFmtId="0" fontId="2" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>
        <xf numFmtId="49" fontId="1" fillId="3" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="top"/></xf>
        <xf numFmtId="3" fontId="1" fillId="3" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>
        <xf numFmtId="164" fontId="1" fillId="3" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>
        <xf numFmtId="3" fontId="7" fillId="3" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>
        <xf numFmtId="49" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="top"/></xf>
        <xf numFmtId="3" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>
        <xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>
        <xf numFmtId="3" fontId="6" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>
        <xf numFmtId="49" fontId="4" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="top"/></xf>
        <xf numFmtId="49" fontId="1" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="top"/></xf>
        <xf numFmtId="49" fontId="8" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="top"/></xf>
        <xf numFmtId="49" fontId="9" fillId="6" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="top"/></xf>
        <xf numFmtId="0" fontId="0" fillId="4" borderId="1" xfId="0" applyFill="1" applyBorder="1" applyAlignment="1" applyProtection="1"><alignment vertical="top" wrapText="1"/><protection locked="0"/></xf>
        <xf numFmtId="165" fontId="0" fillId="4" borderId="1" xfId="0" applyNumberFormat="1" applyFill="1" applyBorder="1" applyAlignment="1" applyProtection="1"><alignment horizontal="left" vertical="top"/><protection locked="0"/></xf>
        <xf numFmtId="49" fontId="4" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="top"/></xf>
        <xf numFmtId="49" fontId="5" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="top"/></xf>
        <xf numFmtId="49" fontId="10" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="top" wrapText="1" indent="1"/></xf>
        <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"/>
        <xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1"/>
        <xf numFmtId="0" fontId="1" fillId="5" borderId="0" xfId="0" applyFont="1" applyFill="1"/>
        <xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>
        <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>
        <xf numFmtId="49" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="top"/></xf>
        <xf numFmtId="3" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>
        <xf numFmtId="0" fontId="4" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>
        <xf numFmtId="3" fontId="1" fillId="0" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1" applyAlignment="1"><alignment horizontal="right" vertical="top"/></xf>
        <xf numFmtId="49" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="top"/></xf>
        <xf numFmtId="3" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>
        </cellXfs>
        <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
        <dxfs count="1"><dxf><fill><patternFill><bgColor rgb="FFE7E6E6"/></patternFill></fill></dxf></dxfs>
        </styleSheet>
    """.trimIndent().replace("\n", "").replace("?><", "?>\n<")

    // ---------------------------------------------------------------- allowlisted formula texts

    /** The only worksheet cell formula: client rows (column D = ROW_CLIENT) with a recorded reviewer status. */
    fun progressFormula(mainLastRow: Int): String =
        "COUNTIFS('$MAIN_SHEET'!\$D\$2:\$D\$$mainLastRow,\"$ROW_CLIENT\",'$MAIN_SHEET'!\$M\$2:\$M\$$mainLastRow,\"<>\")"

    /** Defined-name formula of one jump: the first Bookings row (current sort order) whose key column holds the key. */
    fun jumpFormula(jump: Jump, bookingsLastRow: Int): String {
        val key = columnName(jump.keyColumn)
        return "INDEX($BOOKINGS_SHEET!\$A\$2:\$A\$$bookingsLastRow,MATCH(\"${jump.key}\"," +
            "$BOOKINGS_SHEET!\$$key\$2:\$$key\$$bookingsLastRow,0))"
    }

    /** The AutoFilter range of the Bookings tab, e.g. A1:AF29368. */
    fun bookingsFilterRef(bookingsLastRow: Int): String = "A1:${columnName(BOOKING_HEADERS.size)}$bookingsLastRow"

    /** The hidden _xlnm._FilterDatabase name formula, e.g. Bookings!$A$1:$AF$29368. */
    fun filterDatabaseFormula(bookingsLastRow: Int): String =
        "$BOOKINGS_SHEET!\$A\$1:\$${columnName(BOOKING_HEADERS.size)}\$$bookingsLastRow"

    /** Conditional format (a): a Company review row turns light grey once its reviewer status is recorded. */
    fun recordedStatusFormula(): String = "\$${columnName(M_DECISION)}2<>\"\""

    /** Data validation list: the options as one quoted, comma-separated literal. */
    fun decisionListFormula(options: List<String>): String = "\"" + options.joinToString(",") + "\""

    /** Review date validation bounds: every valid Excel date in the 1900 date system (1900-01-01 .. 9999-12-31). */
    const val DATE_MIN = "1"
    const val DATE_MAX = "2958465"

    /** Space-separated cell list of one column on the given rows, e.g. "M2 M4 M6". */
    fun cellList(column: Int, rows: List<Int>): String = rows.joinToString(" ") { columnName(column) + it }

    /** ignoredErrors sqref (numberStoredAsText only) of the Company review ID columns A and B. */
    fun mainIdRanges(mainLastRow: Int): String = "A2:B$mainLastRow"

    /** ignoredErrors sqref (numberStoredAsText only) of the Bookings ID, code and jump-key columns. */
    fun bookingIdRanges(bookingsLastRow: Int): String =
        (BOOKING_ID_COLUMNS.map { "${columnName(it)}2:${columnName(it)}$bookingsLastRow" } +
            "${columnName(B_CLIENT_KEY)}2:${columnName(B_PARENT_KEY)}$bookingsLastRow").joinToString(" ")

    /**
     * Validates --decision-options "a|b|c": 2 to 6 distinct options of 1 to 40 characters; no comma or double quote
     * (they would break Excel's list literal), no control character and no leading = + - @; at most 255 characters
     * in the list literal. Throws IllegalArgumentException (a usage error) otherwise.
     */
    fun decisionOptions(value: String): List<String> {
        val options = value.split('|').map { it.trim() }
        require(options.size in 2..6) { "--decision-options needs 2 to 6 options separated by |" }
        for (option in options) {
            require(option.length in 1..40) { "--decision-options: each option needs 1 to 40 characters" }
            require(',' !in option && '"' !in option) { "--decision-options: no comma or double quote" }
            require(option[0] !in "=+-@") { "--decision-options: an option must not start with = + - or @" }
            require(option.all { it >= ' ' }) { "--decision-options: no control characters" }
        }
        require(options.toSet().size == options.size) { "--decision-options: options must be distinct" }
        require(decisionListFormula(options).length <= 255) { "--decision-options: list is over 255 characters" }
        return options
    }

    // ---------------------------------------------------------------- package parts

    /** Package parts, in ZIP order. */
    val PARTS = listOf("[Content_Types].xml", "_rels/.rels", "xl/workbook.xml", "xl/_rels/workbook.xml.rels",
        "xl/styles.xml", "xl/worksheets/sheet1.xml", "xl/worksheets/_rels/sheet1.xml.rels", "xl/worksheets/sheet2.xml",
        "xl/worksheets/sheet3.xml", "xl/worksheets/sheet4.xml", "xl/worksheets/sheet5.xml", "xl/worksheets/sheet6.xml", "xl/drawings/drawing1.xml",
        "xl/drawings/_rels/drawing1.xml.rels", "xl/charts/chart1.xml")

    const val NS_MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    const val NS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    const val NS_PKG_REL = "http://schemas.openxmlformats.org/package/2006/relationships"
    const val NS_DRAWING = "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing"
    const val NS_CHART = "http://schemas.openxmlformats.org/drawingml/2006/chart"
    const val NS_A = "http://schemas.openxmlformats.org/drawingml/2006/main"
}

/** A workbook check failed: the input is inconsistent or the written file differs. The message names no business value. */
internal class WorkbookCheckFailure(message: String) : RuntimeException(message)

/** Throws WorkbookCheckFailure when the condition is false. */
internal fun checkWorkbook(condition: Boolean, message: () -> String) {
    if (!condition) throw WorkbookCheckFailure(message())
}

/** 1 -> A, 26 -> Z, 27 -> AA. */
internal fun columnName(n: Int): String {
    val b = StringBuilder()
    var v = n
    while (v > 0) {
        b.insert(0, 'A' + (v - 1) % 26)
        v = (v - 1) / 26
    }
    return b.toString()
}

/** A text value Excel can store: at most 32,767 UTF-16 units and XML-valid characters only (never altered). */
internal fun checkCellText(text: String, sheet: String, ref: String) {
    checkWorkbook(text.length <= WorkbookLayout.MAX_CELL_TEXT) {
        "$sheet $ref text has ${text.length} UTF-16 units, over Excel's 32,767 limit (not truncated; build stopped)"
    }
    var i = 0
    while (i < text.length) {
        val cp = text.codePointAt(i)
        val ok = cp == 0x9 || cp == 0xA || cp == 0xD || cp in 0x20..0xD7FF || cp in 0xE000..0xFFFD || cp in 0x10000..0x10FFFF
        checkWorkbook(ok) { "$sheet $ref text contains a character that XML cannot store (not stripped; build stopped)" }
        i += Character.charCount(cp)
    }
}

/** XML text and attribute escaping. Cell text goes through ooxmlLiteral first. */
internal fun xmlEscape(s: String): String {
    val b = StringBuilder(s.length + 16)
    for (ch in s) {
        when (ch) {
            '&' -> b.append("&amp;")
            '<' -> b.append("&lt;")
            '>' -> b.append("&gt;")
            '"' -> b.append("&quot;")
            '\r' -> b.append("&#13;")
            '\n' -> b.append("&#10;")
            '\t' -> b.append("&#9;")
            else -> b.append(ch)
        }
    }
    return b.toString()
}

private val OOXML_ESCAPE = Regex("_(?=[xX][0-9A-Fa-f]{4}_)")
private val OOXML_CODE = Regex("_[xX]([0-9A-Fa-f]{4})_")

/**
 * Excel decodes _xHHHH_ in cell text as a character escape. A literal "_x" that starts such a pattern is written
 * as "_x005F_x" (the escaped underscore), so Excel shows the original text.
 */
internal fun ooxmlLiteral(s: String): String = OOXML_ESCAPE.replace(s, "_x005F_")

/** What a spreadsheet application shows for stored cell text: every _xHHHH_ decoded once. */
internal fun ooxmlDecode(s: String): String = OOXML_CODE.replace(s) { it.groupValues[1].toInt(16).toChar().toString() }
