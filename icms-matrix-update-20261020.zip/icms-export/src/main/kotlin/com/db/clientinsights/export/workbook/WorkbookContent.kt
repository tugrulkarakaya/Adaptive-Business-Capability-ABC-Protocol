package com.db.clientinsights.export.workbook

import com.db.clientinsights.export.workbook.WorkbookLayout.S_FIGURE
import com.db.clientinsights.export.workbook.WorkbookLayout.S_INPUT
import com.db.clientinsights.export.workbook.WorkbookLayout.S_LABEL
import com.db.clientinsights.export.workbook.WorkbookLayout.S_SECTION
import com.db.clientinsights.export.workbook.WorkbookLayout.S_TEXT

/**
 * Builds the six review and evidence tabs and the row numbers and links the
 * writer and the verifier rely on. Facts only: no parent is chosen or ranked, MAIN_PARENT is never shown, unknown stays
 * blank or reads "unknown", every reviewer and team cell is blank, and the only formula is the Summary progress cell.
 */
internal object WorkbookContent {
    fun build(collection: CollectionData, review: ReviewData, runNotes: List<String>,
              decisionOptions: List<String>): WorkbookModel {
        val main = CompanyReviewSheet.build(review)
        val bookings = BookingsSheet.build(review)
        checkWorkbook(main.sheet.lastRow <= WorkbookLayout.MAX_SHEET_ROWS) {
            "${WorkbookLayout.MAIN_SHEET} needs ${main.sheet.lastRow} rows, over Excel's ${WorkbookLayout.MAX_SHEET_ROWS}"
        }
        checkWorkbook(bookings.sheet.lastRow <= WorkbookLayout.MAX_SHEET_ROWS) {
            "${WorkbookLayout.BOOKINGS_SHEET} needs ${bookings.sheet.lastRow} rows, over Excel's " +
                "${WorkbookLayout.MAX_SHEET_ROWS}"
        }
        checkWorkbook(main.jumps.size <= WorkbookLayout.MAX_HYPERLINKS) {
            "${WorkbookLayout.MAIN_SHEET} needs ${main.jumps.size} links, over Excel's ${WorkbookLayout.MAX_HYPERLINKS}"
        }
        JumpKeys.check(main.jumps)
        checkWorkbook(bookings.sheet.lastRow - 1L == collection.exportedBookingCount) {
            "${WorkbookLayout.BOOKINGS_SHEET} rows differ from the collection's exported booking count"
        }
        val summary = SummarySheet.build(collection, review, main.sheet.lastRow, decisionOptions)
        val rules = RulesSheet.build(collection, review, runNotes, decisionOptions)
        return WorkbookModel(summary.sheet, main.sheet, bookings.sheet, rules, main.companyRowOf,
            main.companyDetailRowOf, main.parentRowsOf, main.parentDetailRowsOf, main.reviewRows,
            bookings.bookingRowsOf, main.jumps, summary.progressRow, summary.chart, decisionOptions.toList(),
            ConfluenceEvidenceSheets.company(collection, review), ConfluenceEvidenceSheets.matrix(collection))
    }
}

/** Rows of a small tab (Summary, Rules), numbered 1.. in the order they are added: labels in A, values in B. */
internal class SheetRows {
    val list = mutableListOf<Row>()

    fun add(height: Double?, vararg cells: Cell): Int =
        (list.size + 1).also { list += Row(it, 0, false, height, cells.toList()) }

    fun blank() {
        add(null)
    }

    fun text(style: Int, text: String) {
        add(null, Cell.text(1, style, text))
    }

    fun section(title: String) {
        add(null, Cell.text(1, S_SECTION, title), Cell.blank(2, S_SECTION))
    }

    fun figure(label: String, value: Long) {
        add(null, Cell.text(1, S_LABEL, label), Cell.number(2, S_FIGURE, value))
    }

    fun pair(label: String, text: String) {
        add(null, Cell.text(1, S_LABEL, label), Cell.text(2, S_TEXT, text))
    }

    /** An open assumption: label, current behaviour, then blank Team decision and Team comment input cells. */
    fun decision(label: String, text: String) {
        add(null, Cell.text(1, S_LABEL, label), Cell.text(2, S_TEXT, text), Cell.blank(3, S_INPUT), Cell.blank(4, S_INPUT))
    }
}
