package com.db.clientinsights.export.workbook

import com.db.clientinsights.export.workbook.WorkbookLayout.BOOKINGS_SHEET
import com.db.clientinsights.export.workbook.WorkbookLayout.MAX_SHEET_ROWS
import com.db.clientinsights.export.workbook.WorkbookLayout.NS_MAIN
import com.db.clientinsights.export.workbook.WorkbookLayout.NS_PKG_REL
import com.db.clientinsights.export.workbook.WorkbookLayout.NS_REL
import com.db.clientinsights.export.workbook.WorkbookLayout.PARTS
import com.db.clientinsights.export.workbook.WorkbookLayout.SHEETS
import com.db.clientinsights.export.workbook.WorkbookLayout.STYLES_XML
import java.io.BufferedWriter
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.io.Writer
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Writes the review workbook as an .xlsx package. Every part is streamed straight into the ZIP in WorkbookLayout.PARTS
 * order; worksheets are written row by row, so the Bookings tab is never held in memory as one text. The bytes are
 * deterministic: fixed part order, ZIP entry time 0, no timestamps or random values.
 */
internal object XlsxWriter {
    const val XML_DECLARATION = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
    private const val REL_TYPE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/"
    /** Defined names: letters, digits, "_" and "."; starting with a letter or "_". Jump keys: [A-Z0-9-]. */
    private val SAFE_NAME = Regex("[A-Za-z_][A-Za-z0-9_.]*")
    private val SAFE_KEY = Regex("[A-Z0-9-]+")
    private const val CT_WORKSHEET = "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"

    /** Streams the whole .xlsx package to out. out is finished as a ZIP but not closed (the caller owns it). */
    fun write(model: WorkbookModel, out: OutputStream) {
        checkModel(model)
        val zip = ZipOutputStream(out, Charsets.UTF_8)
        for (part in PARTS) {
            val entry = ZipEntry(part)
            entry.time = 0L
            zip.putNextEntry(entry)
            val writer = BufferedWriter(OutputStreamWriter(zip, Charsets.UTF_8), 1 shl 16)
            writePart(part, model, writer)
            writer.flush() // never close: that would close the ZIP stream
            zip.closeEntry()
        }
        zip.finish()
        out.flush()
    }

    private fun writePart(part: String, model: WorkbookModel, out: Writer) {
        when (part) {
            "[Content_Types].xml" -> out.write(contentTypes())
            "_rels/.rels" -> out.write(relationships("officeDocument" to "xl/workbook.xml"))
            "xl/workbook.xml" -> out.write(workbook(model))
            "xl/_rels/workbook.xml.rels" -> out.write(relationships(
                *SHEETS.indices.map { "worksheet" to "worksheets/sheet${it + 1}.xml" }.toTypedArray(),
                "styles" to "styles.xml"))
            "xl/styles.xml" -> out.write(STYLES_XML)
            "xl/worksheets/sheet1.xml" -> WorksheetXml.write(out, model, model.summary)
            "xl/worksheets/_rels/sheet1.xml.rels" -> out.write(relationships("drawing" to "../drawings/drawing1.xml"))
            "xl/worksheets/sheet2.xml" -> WorksheetXml.write(out, model, model.main)
            "xl/worksheets/sheet3.xml" -> WorksheetXml.write(out, model, model.bookings)
            "xl/worksheets/sheet4.xml" -> WorksheetXml.write(out, model, model.rules)
            "xl/worksheets/sheet5.xml" -> WorksheetXml.write(out, model, model.companyEvidence)
            "xl/worksheets/sheet6.xml" -> WorksheetXml.write(out, model, model.matrix)
            "xl/drawings/drawing1.xml" -> ChartXml.writeDrawing(out, model.chart)
            "xl/drawings/_rels/drawing1.xml.rels" -> out.write(relationships("chart" to "../charts/chart1.xml"))
            "xl/charts/chart1.xml" -> ChartXml.writeChart(out, model.chart, ChartXml.seriesName(model.summary, model.chart))
            else -> error("no writer for package part $part")
        }
    }

    /** Model checks that would otherwise produce a file Excel repairs or rejects. Messages name sheets only. */
    private fun checkModel(model: WorkbookModel) {
        checkWorkbook(model.sheets.map { it.name } == SHEETS) { "workbook tabs are not ${SHEETS.joinToString()}" }
        for (sheet in model.sheets) checkWorkbook(sheet.lastRow in 1..MAX_SHEET_ROWS) {
            "${sheet.name} has ${sheet.lastRow} rows; a worksheet holds 1 to $MAX_SHEET_ROWS rows (not truncated)"
        }
        checkWorkbook(model.jumps.isEmpty() || model.bookings.lastRow >= 2) {
            "${model.main.name} has links but ${model.bookings.name} has no rows below its header"
        }
        for (jump in model.jumps) {
            checkWorkbook(SAFE_NAME.matches(jump.name)) { "${model.main.name} ${jump.cellRef} link name is not [A-Za-z0-9_.]" }
            checkWorkbook(SAFE_KEY.matches(jump.key)) { "${model.main.name} ${jump.cellRef} jump key is not [A-Z0-9-]" }
            checkWorkbook(jump.row in 2..model.main.lastRow) { "${model.main.name} ${jump.cellRef} is outside the tab" }
        }
        checkWorkbook(model.jumps.map { it.name.lowercase() }.toSet().size == model.jumps.size) {
            "link names are not unique (names ignore case)"
        }
        checkWorkbook(model.jumps.map { it.row }.toSet().size == model.jumps.size) {
            "${model.main.name} has two links on one cell"
        }
    }

    private fun contentTypes(): String = buildString {
        append(XML_DECLARATION)
        append("<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">")
        append("<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>")
        append("<Default Extension=\"xml\" ContentType=\"application/xml\"/>")
        override("/xl/workbook.xml", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml")
        override("/xl/styles.xml", "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml")
        for (i in SHEETS.indices) override("/xl/worksheets/sheet${i + 1}.xml", CT_WORKSHEET)
        override("/xl/drawings/drawing1.xml", "application/vnd.openxmlformats-officedocument.drawing+xml")
        override("/xl/charts/chart1.xml", "application/vnd.openxmlformats-officedocument.drawingml.chart+xml")
        append("</Types>")
    }

    private fun StringBuilder.override(part: String, type: String) {
        append("<Override PartName=\"").append(part).append("\" ContentType=\"").append(type).append("\"/>")
    }

    /** Package-internal relationships rId1, rId2, ... (type suffix to target); never a TargetMode. */
    private fun relationships(vararg rels: Pair<String, String>): String = buildString {
        append(XML_DECLARATION).append("<Relationships xmlns=\"").append(NS_PKG_REL).append("\">")
        rels.forEachIndexed { i, (type, target) ->
            append("<Relationship Id=\"rId").append(i + 1).append("\" Type=\"").append(REL_TYPE).append(type)
                .append("\" Target=\"").append(target).append("\"/>")
        }
        append("</Relationships>")
    }

    /**
     * Opens on Summary. Defined names: the Bookings AutoFilter database first, then one jump name per link, in model
     * order. Formulas are recalculated when the file is opened (the progress figure).
     */
    private fun workbook(model: WorkbookModel): String = buildString {
        val bookingsLast = model.bookings.lastRow
        append(XML_DECLARATION)
        append("<workbook xmlns=\"").append(NS_MAIN).append("\" xmlns:r=\"").append(NS_REL).append("\">")
        append("<bookViews><workbookView activeTab=\"0\"/></bookViews><sheets>")
        SHEETS.forEachIndexed { i, name ->
            append("<sheet name=\"").append(xmlEscape(name)).append("\" sheetId=\"").append(i + 1)
                .append("\" r:id=\"rId").append(i + 1).append("\"/>")
        }
        append("</sheets><definedNames>")
        append("<definedName name=\"_xlnm._FilterDatabase\" localSheetId=\"").append(SHEETS.indexOf(BOOKINGS_SHEET))
            .append("\" hidden=\"1\">").append(xmlEscape(WorkbookLayout.filterDatabaseFormula(bookingsLast)))
            .append("</definedName>")
        for (jump in model.jumps) {
            append("<definedName name=\"").append(xmlEscape(jump.name)).append("\">")
                .append(xmlEscape(WorkbookLayout.jumpFormula(jump, bookingsLast))).append("</definedName>")
        }
        append("</definedNames><calcPr calcId=\"191029\" fullCalcOnLoad=\"1\"/></workbook>")
    }
}
