package com.db.clientinsights.export.workbook

import com.db.clientinsights.export.domain.Producer
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject

/** The run options a receipt records. Run-note text is not recorded (only how many notes were given). */
internal data class ReceiptOptions(
    val expectedCount: Int?,
    val expectedIdCount: Int?,
    val decisionOptions: List<String>,
    val runNoteCount: Int,
)

/**
 * The workbook receipt: which program built the workbook from which exact export files (the primary manifest, i.e.
 * collection-manifest.json or a single run's run-manifest.json, and every file actually read), with which options,
 * what the re-read verification counted, and the workbook's size and SHA-256. Keys are written in a fixed order. It
 * holds IDs of files and runs, hashes and counts only, never client values.
 */
internal object WorkbookReceipt {
    const val FORMAT = "icms-review-workbook/5"
    private val json = Json { prettyPrint = true }

    fun json(producer: Producer, inputKind: String, collection: CollectionData, options: ReceiptOptions,
             verification: Map<String, Any?>, workbookName: String, workbookBytes: Long, workbookSha256: String): String {
        val receipt = buildJsonObject {
            put("workbookFormat", FORMAT)
            putJsonObject("producer") {
                put("applicationVersion", producer.applicationVersion)
                put("gitRevision", producer.gitRevision)
                put("workingTreeDirty", producer.workingTreeDirty)
            }
            put("inputKind", inputKind)
            put("runId", collection.runId)
            put("manifestFile", collection.manifestName)
            put("manifestSha256", collection.manifestSha256)
            put("evidenceSchema", collection.evidenceSchema)
            put("extractionStatus", collection.extractionStatus)
            put("bookingStatus", collection.bookingStatus)
            putJsonObject("exportProducer") {
                put("applicationVersion", collection.producerVersion)
                put("gitRevision", collection.producerRevision)
                put("workingTreeDirty", collection.producerDirty)
            }
            put("batches", collection.batches.size)
            put("consumedFiles", collection.consumedFileCount)
            putJsonObject("consumedFileSha256") { collection.consumedHashes().forEach { (file, hash) -> put(file, hash) } }
            putJsonObject("options") {
                put("expectedCount", options.expectedCount)
                put("expectedIdCount", options.expectedIdCount)
                putJsonArray("decisionOptions") { options.decisionOptions.forEach { add(JsonPrimitive(it)) } }
                put("runNoteCount", options.runNoteCount)
            }
            put("verification", element(verification))
            put("workbookFile", workbookName)
            put("workbookBytes", workbookBytes)
            put("workbookSha256", workbookSha256)
        }
        return json.encodeToString(JsonObject.serializer(), receipt) + "\n"
    }

    /** The verifier's counts as JSON, keeping its key order. */
    private fun element(value: Any?): JsonElement = when (value) {
        null -> JsonNull
        is String -> JsonPrimitive(value)
        is Number -> JsonPrimitive(value)
        is Boolean -> JsonPrimitive(value)
        is Map<*, *> -> JsonObject(value.entries.associate { (key, item) -> key.toString() to element(item) })
        is Iterable<*> -> JsonArray(value.map(::element))
        else -> error("Unsupported receipt value type ${value.javaClass.name}")
    }
}
