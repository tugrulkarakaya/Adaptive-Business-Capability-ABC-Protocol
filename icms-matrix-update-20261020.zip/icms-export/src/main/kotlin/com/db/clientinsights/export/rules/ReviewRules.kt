package com.db.clientinsights.export.rules

import com.db.clientinsights.export.domain.*
import java.math.BigInteger
import java.time.Clock

/** Pure, evidence-linked business rules. No SQL, AI, output limits or source updates. */
class ReviewRules(private val names: NameSignals = NameSignals(), private val clock: Clock = Clock.systemUTC()) {
    /**
     * Reviews each requested entity of one extraction batch in request order: the entity's rule results, its ranked
     * parent candidates and their pairwise clues, then one review per Active booking. Findings are numbered in that
     * order, so the same input always yields the same finding IDs.
     */
    fun evaluate(request: ExportRequest, core: CheckResults, facts: ReviewFacts): DeterministicReview {
        val index = ReviewIndex(core, facts)
        val candidateRules = ParentCandidateRules(names, index.parties)
        val relationshipRules = ParentRelationships(names)
        val bookingRules = BookingReviewRules(index, names)
        val findings = ReviewFindings()
        val entities = mutableListOf<EntityReview>()
        val parents = mutableListOf<ParentCandidate>()
        val relationships = mutableListOf<ParentRelationship>()
        val bookings = mutableListOf<BookingReview>()
        for (entity in core.entities) {
            val evidence = EntityEvidence(entity, index)
            val status = EntityReviewRules.currentRuleStatus(evidence)
            entities += EntityReviewRules.entityReview(evidence, status)
            findings.addAll(entity.entityId, EntityReviewRules.findings(evidence, status))
            val candidates = candidateRules.rank(evidence)
            parents += candidates
            relationships += relationshipRules.evaluate(entity.entityId, candidates, index.parties)
            for (booking in evidence.activeBookings) {
                val reviewed = bookingRules.review(evidence, booking)
                bookings += reviewed.review
                findings.addAll(entity.entityId, reviewed.findings)
            }
        }
        val usage = UsageEvidenceRules(clock).evaluate(request, core, facts.usageEvidence)
        return DeterministicReview(ruleVersion = "1.1.0", facts = facts, entities = entities, bookings = bookings, parents = parents,
            relationships = relationships, findings = findings.toList(),
            identitySelections = BankIdentityRules(clock).evaluate(facts),
            platformNames = PlatformNameRules().evaluate(core, facts), usage = usage,
            themeB6 = ThemeB6Rules().evaluate(core, facts, bookings, usage))
    }

    companion object {
        /** Stands for a baseline path whose report parent is missing. */
        const val NULL_PARENT = "(NULL)"

        /** A path's parent: its primary-hierarchy ultimate parent, else its report parent, else [NULL_PARENT]. */
        fun parentId(path: ParentPath): String = path.hierarchyParentId ?: path.reportParentId ?: NULL_PARENT

        /** Numeric order when both IDs are numeric, text order otherwise. */
        fun compareIds(a: String, b: String): Int =
            if (a.matches(Regex("[0-9]+")) && b.matches(Regex("[0-9]+"))) BigInteger(a).compareTo(BigInteger(b))
            else a.compareTo(b)
    }
}
