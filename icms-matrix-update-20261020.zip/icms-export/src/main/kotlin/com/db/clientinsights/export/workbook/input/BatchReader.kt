package com.db.clientinsights.export.workbook.input

import com.db.clientinsights.export.adapters.serialization.sha256
import com.db.clientinsights.export.workbook.BatchData
import com.db.clientinsights.export.workbook.CollectionData
import com.db.clientinsights.export.workbook.CsvTable
import com.db.clientinsights.export.workbook.checkWorkbook
import java.nio.file.Files
import java.nio.file.Path

/** One batch's run-manifest.json: its own SHA-256 and parsed fields (evidence schema 1.3.0 checked). */
internal class RunManifest(val sha256: String, val json: ManifestJson) {
    companion object {
        const val FILE = "run-manifest.json"
        const val SCHEMA = "1.4.0"
        private val READABLE_SCHEMAS = setOf("1.3.0", SCHEMA)

        /** Reads run-manifest.json directly inside the real batch folder. */
        fun read(realFolder: Path, number: Int): RunManifest {
            val label = "batch $number $FILE"
            val bytes = Files.readAllBytes(PathGuards.plainFileIn(realFolder, FILE, label))
            val json = ManifestJson.parse(bytes, label)
            val schema = json.text("schemaVersion")
            checkWorkbook(schema in READABLE_SCHEMAS) { "batch $number evidence schema $schema is not supported" }
            return RunManifest(sha256(bytes), json)
        }
    }
}

/**
 * Reads the consumed CSVs of one batch folder. Each file must sit directly in the folder, be listed once in the
 * run manifest with a non-negative dataRows count, and match its listed size and SHA-256 before it is parsed and its
 * dataRows after. Other files are ignored.
 */
internal object BatchReader {

    fun read(
        realFolder: Path,
        number: Int,
        folder: String,
        manifest: RunManifest,
        extractionStatus: String?,
    ): BatchData {
        val label = "batch $number"
        val json = manifest.json
        val requestedIds = json.objectOrNull("request")?.textsOrNull("entityIds")
        checkWorkbook(requestedIds != null) { "$label ${RunManifest.FILE} has no request entityIds" }

        val artifacts = HashMap<String, ManifestJson>()
        for (artifact in json.objects("artifacts")) {
            val name = artifact.requiredText("filename")
            checkWorkbook(artifacts.put(name, artifact) == null) { "$label lists $name twice" }
        }
        val tables = LinkedHashMap<String, CsvTable>()
        val hashes = LinkedHashMap<String, String>()
        for (file in CollectionData.CONSUMED_FILES + CollectionData.OPTIONAL_FILES.filter { it in artifacts }) {
            val artifact = artifacts[file]
            checkWorkbook(artifact != null) { "$label manifest has no $file" }
            val dataRows = artifact!!.text("dataRows")?.toLongOrNull()
            checkWorkbook(dataRows != null && dataRows >= 0) {
                "$label $file has no non-negative whole-number dataRows in its manifest"
            }
            val bytes = Files.readAllBytes(PathGuards.plainFileIn(realFolder, file, "$label $file"))
            checkWorkbook(artifact.text("bytes")?.toLongOrNull() == bytes.size.toLong()) {
                "$label $file size differs from its manifest"
            }
            val hash = sha256(bytes)
            checkWorkbook(hash == artifact.text("sha256")) { "$label $file SHA-256 differs from its manifest" }
            val table = CsvTableReader.parse(label, file, bytes)
            checkWorkbook(dataRows == table.rows.size.toLong()) {
                "$label $file row count differs from its manifest"
            }
            RequiredColumns.check(label, table)
            tables[file] = table
            hashes[file] = hash
        }
        return BatchData(number, folder, manifest.sha256, json.text("runId"), extractionStatus, requestedIds!!,
            tables, hashes)
    }
}

/** A consumed table of this batch (always present after BatchReader.read). */
internal fun BatchData.table(file: String): CsvTable = tables[file] ?: error("batch table $file was not read")
