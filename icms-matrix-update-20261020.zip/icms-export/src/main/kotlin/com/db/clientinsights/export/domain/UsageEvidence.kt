package com.db.clientinsights.export.domain

import kotlinx.serialization.Serializable

/** Optional, verified sources. An empty list without a completed query is unknown, never zero. */
@Serializable
data class UsageEvidenceFacts(
    val contacts: List<SourceRow<ContactPersonFact>> = emptyList(),
    val confirmations: List<SourceRow<ConfirmationRoutingFact>> = emptyList(),
    val trading: List<SourceRow<BookingTradingFact>> = emptyList(),
    val queries: List<QueryRun> = emptyList(),
)

/** One person/platform row; people are counted by distinct contactId, not platform rows. */
@Serializable
data class ContactPersonFact(val rowId: String, val entityId: IcmsEntityId, val contactId: String,
    val status: String?, val platformName: String?, val nameOnPlatform: String?)

/** Must represent a verified booking -> settlement account -> confirmation route link. */
@Serializable
data class ConfirmationRoutingFact(val rowId: String, val entityId: IcmsEntityId,
    val bookingRecordId: String, val platformName: String?, val verifiedAccountLink: Boolean = false)

/** A source-owned trade count for one verified booking, with explicit inclusive/exclusive coverage dates. */
@Serializable
data class BookingTradingFact(val rowId: String, val entityId: IcmsEntityId,
    val bookingRecordId: String, val windowStartInclusive: String, val windowEndExclusive: String,
    val tradeCount: Long, val lastTradeDate: String?,
    val coverageComplete: Boolean = false, val verifiedBookingLink: Boolean = false)

@Serializable
data class ContactPlatformName(val name: String, val platforms: List<String>)

@Serializable
data class ContactReview(val entityId: IcmsEntityId, val activeContactCount: Int?,
    val names: List<ContactPlatformName>, val status: String, val limitations: List<String>,
    val evidenceIds: List<String>, val queryRunIds: List<String>)

@Serializable
data class BookingUsageReview(val entityId: IcmsEntityId, val bookingRecordId: String,
    val confirmationRoutings: Boolean?, val confirmationPlatforms: List<String>,
    val recentTrading: Boolean?, val lastTradeDate: String?,
    val windowStartInclusive: String, val windowEndExclusive: String,
    val limitations: List<String>, val evidenceIds: List<String>, val queryRunIds: List<String>)

@Serializable
data class UsageReview(val contacts: List<ContactReview> = emptyList(),
    val bookings: List<BookingUsageReview> = emptyList(),
    val entityTrading: List<EntityTradingSummary> = emptyList())

/** Counts confirmed observations separately from unknown records; a partial cohort has no percentage. */
@Serializable
data class EntityTradingSummary(val entityId: IcmsEntityId, val observedActiveBookingRecords: Int,
    val bookingCoverageComplete: Boolean, val confirmedTradingRecords: Int, val confirmedNoTradingRecords: Int,
    val unknownRecords: Int, val confirmedTradingPercent: Double?)
