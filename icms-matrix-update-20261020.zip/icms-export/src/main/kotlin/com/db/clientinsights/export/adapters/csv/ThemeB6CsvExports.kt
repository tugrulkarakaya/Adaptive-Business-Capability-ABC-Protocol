package com.db.clientinsights.export.adapters.csv

import com.db.clientinsights.export.domain.*
import java.nio.file.Path

/** WIP category evidence for human review; conditional levels are never an overall decision. */
class ThemeB6CsvExports(private val csv: CsvExports) {
    fun write(review: DeterministicReview, directory: Path): Map<String, Int> {
        val facts = review.themeB6
        val counts = linkedMapOf<String, Int>()
        fun table(name: String, headers: List<String>, rows: List<List<Any?>>) {
            counts[name] = csv.writeTable(directory.resolve(name), headers, rows)
        }
        table("theme-b6-status-paths.csv", listOf(
            "path_row_id", "crds_system_id", "booking_code", "rhp_id", "ultimate_parent_id", "crds_booking_status",
            "crds_booking_status_date", "path_statuses", "path_count", "evidence_id", "query_run_id", "evidence_scope"
        ), review.facts.allStatusPaths.map { row ->
            val path = row.data
            listOf(path.rowId, path.systemId, path.bookingCode, path.rhpId, path.ultimateParentId,
                path.bookingStatus, path.bookingStatusDate,
                path.statuses.toSortedMap().entries.joinToString("|") { (key, value) -> "$key=${value.orEmpty()}" },
                path.pathCount, row.origin.evidenceId, row.origin.queryRunId,
                "ALL_STATUS_PATHS_INCLUDING_HISTORICAL_NOT_CURRENT_SELECTION")
        })
        table("theme-b6-booking-assessments.csv", listOf(
            "entity_id", "booking_record_id", "crds_system_id", "booking_code", "settlement_method_id",
            "path_evidence_id", "matches_current_party_pair", "rhp_id", "rhp_industry_status", "rhp_status_date",
            "ultimate_parent_id", "parent_industry_status", "parent_status_date", "crds_booking_status",
            "crds_booking_status_date", "source_status", "category", "result", "confidence",
            "if_no_recent_trading", "if_recent_trading", "matrix_rows", "missing_inputs", "explanation",
            "evidence_ids", "query_run_ids", "policy_status", "source_url"
        ), facts.bookings.flatMap { booking ->
            booking.assessments.map { assessment ->
                listOf(booking.entityId.value, booking.bookingRecordId, booking.systemId, booking.bookingCode,
                    booking.settlementMethodId, booking.pathEvidenceId, booking.matchesCurrentPartyPair,
                    booking.rhpId, booking.rhpIndustryStatus, booking.rhpIndustryStatusDate,
                    booking.ultimateParentId, booking.parentIndustryStatus, booking.parentIndustryStatusDate,
                    booking.crdsBookingStatus, booking.crdsBookingStatusDate, booking.sourceStatus,
                    assessment.category, assessment.result, assessment.confidence, assessment.ifNoRecentTrading,
                    assessment.ifRecentTrading, assessment.matrixRows.joinToString("|"),
                    assessment.missingInputs.joinToString("|"), assessment.explanation,
                    booking.evidenceIds.joinToString("|"), booking.queryRunIds.joinToString("|"),
                    facts.sourceStatus, facts.sourceUrl)
            }
        })
        table("theme-b6-rhp-summary.csv", listOf(
            "entity_id", "rhp_id", "industry_statuses", "status_dates", "has_non_active_status",
            "has_unknown_status", "booking_record_count", "evidence_ids", "query_run_ids", "policy_status"
        ), facts.rhpSummaries.map {
            listOf(it.entityId.value, it.partyId, it.statuses.joinToString("|"), it.statusDates.joinToString("|"),
                it.hasNonActiveStatus, it.hasUnknownStatus, it.bookingRecordCount,
                it.evidenceIds.joinToString("|"), it.queryRunIds.joinToString("|"), facts.sourceStatus)
        })
        table("theme-b6-parent-status-summary.csv", listOf(
            "entity_id", "parent_id", "booking_record_count", "distinct_booking_code_count",
            "current_selected_record_count", "booking_status_counts", "observed_statuses", "source_status",
            "count_scope", "evidence_ids", "query_run_ids", "policy_status"
        ), facts.parentSummaries.map {
            listOf(it.entityId.value, it.parentId, it.bookingRecordCount, it.distinctBookingCodeCount,
                it.currentSelectedRecordCount, it.statusCounts.toSortedMap().entries.joinToString("|") { (status, count) -> "$status=$count" },
                it.observedStatuses.joinToString("|"), it.sourceStatus, it.evidenceScope,
                it.evidenceIds.joinToString("|"), it.queryRunIds.joinToString("|"), facts.sourceStatus)
        })
        table("theme-b6-source-availability.csv", listOf("entity_id", "requirement", "status", "source_read_status", "limitation", "source_url"),
            availability(review))
        return counts
    }

    private fun availability(review: DeterministicReview): List<List<Any?>> {
        val sourceUrl = review.themeB6.sourceUrl
        val entities = (review.entities.map { it.entityId } + review.usage.contacts.map { it.entityId } +
            review.usage.bookings.map { it.entityId }).distinct()
        val contacts = review.usage.contacts.associateBy { it.entityId }
        val bookings = review.usage.bookings.groupBy { it.entityId }
        val queries = review.facts.usageEvidence.queries
        val scopedEntities: List<IcmsEntityId?> = if (entities.isEmpty()) listOf(null) else entities
        val rows = scopedEntities.flatMap { entity ->
            fun readStatus(dataset: String): FetchStatus {
                val runs = queries.filter { it.dataset == dataset && entity?.value in it.requestedKeys }
                return if (runs.isEmpty()) FetchStatus.NOT_CONFIGURED else combineFetchStatuses(runs.map {
                    if (it.truncated && it.status == FetchStatus.COMPLETE) FetchStatus.PARTIAL else it.status
                })
            }
            fun result(dataset: String, valid: Boolean): String {
                val read = readStatus(dataset)
                return if (read == FetchStatus.COMPLETE) {
                    if (valid) "COMPLETE" else "NOT_DETERMINED"
                } else read.name
            }
            val contact = contacts[entity]
            val usage = bookings[entity].orEmpty()
            val contactValid = contact?.activeContactCount != null && contact.status == "COMPLETE"
            val contactComplete = contactValid && readStatus("ACTIVE_CONTACT_PEOPLE") == FetchStatus.COMPLETE
            val contactNamesValid = contactValid &&
                "ACTIVE_CONTACT_CUSTOMER_PLATFORM_NAMES_NOT_VALIDATED_OR_INCOMPLETE" !in contact?.limitations.orEmpty()
            val contactNamesComplete = contactNamesValid && contactComplete
            val confirmationValid = entity != null && usage.all { it.confirmationRoutings != null }
            val tradingValid = entity != null && usage.all { it.recentTrading != null }
            listOf(
                listOf(entity?.value, "ACTIVE_CONTACT_PEOPLE", result("ACTIVE_CONTACT_PEOPLE", contactValid), readStatus("ACTIVE_CONTACT_PEOPLE"),
                    if (contactComplete) "Distinct active people from the configured verified source; source completeness is scoped to this entity."
                    else "No complete validated active-contact-person result. Booking/account platform rows do not establish active people.", sourceUrl),
                listOf(entity?.value, "ACTIVE_CONTACT_CUSTOMER_PLATFORM_NAMES", result("ACTIVE_CONTACT_PEOPLE", contactNamesValid), readStatus("ACTIVE_CONTACT_PEOPLE"),
                    if (contactNamesComplete) "Active-person CUSTOMER names only; suffix removed, platform families grouped. Blank names are omitted."
                    else "The contact count may be complete while its CUSTOMER/platform-name bridge remains unvalidated or incomplete; separate booking/account names are not substituted.", sourceUrl),
                listOf(entity?.value, "CONFIRMATION_ROUTING_PLATFORMS", result("CONFIRMATION_ROUTINGS", confirmationValid), readStatus("CONFIRMATION_ROUTINGS"),
                    if (readStatus("CONFIRMATION_ROUTINGS") == FetchStatus.COMPLETE && confirmationValid)
                        "Verified booking-to-account confirmation-route results; inspect booking-usage-evidence.csv for each booking."
                    else "No complete validated confirmation-route result for every reviewed booking. Account platform names do not prove a confirmation route.", sourceUrl),
                listOf(entity?.value, "RECENT_TRADING_24_MONTHS", result("BOOKING_TRADING_24_MONTHS", tradingValid), readStatus("BOOKING_TRADING_24_MONTHS"),
                    if (readStatus("BOOKING_TRADING_24_MONTHS") == FetchStatus.COMPLETE && tradingValid)
                        "Verified dated trading coverage for each reviewed booking; inspect the explicit window and last-trade dates in booking-usage-evidence.csv."
                    else "No complete validated dated 24-month trading result for every reviewed booking. Accessibility probes do not establish trading or no trading.", sourceUrl)
            )
        }
        return rows + listOf(
            listOf(null, "SETTLEMENT_METHOD_SPECIFIC_ROUTING_COUNT", "NOT_VALIDATED", null,
                "Existing routing summaries use entity, booking code and ICMS system; exact settlement-method attribution is not validated.", sourceUrl),
            listOf(null, "AI_BUSINESS_ASSOCIATIONS", "OUTSIDE_NON_AI_SCOPE", null,
                "No model calls or generated associations. Structured source evidence remains available for future AI integration.", sourceUrl),
            listOf(null, "COMBINED_UNUSED_CONFIDENCE", "BUSINESS_DECISION_REQUIRED", null,
                "The WIP page specifies separate categories without precedence; Theme A versus Theme B placement is TBC. No combined score is invented.", sourceUrl)
        )
    }
}
