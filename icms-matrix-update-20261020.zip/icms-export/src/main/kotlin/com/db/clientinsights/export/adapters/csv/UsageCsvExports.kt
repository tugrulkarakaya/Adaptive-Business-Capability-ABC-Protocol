package com.db.clientinsights.export.adapters.csv

import com.db.clientinsights.export.domain.DeterministicReview
import java.nio.file.Path

/** Optional source evidence stays distinct from existing booking/account platform observations. */
class UsageCsvExports(private val csv: CsvExports) {
    fun write(review: DeterministicReview, directory: Path): Map<String, Int> {
        val counts = linkedMapOf<String, Int>()
        fun table(name: String, headers: List<String>, rows: List<List<Any?>>) {
            counts[name] = csv.writeTable(directory.resolve(name), headers, rows)
        }
        table("active-contact-review.csv", listOf("entity_id", "active_contact_count", "status", "customer_platform_names",
            "limitations", "evidence_ids", "query_run_ids"), review.usage.contacts.map {
            listOf(it.entityId.value, it.activeContactCount, it.status,
                it.names.joinToString(" | ") { name -> "${name.platforms.joinToString(", ")}: ${name.name}" },
                it.limitations.joinToString("|"), it.evidenceIds.joinToString("|"), it.queryRunIds.joinToString("|"))
        })
        table("booking-usage-evidence.csv", listOf("entity_id", "booking_record_id", "confirmation_routings",
            "confirmation_platforms", "recent_trading", "last_trade_date", "window_start_inclusive", "window_end_exclusive",
            "limitations", "evidence_ids", "query_run_ids"), review.usage.bookings.map {
            listOf(it.entityId.value, it.bookingRecordId, it.confirmationRoutings, it.confirmationPlatforms.joinToString("|"),
                it.recentTrading, it.lastTradeDate, it.windowStartInclusive, it.windowEndExclusive,
                it.limitations.joinToString("|"), it.evidenceIds.joinToString("|"), it.queryRunIds.joinToString("|"))
        })
        val facts = review.facts.usageEvidence
        table("contact-person-evidence.csv", listOf("entity_id", "contact_id", "source_status", "platform_name", "name_on_platform",
            "evidence_id", "query_run_id"), facts.contacts.map {
            listOf(it.data.entityId.value, it.data.contactId, it.data.status, it.data.platformName, it.data.nameOnPlatform,
                it.origin.evidenceId, it.origin.queryRunId)
        })
        table("confirmation-routing-evidence.csv", listOf("entity_id", "booking_record_id", "platform_name", "verified_account_link",
            "evidence_id", "query_run_id"), facts.confirmations.map {
            listOf(it.data.entityId.value, it.data.bookingRecordId, it.data.platformName, it.data.verifiedAccountLink,
                it.origin.evidenceId, it.origin.queryRunId)
        })
        table("trading-coverage-evidence.csv", listOf("entity_id", "booking_record_id", "window_start_inclusive", "window_end_exclusive",
            "trade_count", "last_trade_date", "coverage_complete", "verified_booking_link", "evidence_id", "query_run_id"), facts.trading.map {
            listOf(it.data.entityId.value, it.data.bookingRecordId, it.data.windowStartInclusive, it.data.windowEndExclusive,
                it.data.tradeCount, it.data.lastTradeDate, it.data.coverageComplete, it.data.verifiedBookingLink,
                it.origin.evidenceId, it.origin.queryRunId)
        })
        return counts
    }
}
