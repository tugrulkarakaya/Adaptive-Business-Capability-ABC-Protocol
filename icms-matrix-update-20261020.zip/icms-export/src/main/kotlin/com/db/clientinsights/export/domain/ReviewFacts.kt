package com.db.clientinsights.export.domain

import kotlinx.serialization.Serializable

@Serializable
data class ParentPath(val rowId: String, val systemId: String?, val bookingCode: String?,
    val hierarchyParentId: String?, val reportParentId: String?, val pathCount: Long,
    val activeLinkPaths: Long, val reportRankPaths: Long, val tieAtReportRank: Boolean,
    val linkStatuses: List<String>)

@Serializable
data class CurrentBookingPath(val recordId: String, val entityId: IcmsEntityId, val hasCrdsPath: Boolean,
    val rhpId: String?, val ultimateParentId: String?, val currentParentsOnKey: Long,
    val statuses: Map<String, String?>)

@Serializable
data class PartyFact(val rowId: String, val partyId: String, val standardName: String?, val legalName: String?,
    val survivingEntityId: String?, val industryStatus: String?, val industryStatusDate: String?,
    val ultimateParentId: String?, val immediateParentId: String?)

@Serializable
data class SalesforceFact(val rowId: String, val partyId: String, val name: String?,
    val legalUltimateParentId: String?, val legalImmediateParentId: String?, val reportingGroupId: String?,
    val reportingLevel: Boolean, val pathIds: List<String?>) {
    fun resolvedReportingGroupId(): String? = if (reportingLevel) partyId else reportingGroupId
}

@Serializable
data class RoutingFact(val rowId: String, val entityId: IcmsEntityId, val bookingCode: String?,
    val settlementSystemId: String?, val count: Long, val blockCount: Long, val lastChangeDate: String?)

@Serializable
data class SharedBookingKey(val rowId: String, val entityId: IcmsEntityId, val bookingCode: String?,
    val settlementSystemId: String?, val otherEntityId: IcmsEntityId, val otherEntityName: String?)

@Serializable
data class BankIdentityFact(val rowId: String, val partyId: String, val kind: String, val fields: Map<String, String?>)

@Serializable
data class AssignmentLineage(val recordId: String, val entityId: IcmsEntityId,
    val activatedDbLeId: String?, val overrideSource: String?, val bookingCode: String? = null,
    val settlementSystemId: String? = null, val assignedCrdsPartyId: String? = null, val status: String? = null)

@Serializable
data class RoutingLineage(val rowId: String, val entityId: IcmsEntityId, val bookingCode: String?,
    val settlementSystemId: String?, val routeCount: Long, val activeRouteCount: Long,
    val matchingAssignmentIdCount: Long, val accountCount: Long, val requestedEntityAccountCount: Long,
    val missingAccountCount: Long, val otherEntityRouteCount: Long)

@Serializable
data class ActivityAvailability(val source: String, val accessibility: String,
    val recentTrading: Boolean? = null,
    val limitation: String = "No validated dated trade-to-booking/system/entity join or confirmed 24-month coverage.")

@Serializable
data class ReviewFacts(
    val paths: List<SourceRow<ParentPath>> = emptyList(),
    val currentBookings: List<SourceRow<CurrentBookingPath>> = emptyList(),
    val parties: List<SourceRow<PartyFact>> = emptyList(),
    val salesforce: List<SourceRow<SalesforceFact>> = emptyList(),
    val routings: List<SourceRow<RoutingFact>> = emptyList(),
    val sharedKeys: List<SourceRow<SharedBookingKey>> = emptyList(),
    val identities: List<SourceRow<BankIdentityFact>> = emptyList(),
    val assignments: List<SourceRow<AssignmentLineage>> = emptyList(),
    val routingLineage: List<SourceRow<RoutingLineage>> = emptyList(),
    val activityAvailability: List<ActivityAvailability> = emptyList(),
    val queries: List<QueryRun> = emptyList(),
    val platformNames: List<SourceRow<BookingPlatformFact>> = emptyList(),
    val platformNativeBookings: List<SourceRow<PlatformNativeBooking>> = emptyList(),
    val allStatusPaths: List<SourceRow<AllStatusBookingPath>> = emptyList(),
    val usageEvidence: UsageEvidenceFacts = UsageEvidenceFacts(),
)
