package com.db.clientinsights.export.workbook

import com.db.clientinsights.export.adapters.serialization.sha256
import com.db.clientinsights.export.workbook.input.BatchReader
import com.db.clientinsights.export.workbook.input.ManifestJson
import com.db.clientinsights.export.workbook.input.PathGuards
import com.db.clientinsights.export.workbook.input.RunManifest
import java.math.BigInteger
import java.nio.file.Files
import java.nio.file.Path

/**
 * Reads one export for the review workbook and checks its integrity before anything is joined: manifest schemas,
 * real-path containment of every manifest, batch folder and CSV, and each consumed CSV's size, SHA-256 and row count
 * against its run manifest. Files the workbook does not consume (also at the collection root) are ignored.
 */
internal object WorkbookInput {
    const val COLLECTION_MANIFEST = "collection-manifest.json"
    const val COLLECTION_SCHEMA = "1.1.0"
    /** BatchData.folder of the one batch of a single-run input: the input folder itself. */
    const val SINGLE_RUN_FOLDER = "."
    private const val EXPLICIT_SELECTION = "EXPLICIT_ENTITY_IDS"

    /**
     * Reads a collection folder or its collection-manifest.json, or a single-run batch folder (no collection
     * manifest) or its run-manifest.json. Only these two manifest names are accepted: a staged or other manifest file
     * fails the check, so an unpublished collection is never read by accident. A manifest that is a symlink must
     * resolve to a file of the same name in the same folder. A missing path is a usage error.
     */
    fun read(input: Path): CollectionData {
        require(Files.exists(input)) { "--input does not exist" }
        val real = input.toRealPath()
        if (Files.isRegularFile(real)) return readManifestFile(input)
        require(Files.isDirectory(real)) { "--input must be a folder, $COLLECTION_MANIFEST or ${RunManifest.FILE}" }
        return when {
            Files.exists(real.resolve(COLLECTION_MANIFEST)) -> readManifestFile(real.resolve(COLLECTION_MANIFEST))
            Files.exists(real.resolve(RunManifest.FILE)) -> readManifestFile(real.resolve(RunManifest.FILE))
            else -> throw WorkbookCheckFailure(
                "--input has neither $COLLECTION_MANIFEST nor ${RunManifest.FILE} " +
                    "(an unpublished collection is not read)")
        }
    }

    /**
     * Reads the export named by one manifest path. The supplied name must be collection-manifest.json or
     * run-manifest.json, and its real path (symlinks resolved) must have the same name and sit in the same real
     * folder as the supplied path; that folder is the one read.
     */
    private fun readManifestFile(manifest: Path): CollectionData {
        val supplied = manifest.fileName?.toString()
        checkWorkbook(supplied == COLLECTION_MANIFEST || supplied == RunManifest.FILE) {
            "--input file is not $COLLECTION_MANIFEST or ${RunManifest.FILE} " +
                "(unpublished or other manifests are not read)"
        }
        val real = manifest.toRealPath()
        checkWorkbook(real.fileName.toString() == supplied) { "--input $supplied is a link to a file with another name" }
        val folder = manifest.toAbsolutePath().parent.toRealPath()
        checkWorkbook(real.parent == folder) { "--input $supplied resolves to a file outside its folder" }
        return if (supplied == COLLECTION_MANIFEST) readCollection(folder, real) else readSingleRun(folder)
    }

    /**
     * Reads a collection whose manifest is `manifest`, any regular file directly inside `dir` (the export also uses
     * this with a staged manifest before publishing collection-manifest.json). The manifest is read and SHA-256
     * hashed exactly like collection-manifest.json; every other check is the same.
     */
    fun readCollection(dir: Path, manifest: Path): CollectionData {
        val root = dir.toRealPath()
        val manifestFile = PathGuards.fileDirectlyIn(root, manifest, COLLECTION_MANIFEST)
        val bytes = Files.readAllBytes(manifestFile)
        val m = ManifestJson.parse(bytes, COLLECTION_MANIFEST)
        val schema = m.text("schemaVersion")
        checkWorkbook(schema == COLLECTION_SCHEMA) { "collection schema $schema is not $COLLECTION_SCHEMA" }
        val cohort = m.textsOrNull("requestedEntityIds")
            ?: m.objects("discoveryPages").flatMap { it.textsOrNull("entityIds").orEmpty() }
        checkCohort(cohort)
        val bookingCount = declaredBookingCount(m, COLLECTION_MANIFEST)

        val evidenceSchemas = linkedSetOf<String>()
        val batches = m.objects("batches").mapIndexed { i, entry ->
            val number = i + 1
            val folder = entry.text("folder")
            val batchDir = PathGuards.batchFolder(root, number, folder)
            val runManifest = RunManifest.read(batchDir, number)
            evidenceSchemas += runManifest.json.requiredText("schemaVersion")
            checkWorkbook(runManifest.sha256 == entry.text("manifestSha256")) {
                "batch $number ${RunManifest.FILE} SHA-256 differs from the collection manifest"
            }
            val status = entry.text("extractionStatus")
            batchDir to BatchReader.read(batchDir, number, folder.orEmpty(), runManifest, status)
        }
        checkWorkbook(batches.isNotEmpty()) { NO_COMPANIES }
        checkWorkbook(batches.map { it.first }.toSet().size == batches.size) { "collection lists a batch folder twice" }

        val producer = m.objectOrNull("producer")
        return CollectionData(
            dir = root,
            inputKind = CollectionData.KIND_COLLECTION,
            manifestName = COLLECTION_MANIFEST,
            manifestSha256 = sha256(bytes),
            runId = m.text("runId"),
            startedAt = m.text("startedAt"),
            finishedAt = m.text("finishedAt"),
            extractionStatus = m.text("extractionStatus"),
            discoveryStatus = m.text("discoveryStatus"),
            selection = m.text("selection"),
            crossSourceAtomicSnapshot = m.text("crossSourceAtomicSnapshot") == "true",
            exportedBookingCount = bookingCount,
            bookingStatus = m.text("bookingStatus"),
            producerVersion = producer?.text("applicationVersion"),
            producerRevision = producer?.text("gitRevision"),
            producerDirty = producer?.text("workingTreeDirty"),
            evidenceSchema = evidenceSchemas.joinToString(", "),
            cohort = cohort,
            batches = batches.map { it.second },
        )
    }

    /**
     * A single-run batch folder: one batch, cohort = the run's requested entity IDs, collection fields taken from
     * the run manifest, whose own SHA-256 stands in for the collection manifest's.
     */
    private fun readSingleRun(dir: Path): CollectionData {
        val root = dir.toRealPath()
        val manifest = RunManifest.read(root, 1)
        val m = manifest.json
        val bookingCount = declaredBookingCount(m, RunManifest.FILE)
        val batch = BatchReader.read(root, 1, SINGLE_RUN_FOLDER, manifest, m.text("extractionStatus"))
        checkCohort(batch.requestedIds)
        val producer = m.objectOrNull("producer")
        return CollectionData(
            dir = root,
            inputKind = CollectionData.KIND_SINGLE_RUN,
            manifestName = RunManifest.FILE,
            manifestSha256 = manifest.sha256,
            runId = m.text("runId"),
            startedAt = m.text("startedAt"),
            finishedAt = m.text("finishedAt"),
            extractionStatus = m.text("extractionStatus"),
            discoveryStatus = null,
            selection = EXPLICIT_SELECTION,
            crossSourceAtomicSnapshot = false,
            exportedBookingCount = bookingCount,
            bookingStatus = m.objectOrNull("request")?.text("bookingStatus"),
            producerVersion = producer?.text("applicationVersion"),
            producerRevision = producer?.text("gitRevision"),
            producerDirty = producer?.text("workingTreeDirty"),
            evidenceSchema = m.requiredText("schemaVersion"),
            cohort = batch.requestedIds,
            batches = listOf(batch),
        )
    }

    /** "collection" or "single-run", as recorded when the input was read. */
    fun inputKind(collection: CollectionData): String = collection.inputKind

    /**
     * Reads an --expected-ids file: IDs separated by whitespace or commas, '#' starts a comment, BOMs ignored. The
     * export's own --ids-file is accepted as is: an optional entity_id header is skipped, surrounding quotes are
     * removed, and digit-only IDs lose leading zeros as the export's IDs do (007 -> 7). Returns them in file order
     * (duplicates kept, so the caller can compare counts).
     */
    fun readIdList(path: Path): List<String> {
        val ids = ArrayList<String>()
        for (line in Files.readAllLines(path, Charsets.UTF_8)) {
            val content = line.replace("\uFEFF", "").substringBefore('#')
            content.split(ID_SEPARATORS).map { it.trim().removeSurrounding("\"") }.filter { it.isNotBlank() }
                .forEach { ids += if (DIGITS.matches(it)) BigInteger(it).toString() else it }
        }
        if (ids.firstOrNull() == ID_HEADER) ids.removeAt(0)
        return ids
    }

    /** Failure message for an empty cohort or a collection without batches; the caller decides whether to skip. */
    const val NO_COMPANIES = "the export contains no companies"

    /** The most booking rows the Bookings tab can hold below its header row. */
    const val MAX_BOOKINGS: Long = WorkbookLayout.MAX_SHEET_ROWS - 1L

    /**
     * The manifest's declared exportedBookingCount, checked against the Bookings tab capacity before any CSV is
     * opened. The rows actually read are reconciled with it later (ReviewJoin).
     */
    private fun declaredBookingCount(m: ManifestJson, file: String): Long {
        val count = m.requiredLong("exportedBookingCount")
        checkWorkbook(count in 0..MAX_BOOKINGS) {
            "$file exportedBookingCount is negative or over the Bookings tab capacity of $MAX_BOOKINGS rows"
        }
        return count
    }

    private val ID_SEPARATORS = Regex("[\\s,]+")
    private val DIGITS = Regex("[0-9]+")
    private const val ID_HEADER = "entity_id"

    private fun checkCohort(cohort: List<String>) {
        checkWorkbook(cohort.isNotEmpty()) { NO_COMPANIES }
        checkWorkbook(cohort.toSet().size == cohort.size) { "collection lists a company ID more than once" }
    }
}
