package com.db.clientinsights.export.workbook.verify

import com.db.clientinsights.export.workbook.Sheet
import com.db.clientinsights.export.workbook.WorkbookLayout
import com.db.clientinsights.export.workbook.WorkbookLayout.NS_MAIN
import com.db.clientinsights.export.workbook.WorkbookLayout.NS_REL
import com.db.clientinsights.export.workbook.WorkbookModel
import com.db.clientinsights.export.workbook.WorksheetXml
import com.db.clientinsights.export.workbook.checkWorkbook
import com.db.clientinsights.export.workbook.columnName

/** Counts of the allowlisted worksheet features found on one tab. */
internal class SheetFeatures(
    val dataValidations: Int = 0,
    val conditionalFormats: Int = 0,
    val hyperlinks: Int = 0,
    val autoFilters: Int = 0,
    val ignoredErrorRanges: Int = 0,
)

/**
 * The worksheet elements outside sheetData, checked exactly per tab: view, columns, outline settings, and the
 * allowlisted features (AutoFilter on Bookings only; conditional formats, validations and links on Company review
 * only; numberStoredAsText-only ignoredErrors on the ID ranges; the drawing on Summary only). A feature whose range
 * would start below an empty tab is absent (never an inverted range such as A2:A1).
 */
internal class WorksheetChecks(private val model: WorkbookModel, private val sheet: Sheet, private val part: String) {
    private val where = "${sheet.name} ($part)"
    private val isSummary = sheet === model.summary
    private val isMain = sheet === model.main
    private val isBookings = sheet === model.bookings
    private val isEvidence = sheet === model.companyEvidence || sheet === model.matrix
    private val last = sheet.lastRow

    fun check(elements: List<XNode>): SheetFeatures {
        for (element in elements) checkGeneric(element)
        val byName = elements.groupBy { it.name }
        checkWorkbook(byName.filterKeys { it != "conditionalFormatting" }.values.all { it.size == 1 }) {
            "$where repeats a worksheet element"
        }
        checkSheetPr(byName["sheetPr"].orEmpty())
        checkDimension(byName["dimension"].orEmpty())
        checkView(byName["sheetViews"].orEmpty())
        checkFormat(byName["sheetFormatPr"].orEmpty())
        checkColumns(byName["cols"].orEmpty())
        checkDrawing(byName["drawing"].orEmpty())
        return SheetFeatures(
            dataValidations = checkDataValidations(byName["dataValidations"].orEmpty()),
            conditionalFormats = checkConditionalFormats(byName["conditionalFormatting"].orEmpty()),
            hyperlinks = checkHyperlinks(byName["hyperlinks"].orEmpty()),
            autoFilters = checkAutoFilter(byName["autoFilter"].orEmpty()),
            ignoredErrorRanges = checkIgnoredErrors(byName["ignoredErrors"].orEmpty()),
        )
    }

    /** Main namespace only; no relationship attribute except the Summary drawing's; no forbidden token. */
    private fun checkGeneric(element: XNode) {
        for (node in element.walk()) {
            checkWorkbook(node.namespace == NS_MAIN) { "$where has an element from another namespace" }
            for ((key, value) in node.attributes) {
                checkWorkbook(!key.startsWith("{") || (isSummary && node.name == "drawing" && key == qualified(NS_REL, "id"))) {
                    "$where <${node.name}> has a namespaced or relationship attribute"
                }
                checkWorkbook(FORBIDDEN_TOKEN !in value) { "$where <${node.name}> contains the text $FORBIDDEN_TOKEN" }
            }
            checkWorkbook(FORBIDDEN_TOKEN !in node.text) { "$where <${node.name}> contains the text $FORBIDDEN_TOKEN" }
        }
    }

    private fun checkSheetPr(found: List<XNode>) {
        if (!isMain) return checkWorkbook(found.isEmpty()) { "$where has sheet properties" }
        val pr = found.singleOrNull()
        checkWorkbook(pr != null && pr.attributes.isEmpty() && pr.children.size == 1 &&
            pr.children[0].name == "outlinePr" && pr.children[0].children.isEmpty() &&
            pr.children[0].attributes == mapOf("summaryBelow" to "0", "summaryRight" to "1")) {
            "$where outline summary rows are not set above the detail rows"
        }
    }

    private fun checkDimension(found: List<XNode>) {
        checkWorkbook(found.singleOrNull()?.attributes == mapOf("ref" to "A1:${columnName(sheet.widths.size)}$last")) {
            "$where dimension differs"
        }
    }

    /** One sheet view; only Summary is selected; frozen panes exactly as the model asks. */
    private fun checkView(found: List<XNode>) {
        val view = found.singleOrNull()?.children?.singleOrNull()
        checkWorkbook(view != null && view.name == "sheetView" && found[0].attributes.isEmpty()) { "$where needs exactly one sheet view" }
        checkWorkbook(view!!["tabSelected"] == (if (isSummary) "1" else null) && view["workbookViewId"] == "0") {
            "$where selected-tab state differs"
        }
        val panes = view.all("pane")
        checkWorkbook(view.children.all { it.name == "pane" || it.name == "selection" } && panes.size <= 1) {
            "$where sheet view has unexpected content"
        }
        val columns = sheet.frozenColumns
        val rows = sheet.frozenRows
        if (columns == 0 && rows == 0) return checkWorkbook(panes.isEmpty()) { "$where has a frozen pane the model does not ask for" }
        val pane = panes.singleOrNull()
        checkWorkbook(pane != null && pane["state"] == "frozen" &&
            pane["xSplit"] == columns.takeIf { it > 0 }?.toString() && pane["ySplit"] == rows.takeIf { it > 0 }?.toString() &&
            pane["topLeftCell"] == columnName(columns + 1) + (rows + 1)) { "$where frozen panes differ" }
    }

    private fun checkFormat(found: List<XNode>) {
        val format = found.singleOrNull()
        checkWorkbook(format != null && format.children.isEmpty() &&
            format["outlineLevelRow"] == (if (isMain) "2" else null)) { "$where row outline settings differ" }
    }

    private fun checkColumns(found: List<XNode>) {
        val cols = found.singleOrNull()?.children.orEmpty()
        checkWorkbook(cols.size == sheet.widths.size) { "$where column widths differ" }
        cols.forEachIndexed { i, col ->
            checkWorkbook(col.name == "col" && col.attributes.keys == setOf("min", "max", "width", "customWidth") &&
                col["min"] == "${i + 1}" && col["max"] == "${i + 1}" && col["customWidth"] == "1" &&
                col["width"]?.toDoubleOrNull() == sheet.widths[i]) { "$where column ${columnName(i + 1)} width differs" }
        }
    }

    private fun checkDrawing(found: List<XNode>) {
        if (!isSummary) return checkWorkbook(found.isEmpty()) { "$where has a drawing (only Summary has the chart)" }
        checkWorkbook(found.singleOrNull()?.let { it.attributes == mapOf(qualified(NS_REL, "id") to "rId1") && it.children.isEmpty() } == true) {
            "$where drawing reference differs"
        }
    }

    /** Bookings only: the AutoFilter over the whole flat table, which also covers the two jump-key columns. */
    private fun checkAutoFilter(found: List<XNode>): Int {
        if (!isBookings && !isEvidence) return found.size.also { checkWorkbook(it == 0) { "$where has an unexpected AutoFilter" } }
        val filter = found.singleOrNull()
        val ref = if (isBookings) WorkbookLayout.bookingsFilterRef(last) else "A1:${columnName(sheet.widths.size)}$last"
        checkWorkbook(filter != null && filter.attributes == mapOf("ref" to ref) && filter.children.isEmpty()) {
            "$where AutoFilter range differs or has saved filter or sort settings"
        }
        checkRanges(ref) { "$where AutoFilter range is inverted" }
        checkWorkbook(!isBookings || lastColumnOf(ref) >= maxOf(WorkbookLayout.B_CLIENT_KEY, WorkbookLayout.B_PARENT_KEY)) {
            "$where AutoFilter does not cover the jump-key columns"
        }
        return 1
    }

    /** Company review only, when it has data rows: exactly the grey-row rule and the key-share data bar. */
    private fun checkConditionalFormats(found: List<XNode>): Int {
        if (!isMain || last < 2) return found.size.also { checkWorkbook(it == 0) { "$where has conditional formats" } }
        checkWorkbook(found.size == 2) { "$where does not have exactly 2 conditional formats" }
        val (grey, bar) = found
        val share = columnName(WorkbookLayout.M_SHARE)
        checkWorkbook(grey.attributes == mapOf("sqref" to "A2:${columnName(WorkbookLayout.MAIN_HEADERS.size)}$last")) {
            "$where grey-row conditional format range differs"
        }
        val greyRule = grey.children.singleOrNull()
        checkWorkbook(greyRule != null && greyRule.name == "cfRule" &&
            greyRule.attributes == mapOf("type" to "expression", "dxfId" to "0", "priority" to "1") &&
            greyRule.children.size == 1 && greyRule.children[0].name == "formula" &&
            greyRule.children[0].attributes.isEmpty() && greyRule.children[0].children.isEmpty() &&
            greyRule.children[0].text == WorkbookLayout.recordedStatusFormula()) { "$where grey-row rule differs" }
        checkWorkbook(bar.attributes == mapOf("sqref" to "${share}2:$share$last")) { "$where data-bar range differs" }
        val barRule = bar.children.singleOrNull()
        checkWorkbook(barRule != null && barRule.name == "cfRule" &&
            barRule.attributes == mapOf("type" to "dataBar", "priority" to "2") && barRule.children.size == 1) {
            "$where data-bar rule differs"
        }
        val dataBar = barRule!!.children[0]
        val parts = dataBar.children.map { Triple(it.name, it.attributes, it.children.size + it.text.length) }
        checkWorkbook(dataBar.name == "dataBar" && dataBar.attributes == mapOf("minLength" to "0", "maxLength" to "100") &&
            parts == listOf(Triple("cfvo", mapOf("type" to "num", "val" to "0"), 0),
                Triple("cfvo", mapOf("type" to "num", "val" to "100"), 0),
                Triple("color", mapOf("rgb" to "FF9BC2E6"), 0))) { "$where data-bar settings differ" }
        return 2
    }

    /** Company review only, when it has reviewer rows: the decision list and the date rule, on those rows only. */
    private fun checkDataValidations(found: List<XNode>): Int {
        if (!isMain || model.reviewRows.isEmpty()) {
            return found.size.also { checkWorkbook(it == 0) { "$where has data validations" } }
        }
        val list = found.singleOrNull()
        checkWorkbook(list != null && list.attributes == mapOf("count" to "2") && list.children.size == 2) {
            "$where does not have exactly 2 data validations"
        }
        val (decision, date) = list!!.children
        val decisionSqref = WorkbookLayout.cellList(WorkbookLayout.M_DECISION, model.reviewRows)
        val dateSqref = WorkbookLayout.cellList(WorkbookLayout.M_DATE, model.reviewRows)
        checkWorkbook(decision.name == "dataValidation" && withoutDefaultErrorStyle(decision) == mapOf(
            "type" to "list", "allowBlank" to "1", "showInputMessage" to "1", "showErrorMessage" to "1",
            "errorTitle" to "Reviewer decision", "error" to WorksheetXml.DECISION_ERROR,
            "promptTitle" to "Reviewer decision", "prompt" to WorksheetXml.decisionPrompt(model.decisionOptions), "sqref" to decisionSqref)) {
            "$where reviewer decision validation differs"
        }
        checkWorkbook(formulas(decision) == listOf("formula1" to WorkbookLayout.decisionListFormula(model.decisionOptions))) {
            "$where reviewer decision list differs"
        }
        checkWorkbook(date.name == "dataValidation" && withoutDefaultErrorStyle(date) == mapOf(
            "type" to "date", "operator" to "between", "allowBlank" to "1", "showErrorMessage" to "1",
            "errorTitle" to "Review date", "error" to WorksheetXml.DATE_ERROR, "sqref" to dateSqref)) {
            "$where review date validation differs"
        }
        checkWorkbook(formulas(date) == listOf("formula1" to WorkbookLayout.DATE_MIN, "formula2" to WorkbookLayout.DATE_MAX)) {
            "$where review date bounds differ"
        }
        checkSqref(decisionSqref) { "$where reviewer decision validation range is invalid" }
        checkSqref(dateSqref) { "$where review date validation range is invalid" }
        return 2
    }

    /** errorStyle="stop" is Excel's default; accept it written or omitted, nothing else. */
    private fun withoutDefaultErrorStyle(node: XNode): Map<String, String> =
        if (node["errorStyle"] == "stop") node.attributes - "errorStyle" else node.attributes

    private fun formulas(node: XNode): List<Pair<String, String>> = node.children.map {
        checkWorkbook(it.attributes.isEmpty() && it.children.isEmpty()) { "$where validation formula has unexpected content" }
        it.name to it.text
    }

    /** Company review only: exactly the jump cells, each to its defined name (location), never a relationship. */
    private fun checkHyperlinks(found: List<XNode>): Int {
        if (!isMain || model.jumps.isEmpty()) return found.size.also { checkWorkbook(it == 0) { "$where has hyperlinks" } }
        val links = found.singleOrNull()?.takeIf { it.attributes.isEmpty() }?.children
        checkWorkbook(links != null && links.size == model.jumps.size && links.size <= WorkbookLayout.MAX_HYPERLINKS) {
            "$where does not have exactly one hyperlink per jump"
        }
        links!!.zip(model.jumps).forEach { (link, jump) ->
            checkWorkbook(link.name == "hyperlink" && link.children.isEmpty() &&
                link.attributes.keys.all { it in HYPERLINK_ATTRIBUTES } &&
                link["ref"] == jump.cellRef && link["location"] == jump.name &&
                link["tooltip"] in setOf(null, WorksheetXml.JUMP_TOOLTIP)) {
                "$where hyperlink at ${jump.cellRef} differs from its jump"
            }
        }
        return links.size
    }

    /** numberStoredAsText only, on exactly the ID ranges of Company review or Bookings; nowhere else. */
    private fun checkIgnoredErrors(found: List<XNode>): Int {
        val sqref = when {
            last < 2 -> null
            isMain -> WorkbookLayout.mainIdRanges(last)
            isBookings -> WorkbookLayout.bookingIdRanges(last)
            else -> null
        }
        if (sqref == null) return found.size.also { checkWorkbook(it == 0) { "$where suppresses error indicators" } }
        val item = found.singleOrNull()?.takeIf { it.attributes.isEmpty() }?.children?.singleOrNull()
        checkWorkbook(item != null && item.name == "ignoredError" && item.children.isEmpty() &&
            item.attributes == mapOf("sqref" to sqref, "numberStoredAsText" to "1")) {
            "$where ignored errors differ (only numberStoredAsText on the ID ranges is allowed)"
        }
        return checkSqref(sqref) { "$where ignored-error range is invalid" }
    }

    companion object {
        private val HYPERLINK_ATTRIBUTES = setOf("ref", "location", "tooltip", "display")
    }
}
