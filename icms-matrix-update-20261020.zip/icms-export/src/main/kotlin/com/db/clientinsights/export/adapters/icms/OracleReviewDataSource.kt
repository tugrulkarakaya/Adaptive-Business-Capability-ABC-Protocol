package com.db.clientinsights.export.adapters.icms

import com.db.clientinsights.export.domain.*
import com.db.clientinsights.export.ports.ReviewDataSource
import java.sql.ResultSet

/** Each source boundary has its own profile. Missing optional sources are recorded, never replaced by negatives. */
class OracleReviewDataSource(private val executor: (String) -> JdbcQueryExecutor) : ReviewDataSource {
    override fun fetch(request: ExportRequest, facts: ExtractedFacts): ReviewFacts {
        val queries = mutableListOf<QueryRun>()
        fun <T> read(profile: String, definition: QueryDefinition<T>, keys: List<String>,
                     parameters: List<String?> = emptyList()): List<SourceRow<T>> {
            val result = executor(profile).fetch(definition, keys, parameters)
            queries += result.queries
            return result.rows
        }
        val ids = request.entityIds.map { it.value }
        val paths = read("review", PATHS, ids)
        val current = read("review", CURRENT, ids)
        val allStatusPaths = read("review", ALL_STATUS_PATHS, ids)
        val routings = read("routings", ROUTINGS, ids)
        val shared = read("icms", SHARED, ids)
        val assignments = read("icms", ASSIGNMENTS, ids)
        val lineage = read("routings", LINEAGE, ids)
        val platformNames = read("platforms", PLATFORM_NAMES, ids, listOf(request.bookingStatus, request.bookingStatus))
        val nativeBookingIds = platformNames.map { it.data.nativeBookingId }.numericIds()
        val nativeBookings = read("native-bookings", NATIVE_BOOKINGS, nativeBookingIds)
        val partyIds = (paths.flatMap { listOf(it.data.hierarchyParentId, it.data.reportParentId) } +
            current.flatMap { listOf(it.data.rhpId, it.data.ultimateParentId) } +
            allStatusPaths.flatMap { listOf(it.data.rhpId, it.data.ultimateParentId) } +
            facts.bookingRecords.map { it.data.assignedCrdsPartyId?.value }).numericIds()
        val parties = read("parties", PARTIES, partyIds)
        val salesforce = read("salesforce", SALESFORCE, partyIds)
        val referencedIds = (parties.flatMap { listOf(it.data.survivingEntityId, it.data.ultimateParentId, it.data.immediateParentId) } +
            salesforce.flatMap { listOf(it.data.legalUltimateParentId, it.data.legalImmediateParentId, it.data.resolvedReportingGroupId()) + it.data.pathIds })
            .numericIds().filter { it !in partyIds }
        val referenced = read("parties", PARTIES, referencedIds)
        val identityIds = (partyIds + referencedIds).distinct()
        val identities = IDENTITY_QUERIES.flatMap { read("identity", it, identityIds) }
        val availability = ACTIVITY_QUERIES.map { definition ->
            val page = executor("activity").fetchPage(definition, null, 1)
            queries += page.query
            ActivityAvailability(definition.dataset, when {
                page.query.status != FetchStatus.COMPLETE -> "UNAVAILABLE"
                page.rows.isEmpty() -> "NO_ACCESSIBLE_ROWS"
                else -> "HAS_ROWS"
            })
        }
        return ReviewFacts(paths, current, parties + referenced, salesforce, routings, shared, identities,
            assignments, lineage, availability, queries, platformNames, nativeBookings, allStatusPaths)
    }

    companion object {
        private val PLATFORM_NAMES = QueryDefinition(SqlTemplate("booking-platform-names"), "BOOKING_PLATFORM_NAMES", { r ->
            BookingPlatformFact(checkNotNull(r.idText("id")), IcmsEntityId.parse(checkNotNull(r.idText("le_id"))), checkNotNull(r.idText("booking_record_id")),
                r.getString("booking_code"), r.idText("settlement_system_id"), r.getString("booking_status"),
                checkNotNull(r.idText("routing_id")), r.idText("native_booking_id"), checkNotNull(r.idText("account_id")), r.idText("account_entity_id"),
                checkNotNull(r.idText("platform_record_id")), r.idText("platform_id"), r.getString("platform_name"),
                r.getString("customer_code"), r.getString("name"), r.getString("firm_code"), r.getString("firm_name"),
                r.getString("created_at"), r.getString("updated_at"))
        }, BookingPlatformFact::rowId, { stableId(it.bookingRecordId, it.routingId, it.platformRecordId) })

        private val NATIVE_BOOKINGS = QueryDefinition(SqlTemplate("platform-native-bookings"), "PLATFORM_NATIVE_BOOKINGS", { r ->
            PlatformNativeBooking(checkNotNull(r.idText("id")), IcmsEntityId.parse(checkNotNull(r.idText("le_id"))), r.getString("booking_code"),
                r.idText("settlement_system_id"), r.getString("status"))
        }, PlatformNativeBooking::recordId)

        private val PATHS = QueryDefinition(SqlTemplate("parent-paths"), "PARENT_PATHS", { r ->
            ParentPath(r.getString("id"), r.idText("system_id"), r.getString("booking_code"),
                r.idText("hierarchy_parent_id"), r.idText("report_parent_id"), r.getLong("path_count"),
                r.getLong("active_xref_paths"), r.getLong("report_rank_paths"), r.getInt("tie_at_report_rank") == 1,
                listOfNotNull(r.idText("min_xref_status"), r.idText("max_xref_status")).distinct())
        }, ParentPath::rowId, { stableId(it.systemId, it.bookingCode, it.hierarchyParentId) })

        private val ALL_STATUS_PATHS = QueryDefinition(SqlTemplate("all-booking-status-paths"), "ALL_BOOKING_STATUS_PATHS", { r ->
            AllStatusBookingPath(r.getString("id"), r.idText("system_id"), r.getString("booking_code"),
                r.idText("rhp_id"), r.idText("hierarchy_parent_id"), r.getString("xref_status"),
                r.getString("xref_status_date"),
                listOf("product_system_status", "product_adoption_status", "adoption_entity_status",
                    "adoption_location_status", "business_relationship_status", "hierarchy_status", "hierarchy_ended")
                    .associateWith { r.getString(it) }, r.getLong("path_count"))
        }, AllStatusBookingPath::rowId, { path -> stableId(path.systemId, path.bookingCode, path.rhpId,
            path.ultimateParentId, path.bookingStatus, path.bookingStatusDate, *path.statuses.values.toTypedArray()) })

        private val CURRENT = QueryDefinition(SqlTemplate("current-booking-paths"), "CURRENT_BOOKING_PATHS", { r ->
            CurrentBookingPath(r.getString("id"), IcmsEntityId.parse(r.getString("le_id")), r.getInt("has_crds_path") == 1,
                r.idText("rhp_id"), r.idText("ultimate_parent_id"), r.getLong("current_parents_on_key"),
                listOf("account_xref_status", "product_system_status", "product_adoption_status", "adoption_entity_status",
                    "adoption_location_status", "business_relationship_status", "hierarchy_status").associateWith { r.idText(it) })
        }, CurrentBookingPath::recordId)

        private val PARTIES = QueryDefinition(SqlTemplate("party-facts"), "CRDS_PARTIES", { r ->
            PartyFact(r.getString("id"), checkNotNull(r.idText("party_id")), r.getString("party_std_nm"), r.getString("party_legal_nm"),
                r.idText("surviving_entity_id"), r.getString("party_industry_status"), r.getString("industry_status_date"),
                r.idText("ultimate_parent_id"), r.idText("immediate_parent_id"))
        }, PartyFact::rowId, { stableId(it.partyId, it.ultimateParentId, it.immediateParentId) })

        private val SALESFORCE = QueryDefinition(SqlTemplate("salesforce-hierarchy"), "SALESFORCE_HIERARCHY", { r ->
            SalesforceFact(r.getString("id"), r.getString("party_id"), r.getString("name"), r.idText("legal_ultimate_parent_id"),
                r.idText("legal_immediate_parent_id"), r.idText("reporting_group_id"), r.getInt("reporting_level") == 1,
                (1..25).map { r.idText("l$it") })
        }, SalesforceFact::rowId, { stableId(it.partyId, it.legalUltimateParentId, it.reportingGroupId, it.reportingLevel.toString(), *it.pathIds.toTypedArray()) }, textKeys = true)

        private val ROUTINGS = QueryDefinition(SqlTemplate("settlement-routings"), "SETTLEMENT_ROUTINGS", { r ->
            RoutingFact(r.getString("id"), IcmsEntityId.parse(checkNotNull(r.idText("le_id"))), r.getString("booking_code"),
                r.idText("settlement_system_id"), r.getLong("routing_count"), r.getLong("block_count"), r.getString("last_change"))
        }, RoutingFact::rowId, { stableId(it.entityId.value, it.bookingCode, it.settlementSystemId) })

        private val SHARED = QueryDefinition(SqlTemplate("shared-booking-keys"), "SHARED_BOOKING_KEYS", { r ->
            SharedBookingKey(r.getString("id"), IcmsEntityId.parse(r.getString("le_id")), r.getString("booking_code"),
                r.idText("settlement_system_id"), IcmsEntityId.parse(r.getString("other_le_id")), r.getString("other_name"))
        }, SharedBookingKey::rowId, { stableId(it.entityId.value, it.bookingCode, it.settlementSystemId, it.otherEntityId.value) })

        private val ASSIGNMENTS = QueryDefinition(SqlTemplate("assignment-lineage"), "ASSIGNMENT_LINEAGE", { r ->
            AssignmentLineage(r.getString("id"), IcmsEntityId.parse(r.getString("le_id")), r.idText("activated_db_le_id"), r.idText("db_le_override_src"),
                r.getString("booking_code"), r.idText("settlement_system_id"), r.idText("crds_id"), r.getString("status"))
        }, AssignmentLineage::recordId)

        private val LINEAGE = QueryDefinition(SqlTemplate("routing-lineage"), "ROUTING_LINEAGE", { r ->
            RoutingLineage(r.getString("id"), IcmsEntityId.parse(r.getString("le_id")), r.getString("booking_code"),
                r.idText("settlement_system_id"), r.getLong("route_count"), r.getLong("active_route_count"),
                r.getLong("matching_assignment_ids"), r.getLong("account_count"), r.getLong("requested_entity_accounts"),
                r.getLong("missing_accounts"), r.getLong("other_entity_routes"))
        }, RoutingLineage::rowId, { stableId(it.entityId.value, it.bookingCode, it.settlementSystemId) })

        private fun identity(query: String, kind: String, columns: List<String>) = QueryDefinition(
            SqlTemplate(query), kind, { r: ResultSet ->
                BankIdentityFact(r.getString("id"), checkNotNull(r.idText("party_id")), kind, columns.associateWith { r.getString(it) })
            }, BankIdentityFact::rowId, { stableId(it.partyId, *it.fields.values.toTypedArray()) })

        private val IDENTITY_QUERIES = listOf(
            identity("bank-lei-identifiers", "BANK_LEI_IDENTIFIERS", listOf("lei", "valid_from", "valid_to", "expiry_date", "updated_at")),
            identity("bank-identity-cache", "BANK_IDENTITY_CACHE", listOf("lei", "db_le_name", "country", "bic", "status", "updated_at")),
            identity("bank-party-address", "BANK_PARTY_ADDRESS", listOf("address_type", "address_line1", "address_line2", "address_line3", "address_line4", "postal_code", "country")),
        )
        private val ACTIVITY_QUERIES = listOf("activity-ps-trade" to "PS_TRADE", "activity-eplatform" to "V_ICMS_EPLATFORMACCOUNTTRADE",
            "activity-mosaic" to "V_MOSAIC_TRANSACTION").map { (query, dataset) ->
            QueryDefinition(SqlTemplate(query), dataset, { r: ResultSet -> r.getString("id") }, { it })
        }
    }
}

private fun List<String?>.numericIds(): List<String> = filterNotNull().filter { it.matches(Regex("[0-9]+")) }.distinct()
private fun stableId(vararg fields: String?): String = fields.joinToString(":") { it?.let { value -> "${value.length}-$value" } ?: "null" }
