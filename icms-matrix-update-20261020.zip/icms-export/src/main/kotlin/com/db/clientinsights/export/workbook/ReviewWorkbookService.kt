package com.db.clientinsights.export.workbook

import com.db.clientinsights.export.domain.Producer
import com.db.clientinsights.export.domain.invalidInput
import java.io.BufferedOutputStream
import java.nio.file.Files
import java.nio.file.LinkOption.NOFOLLOW_LINKS
import java.nio.file.Path
import java.nio.file.StandardOpenOption.CREATE_NEW
import java.nio.file.StandardOpenOption.WRITE
import java.security.DigestOutputStream
import java.security.MessageDigest
import java.util.Locale

/** What one offline workbook run was asked to do. */
internal data class WorkbookOptions(
    val input: Path,
    val output: Path,
    val expectedCount: Int?,
    val expectedIds: Path?,
    val runNotes: List<String>,
    val decisionOptions: List<String>,
)

/** The published workbook and its receipt. */
internal data class WorkbookResult(
    val workbook: Path,
    val receipt: Path,
    val companies: Int,
    val candidates: Int,
    val bookings: Int,
    val workbookSha256: String,
)

/**
 * Builds the human review workbook of one export and publishes it with its receipt, all or nothing.
 *
 * Steps: read and integrity-check the export (WorkbookInput), join it (ReviewJoin), lay out the six tabs
 * (WorkbookContent), stream the .xlsx to a staging file (XlsxWriter), re-read and check it (XlsxVerifier), write the
 * receipt, then publish. A failed check throws WorkbookCheckFailure; nothing is published and staging files are
 * removed. The workbook adds no business rule: it presents the export's facts for people to decide.
 */
internal object ReviewWorkbookService {
    /** Receipt input kind of the workbook built by a normal export run (offline runs record the input's own kind). */
    const val EXPORT_RUN = "export-run"

    /**
     * Offline regeneration from a saved export (collection or single-run batch). The outputs must not exist yet and
     * must lie outside the input export folder (checked on real paths, so links and aliases cannot hide it).
     */
    fun generate(options: WorkbookOptions, producer: Producer): WorkbookResult {
        checkNotInterrupted()
        val source = WorkbookSource.locate(options.input)
        val target = WorkbookTarget.forOutput(options.output, source.folder)
        val expectedIds = options.expectedIds?.let(WorkbookInput::readIdList)
        val collection = WorkbookInput.read(source.path)
        checkExpectedCohort(collection.cohort, options.expectedCount, expectedIds)
        val receiptOptions = ReceiptOptions(options.expectedCount, expectedIds?.size, options.decisionOptions,
            options.runNotes.size)
        return build(collection, collection.inputKind, options.runNotes, receiptOptions, producer, target)
    }

    /**
     * The normal export run: builds the workbook from the collection's staged (not yet published) manifest and
     * publishes ICMS-company-review.xlsx and workbook-receipt.json inside the collection folder. The caller
     * publishes the collection manifest only after this returns.
     */
    fun generateForExport(collectionDir: Path, stagedManifest: Path, producer: Producer,
                          decisionOptions: List<String>): WorkbookResult {
        checkNotInterrupted()
        val folder = collectionDir.toRealPath()
        val target = WorkbookTarget.inFolder(folder)
        val collection = WorkbookInput.readCollection(folder, stagedManifest)
        val receiptOptions = ReceiptOptions(null, null, decisionOptions, 0)
        return build(collection, EXPORT_RUN, emptyList(), receiptOptions, producer, target)
    }

    /** --expected-count and --expected-ids guard against building the review for the wrong cohort. */
    private fun checkExpectedCohort(cohort: List<String>, expectedCount: Int?, expectedIds: List<String>?) {
        if (expectedCount != null) checkWorkbook(cohort.size == expectedCount) {
            "the export has ${cohort.size} requested companies, --expected-count is $expectedCount"
        }
        if (expectedIds != null) checkWorkbook(expectedIds.size == cohort.size && expectedIds.toSet() == cohort.toSet()) {
            "the export's company IDs differ from --expected-ids (${expectedIds.size} listed, ${cohort.size} in the export)"
        }
    }

    private fun build(collection: CollectionData, kind: String, runNotes: List<String>, receiptOptions: ReceiptOptions,
                      producer: Producer, target: WorkbookTarget): WorkbookResult {
        val review = ReviewJoin.join(collection)
        val model = WorkbookContent.build(collection, review, runNotes, receiptOptions.decisionOptions)
        checkSheetLimits(model)
        var sha256 = ""
        target.publish { staged ->
            sha256 = writeWorkbook(model, staged)
            val verification = XlsxVerifier.verify(staged, model, review, collection)
            checkWorkbook(fileSha256(staged) == sha256) { "the workbook file changed after it was written" }
            WorkbookReceipt.json(producer, kind, collection, receiptOptions, verification,
                target.workbook.fileName.toString(), Files.size(staged), sha256)
        }
        return WorkbookResult(target.workbook, target.receipt, review.companies.size, review.candidateCount,
            review.bookingCount, sha256)
    }

    /**
     * Excel's per-sheet limits, checked on the model before anything is written: rows (including the header) and
     * hyperlinks. The build stops instead of truncating.
     */
    internal fun checkSheetLimits(model: WorkbookModel) {
        for (sheet in model.sheets) {
            checkWorkbook(sheet.lastRow <= WorkbookLayout.MAX_SHEET_ROWS) {
                "sheet ${sheet.name} needs ${sheet.lastRow} rows, over Excel's ${WorkbookLayout.MAX_SHEET_ROWS} limit " +
                    "(not truncated; build stopped)"
            }
        }
        checkWorkbook(model.jumps.size <= WorkbookLayout.MAX_HYPERLINKS) {
            "sheet ${WorkbookLayout.MAIN_SHEET} needs ${model.jumps.size} links, over Excel's " +
                "${WorkbookLayout.MAX_HYPERLINKS} limit (build stopped)"
        }
    }

    /** Streams the package to a new file and returns its SHA-256, computed while writing. */
    private fun writeWorkbook(model: WorkbookModel, file: Path): String {
        val digest = MessageDigest.getInstance("SHA-256")
        DigestOutputStream(BufferedOutputStream(Files.newOutputStream(file, CREATE_NEW, WRITE)), digest).use { out ->
            XlsxWriter.write(model, out)
        }
        return hex(digest.digest())
    }

    /** SHA-256 of a file, read in blocks (the workbook can be large). */
    internal fun fileSha256(file: Path): String {
        val digest = MessageDigest.getInstance("SHA-256")
        Files.newInputStream(file).use { input ->
            val buffer = ByteArray(1 shl 16)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                digest.update(buffer, 0, read)
            }
        }
        return hex(digest.digest())
    }

    private fun hex(bytes: ByteArray): String = bytes.joinToString("") { String.format(Locale.ROOT, "%02x", it) }
}

/**
 * --input as the user supplied it, and the real export folder it names (the collection folder, or the single-run batch
 * folder). The supplied path goes to WorkbookInput.read unchanged, so its manifest-name and link guards see the name
 * the user gave; the real folder is used to keep outputs out of the export. Only collection-manifest.json and
 * run-manifest.json are recognised, so a staged (unpublished) collection manifest is never read.
 */
internal class WorkbookSource(val path: Path, val folder: Path) {
    companion object {
        private const val COLLECTION_MANIFEST = "collection-manifest.json"
        private const val RUN_MANIFEST = "run-manifest.json"

        /** A missing input is a file error (NoSuchFileException); an unrecognised one is a usage error. */
        fun locate(input: Path): WorkbookSource {
            val real = input.toRealPath()
            val suppliedName = input.fileName?.toString().orEmpty()
            return when {
                Files.isDirectory(real) && (Files.exists(real.resolve(COLLECTION_MANIFEST), NOFOLLOW_LINKS) ||
                    Files.exists(real.resolve(RUN_MANIFEST), NOFOLLOW_LINKS)) -> WorkbookSource(input, real)
                Files.isRegularFile(real) && (suppliedName == COLLECTION_MANIFEST || suppliedName == RUN_MANIFEST) ->
                    WorkbookSource(input, input.toAbsolutePath().parent.toRealPath())
                else -> invalidInput("--input must be a collection folder, its collection-manifest.json, " +
                    "a single-run batch folder or its run-manifest.json.")
            }
        }
    }
}

/** Stops a run whose thread was interrupted (exit 130); called before work starts and before each publishing move. */
internal fun checkNotInterrupted() {
    if (Thread.currentThread().isInterrupted) throw InterruptedException("Interrupted; nothing more is published.")
}
