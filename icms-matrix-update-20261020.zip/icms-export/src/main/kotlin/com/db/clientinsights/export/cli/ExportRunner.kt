package com.db.clientinsights.export.cli

import com.db.clientinsights.export.adapters.bundle.ExportCollectionWriter
import com.db.clientinsights.export.adapters.fixture.FixtureSources
import com.db.clientinsights.export.adapters.icms.OracleIcmsReferenceSource
import com.db.clientinsights.export.adapters.icms.OracleIcmsSource
import com.db.clientinsights.export.adapters.icms.OracleReviewCohortSource
import com.db.clientinsights.export.adapters.icms.OracleReviewDataSource
import com.db.clientinsights.export.adapters.icms.OracleUsageEvidenceSource
import com.db.clientinsights.export.adapters.icms.OracleSourceConfiguration
import com.db.clientinsights.export.application.ExportService
import com.db.clientinsights.export.application.CohortExportService
import com.db.clientinsights.export.ports.ReviewCohortSource
import com.db.clientinsights.export.ports.IcmsSource
import com.db.clientinsights.export.ports.IcmsReferenceSource
import com.db.clientinsights.export.ports.ReviewDataSource
import com.db.clientinsights.export.ports.UsageEvidenceSource
import com.db.clientinsights.export.ports.EvidenceBatchSink
import com.db.clientinsights.export.domain.FetchStatus
import com.db.clientinsights.export.domain.Producer
import java.io.PrintStream
import java.util.Properties
import java.util.UUID
import kotlin.system.exitProcess

fun main(args: Array<String>) { exitProcess(runCli(args)) }

/**
 * Runs one export (or, with first argument `workbook`, the offline review-workbook command) and returns its exit code.
 *
 * - 0: complete extraction, review workbook built and verified; review findings may still exist.
 * - 2: incomplete or unconfigured source evidence; the collection manifest is published with that status (the
 *   workbook is still built and shows the evidence as incomplete).
 * - 3: the batches were written but the review workbook could not be built or verified; the collection manifest is
 *   NOT published.
 * - 64: invalid input or configuration found by the export's own validation.
 * - 1: file error while reading an input file (configuration, fixture or ID list) or writing output.
 * - 70: source-contract violation or any other failure, including unexpected argument or IO errors from sources,
 *   adapters or the environment; raw exception text is never printed.
 * - 130: interrupted export; completed batches remain and no collection manifest is published.
 */
fun runCli(args: Array<String>, out: PrintStream = System.out, err: PrintStream = System.err,
           environment: (String) -> String? = System::getenv): Int {
    if (args.firstOrNull() == WORKBOOK_COMMAND) return runWorkbookCommand(args.drop(1), out, err)
    if (args.contentEquals(arrayOf("--help"))) {
        out.println("""
            ICMS deterministic review export
            Usage: icms-export (--demo | --fixture FILE | --config FILE)
                   (--ids 101,102 | --ids-file cohort.csv | --all-flagged)
                   [--booking-status active|all] [--export-batch-size 10] [--workers 2] [--output DIRECTORY]
                   [--decision-options "a|b|c"]
            CSV input: one entity ID per row, optionally headed entity_id.
            --all-flagged selects all companies flagged by the baseline multiple-ultimate-parent report.
            It writes one evidence bundle per batch and a collection-manifest.json with totals and discovery status.
            --export-batch-size accepts 1..500 companies for every selection; --workers accepts 1..4.
            A finished run (exit 0 or 2) has collection-manifest.json and batches/<run-id>/ with CSVs and evidence.
            Includes current/baseline parent checks, reporting groups, routings and bank identity evidence.
            AI is disabled. Recent trading and confirmation routing remain NOT_EVALUATED until validated sources exist.
            Each export also writes the review workbook ICMS-company-review.xlsx and workbook-receipt.json in its
            collection folder before publishing collection-manifest.json (exit 3 if the workbook fails).
        """.trimIndent())
        out.println()
        out.println(WORKBOOK_USAGE)
        return 0
    }
    return exitCodeOf(err) {
        val options = readUserInput { CliOptions.parse(args) }
        exportCollection(options, openSources(options, environment), out)
    }
}

/** The source adapters that one CLI run reads from. */
internal class CliSources(
    val icms: IcmsSource,
    val catalog: ReviewCohortSource,
    val references: IcmsReferenceSource,
    val review: ReviewDataSource?,
    val usage: UsageEvidenceSource? = null,
)

/** Opens the demo, fixture or Oracle sources selected by the options; configuration problems are input errors. */
internal fun openSources(options: CliOptions, environment: (String) -> String?): CliSources {
    if (options.demo || options.fixture != null) {
        val fixture = options.fixture?.let { readUserInput { FixtureSources.load(it) } } ?: FixtureSources.demo()
        return CliSources(icms = fixture, catalog = fixture, references = fixture, review = fixture.reviewSource)
    }
    // Loading only reads the file; the environment is consulted later, inside executor(), with typed errors.
    val config = readUserInput { OracleSourceConfiguration.load(checkNotNull(options.config), environment) }
    return CliSources(
        icms = OracleIcmsSource(config.executor("icms")),
        catalog = OracleReviewCohortSource(config.executor("cohort")),
        references = OracleIcmsReferenceSource(config.executor("references")),
        review = OracleReviewDataSource(config::executor),
        usage = OracleUsageEvidenceSource(config::executor),
    )
}

/** Writes every batch and then the collection manifest; returns 0 for complete and 2 for incomplete evidence. */
internal fun exportCollection(options: CliOptions, sources: CliSources, out: PrintStream,
                              workbookBuilder: ExportWorkbookBuilder = ExportWorkbookBuilder.DEFAULT): Int {
    val producer = buildProducer()
    val service = ExportService(sources.icms, sources.references, producer, reviewSource = sources.review,
        usageEvidenceSource = sources.usage)
    val request = options.request
    val runId = UUID.randomUUID().toString()
    val writer = writeOutput { ExportCollectionWriter(options.output, runId) }
    var written = 0
    val sink = EvidenceBatchSink { bundle ->
        writeOutput { writer.writeBatch(bundle) }.also {
            written++
            out.println("Batch $written saved: ${it.entityCount} entities; ${it.bookingCount} booking records; " +
                "extraction: ${it.extractionStatus}.")
        }
    }
    val collections = CohortExportService(sources.catalog, service, producer)
    val collection = if (request == null)
        collections.export(runId, options.bookingStatus, options.exportBatchSize, sink, options.workers)
    else collections.exportSelected(runId, request, options.exportBatchSize, sink, options.workers)
    // The manifest is staged, the review workbook built from it, and only then is the manifest published.
    val step = ExportWorkbookStep(workbookBuilder)
    val staged = writeOutput { writer.stage(collection) }
    val skipped = step.skipReason(writer.directory, collection)
    val workbook = if (skipped == null) step.build(writer, staged, producer, options.decisionOptions) else null
    step.publish(writer, staged, workbook)
    if (skipped != null) out.println("No review workbook: $skipped.")
    out.println("Collection folder: ${writer.directory.toAbsolutePath()}")
    out.println("Selected entities: ${collection.discoveredEntityCount}; found: ${collection.foundEntityCount}; " +
        "batches: ${collection.batches.size}")
    out.println("Exported booking records: ${collection.exportedBookingCount}; data issues: ${collection.issueCount}")
    out.println("Extraction: ${collection.extractionStatus}. AI: DISABLED. Recent trading: NOT_EVALUATED.")
    workbook?.let { out.println("Review workbook: ${it.workbook.toAbsolutePath()}") }
    return if (collection.extractionStatus == FetchStatus.COMPLETE) 0 else 2
}

/** The application version and git revision recorded in every manifest and workbook receipt. */
internal fun buildProducer(): Producer {
    val properties = Properties()
    ExportService::class.java.getResourceAsStream("/export-build.properties")?.use { properties.load(it) }
    return Producer(properties.getProperty("version", "unknown"), properties.getProperty("revision", "unknown"),
        properties.getProperty("dirty", "true").toBoolean())
}
