package com.db.clientinsights.export.workbook

import com.db.clientinsights.export.workbook.WorkbookLayout.S_HEADER
import com.db.clientinsights.export.workbook.WorkbookLayout.S_TITLE

/**
 * The "Rules and assumptions" tab: what the file is and is not, how to read the numbers, a glossary, the inherited
 * assumptions A1-A4 with blank team cells (exactly 8), this run's facts, the batches, issues not tied to one company,
 * and one line per column of 'Company review' and 'Bookings'. The A1-A4 texts are the accepted v3.1 wording.
 */
internal object RulesSheet {
    /** Blank team input cells on this tab: Team decision and Team comment for A1-A4. */
    const val TEAM_INPUT_CELLS = 8

    fun build(collection: CollectionData, review: ReviewData, runNotes: List<String>, options: List<String>): Sheet {
        val rows = SheetRows()
        rows.add(24.0, Cell.text(1, S_TITLE, "Client parent review: rules and assumptions"))
        rows.blank()
        aboutThisFile(rows)
        rows.blank()
        howToRead(rows, collection)
        rows.pair("Company evidence tab", "Active-contact counts, separate contact-name coverage, and all-path RHP/parent status evidence. " +
            "A known contact count does not certify platform names. Unknown evidence is not zero. Parent associations can include historical paths.")
        rows.pair("Matrix review tab", "One row per booking/path, with three independent WIP category checks. IF no recent trading and IF recent trading " +
            "are conditional scenarios, not actual confidence. There is no overall winner, parent choice or deactivation instruction. " +
            "Use the filters and source evidence IDs to inspect the relevant record. An empty matrix means its evidence was not supplied by that export.")
        rows.blank()
        glossary(rows, options)
        rows.blank()
        assumptions(rows)
        rows.blank()
        thisRun(rows, collection, review, runNotes, options)
        rows.blank()
        rows.section("Batches (source folders)")
        for (b in collection.batches)
            rows.pair(b.label, "folder ${b.folder}; status ${orText(b.extractionStatus.orEmpty(), WorkbookText.UNKNOWN)}; " +
                "${b.requestedIds.size} companies (${b.requestedIds.joinToString(", ")}); run-manifest SHA-256 " +
                b.manifestSha256)
        if (review.globalIssues.isNotEmpty()) {
            rows.blank()
            rows.section("Issues not tied to one company")
            val grouped = linkedMapOf<String, MutableSet<String>>()
            for (issue in review.globalIssues)
                grouped.getOrPut("${issue[1]} ${plainRule(issue[2])}: ${issue[3]}") { linkedSetOf() } += issue[0]
            grouped.forEach { (text, batches) -> rows.pair(batches.joinToString(", "), text) }
        }
        rows.blank()
        columnGuide(rows, "Columns of 'Company review'", WorkbookLayout.MAIN_HEADERS, mainGuide(options))
        rows.blank()
        columnGuide(rows, "Columns of 'Bookings'", WorkbookLayout.BOOKING_HEADERS, BOOKING_GUIDE)
        return Sheet.of(WorkbookLayout.RULES_SHEET, rows.list, WorkbookLayout.RULES_WIDTHS, 0, 0)
    }

    private fun aboutThisFile(rows: SheetRows) {
        rows.section("About this file")
        rows.pair("What it is", "Four tabs. 'Summary': what this file covers, how to review, progress and a chart. " +
            "'Company review': one 'Client' row per client in this file; click + at the left to open its possible " +
            "parents and the details rows. 'Bookings': every exported ICMS booking record of these clients, one row " +
            "each, with filters. 'Rules and assumptions': this tab. The clients are the selected sample in this file, " +
            "not the whole bank. Facts and notes are copied from the export.")
        rows.pair("Who decides", "The reviewer and the team. The file does not choose a parent and does not change " +
            "any data. The reviewer cells ('Reviewer decision', 'Reviewer comment', 'Reviewer name', 'Review date') " +
            "and the team cells below are intentionally empty.")
        rows.pair("Numbers this file computes", "Only counts of rows: the figures and the chart table on 'Summary' " +
            "(including the count of client rows with a recorded review status) and, in the 'Bookings (click the " +
            "number)' column, the number of booking records on 'Bookings'. Every other number is copied from the " +
            "export; nothing was recalculated.")
        rows.pair("Rule outcomes", "'Current parents (current rule)' and 'Parents (original selection check)' are " +
            "outcomes of the existing rules (below). Neither count is a verdict on which parent is correct. Where the " +
            "two differ, the gap shows where the picture changed and where to look.")
        rows.pair("Not shown on purpose", "The tool's automatic 'main parent' hint is not shown: its rule is " +
            "reopened (A3) and no automatic parent choice is approved. No application rule was changed for this file.")
    }

    private fun howToRead(rows: SheetRows, collection: CollectionData) {
        rows.section("How to read the numbers")
        rows.pair("Keys, not trades", "A key is one booking system plus one booking code. 'Matched keys' counts keys " +
            "with a cRDS path. 'Current booking records' counts Active ICMS booking records whose current path " +
            "resolves to a parent (not every Active booking); 'codes' counts their distinct booking codes.")
        rows.pair("Shares overlap", "'Key share' = this parent's keys ÷ the client's matched keys. One key can lead " +
            "to several parents, so a client's shares can add up to more than 100%. It is not a probability.")
        rows.pair("Client rows vs parent rows", "Client-row numbers are the export's totals for the client. " +
            "Parent-row numbers are what was observed for that parent; if evidence is incomplete they can be too low.")
        rows.pair("Blank is not zero", "On a client row, a blank number or an 'unknown' total means a required read " +
            "failed or was cut short, or the client could not be identified in ICMS (not found, or more than one ICMS " +
            "record has its ID); 0 is a known zero. On a parent row, numbers are observed values: if the row " +
            "says evidence is incomplete, a 0 does not prove absence.")
        rows.pair("Bookings column", "Client row: the number of the client's booking records on the 'Bookings' tab " +
            "(all of them, with or without a selected parent). Parent row: the client's current booking records whose " +
            "current path leads to that parent; on the 'Bookings' tab each of them shows this parent as its selected " +
            "parent. A 0 has no link.")
        rows.pair("Links", "A number above 0 in 'Bookings (click the number)' is a link inside this file. It jumps to " +
            "the first matching row on the 'Bookings' tab through a named lookup on the two jump-key columns at the " +
            "right end of that tab, so it still finds the first match after the tab is sorted. It does not filter the " +
            "tab. Clear any filters on 'Bookings' before jumping: a row hidden by a filter cannot be shown. To see all " +
            "of a client's or a parent's bookings, filter the jump-key column for that key. Do not edit the jump-key " +
            "columns.")
        rows.pair("Bookings tab", "Each row is one exported ICMS booking record. Rows are listed by client (in " +
            "'Company review' order), then by selected parent (in parent-row order), then the bookings with no " +
            "selected parent. 'Current-path result' says where the booking's current path leads; 'Selected parent ID' " +
            "names the parent selected by the current-path rule. If the source counts several eligible current " +
            "parents on the same booking key, only the selected one is named; every possible parent of the client is " +
            "listed on 'Company review'. The RHP is the cRDS party the booking's path starts from. The assigned-ID " +
            "check and the Salesforce reporting group are comparisons, not proof of identity or ownership. Platform " +
            "names are stored names, not proof of identity, ownership or use. A blank cell means the export recorded " +
            "no value. The Bookings tab has no reviewer cells.")
        rows.pair("Leading apostrophe", "A value that starts with ' followed by =, +, - or @ is shown exactly as " +
            "exported: the export adds that apostrophe as a spreadsheet-safety marker. It is not part of the bank's " +
            "data.")
        rows.pair("Original selection check", "The older database check that flagged companies as having more than " +
            "one ultimate parent (about 1,083 companies when last run)." +
            (if (collection.selection == "BASELINE_MULTIPLE_ULTIMATE_PARENTS") " The clients in this file come from " +
                "its results." else " This run used an explicit list of company IDs.") +
            " For each booking it picked a parent in two steps: first the parent with the most active account links, " +
            "then, among those, the most recent (inactive links allowed). It then counts the distinct parents. A tie " +
            "at the first step could be settled arbitrarily by the original check; the export flags such ties. The " +
            "export's own choice of the lowest parent ID only makes its output repeatable; it is not how the original " +
            "check settled ties.")
        rows.pair("Current rule", "Counts only parents reached by each Active booking's most recent eligible path " +
            "(active account link and active relationship). It can find fewer or more parents than the original " +
            "selection check. Neither is a final decision.")
        rows.pair("Order of parent rows", "Parent rows keep the export's order: most current booking records first, " +
            "then most active-link keys, then most matched keys. This order helps reading; it is not a ranking or a " +
            "verdict.")
        rows.pair("Grey rows", "A row on 'Company review' turns light grey once its 'Reviewer decision' is filled in. " +
            "Grey only shows that a status was recorded; it does not mean the row is correct or approved.")
    }

    private fun glossary(rows: SheetRows, options: List<String>) {
        rows.section("Glossary")
        rows.pair("Client", "A company in ICMS whose possible parents are reviewed here; one 'Client' row each on " +
            "'Company review'. Only the clients selected for this file are included.")
        rows.pair("Parent row (possible parent)", "A party that the bank's data links to the client through a cRDS " +
            "path. A possible parent, not a confirmed one; the parent rows are not a ranking.")
        rows.pair("Ultimate parent", "The top party of a cRDS hierarchy path; the party the rules count as a parent.")
        rows.pair("ICMS", "The bank's client and booking system that this export reads (clients and their booking " +
            "records).")
        rows.pair("cRDS", "The bank's client reference data system: parties, their hierarchies and their status.")
        rows.pair("Booking record", "One ICMS booking record of a client: one row on the 'Bookings' tab.")
        rows.pair("Booking key", "One booking system plus one booking code. Several booking records can share a key.")
        rows.pair("RHP", "Relationship-holding party: the cRDS party a booking's path starts from.")
        rows.pair("Current rule", "The rule that counts the parents reached by each Active booking's most recent " +
            "eligible path (see 'Current rule' above).")
        rows.pair("Original selection check", "The older database check that flagged companies with more than one " +
            "ultimate parent (see 'Original selection check' above).")
        rows.pair("Key share", "This parent's keys ÷ the client's matched keys, as a percentage. Shares overlap; it " +
            "is not a probability or a score.")
        rows.pair("Evidence complete / incomplete", "Complete: every read the row depends on finished. Incomplete: a " +
            "read failed or was cut short, or a total was left unknown; numbers are observed only, and a blank or a 0 " +
            "does not prove absence. The details row says which read.")
        rows.pair("Reviewer decision options", options.joinToString("; ") + ". Draft options until the team " +
            "confirms them; the team agrees what each one means. A blank cell means not reviewed yet.")
        rows.pair("Grey row", "A 'Company review' row with a recorded 'Reviewer decision'. It shows that a status was " +
            "recorded, not approval or correctness.")
        rows.pair("Jump key", "The literal keys in the last two 'Bookings' columns (for example C0001 for a client and " +
            "C0001-P0002 for its second parent row). The links on 'Company review' look them up.")
    }

    /** A1-A4 (accepted v3.1 wording, unchanged) with blank Team decision and Team comment cells. */
    private fun assumptions(rows: SheetRows) {
        rows.section("Assumptions still in use (inherited, NOT approved; team decision needed)")
        rows.add(null, Cell.text(1, S_HEADER, "Point"), Cell.text(2, S_HEADER, "Current behaviour (unchanged, not approved)"),
            Cell.text(3, S_HEADER, "Team decision"), Cell.text(4, S_HEADER, "Team comment"))
        rows.decision("A1 Missing status dates", "Path recency is the latest of five status dates, and each missing " +
            "date is replaced with the time the query ran. A missing date can therefore make a path appear more recent " +
            "than an older dated path. This is an inherited ranking rule, not proof of a recent company change; the " +
            "missing-date policy still needs business review.")
        rows.decision("A2 Parent-search system scope", "Parent-path searches use a fixed list of 27 cRDS systems, for " +
            "both the original selection check and the current rule. ICMS booking records outside that list are still " +
            "exported. 'No path found' can reflect this search scope; it does not prove the company has no parent. The " +
            "scope still needs business review.")
        rows.decision("A3 Main parent hint", "Reopened. Not shown in this file. 'Active-link keys' is shown as a " +
            "plain number only.")
        rows.decision("A4 Bank-name review clue", "A candidate whose cleaned name equals 'deutsche bank' gets the " +
            "warning 'Name looks like Deutsche Bank'. This does not verify legal identity and does not remove " +
            "candidates or bookings, change counts or order, or choose a different current parent.")
        rows.pair("Identity", "Names, Salesforce links and name similarities are clues, not proof of legal identity " +
            "or ownership.")
    }

    private fun thisRun(rows: SheetRows, c: CollectionData, review: ReviewData, runNotes: List<String>,
                        options: List<String>) {
        fun known(value: String?) = orText(value.orEmpty(), WorkbookText.UNKNOWN)
        rows.section("This run")
        rows.pair(if (c.inputKind == CollectionData.KIND_SINGLE_RUN) "Export run (single batch folder)" else "Collection run",
            known(c.runId))
        rows.pair("Started / finished (UTC)", known(c.startedAt) + " / " + known(c.finishedAt))
        rows.pair("Companies", "${c.cohort.size} requested; ${review.candidateCount} parent candidate rows; " +
            "${review.bookingCount} booking records (booking status ${known(c.bookingStatus)}); " +
            "${c.batches.size} batches")
        rows.pair("Overall read status", known(c.extractionStatus) + " (discovery " + known(c.discoveryStatus) + ")")
        rows.pair("Snapshot", if (c.crossSourceAtomicSnapshot) "One snapshot across sources."
            else "Sources and batches were read at slightly different moments; this is not one atomic snapshot.")
        rows.pair("Producer", "icms-export ${known(c.producerVersion)}, revision ${known(c.producerRevision)}" +
            (if (c.producerDirty == "true") " (uncommitted changes)" else "") + "; evidence schema ${c.evidenceSchema}")
        rows.pair("Reviewer decision options", options.joinToString(", ") +
            if (options == WorkbookLayout.DRAFT_DECISION_OPTIONS) " (the team's draft list; not yet confirmed)"
            else " (set for this file with --decision-options)")
        if (review.batchLimitations.isEmpty()) {
            rows.pair("Read limitations", "None: every source read completed.")
        } else {
            val byRead = sortedMapOf<String, MutableList<String>>()
            for (l in review.batchLimitations) byRead.getOrPut(l[1] + " " + l[2].lowercase()) { mutableListOf() } += l[0]
            for ((read, batches) in byRead) {
                val dataset = read.substringBefore(' ')
                val note = when (dataset) {
                    in WorkbookText.OPTIONAL_DATASETS -> " Optional activity source: does not make parent evidence " +
                        "incomplete."
                    in WorkbookText.PARENT_EVIDENCE_DATASETS -> " Affected clients show 'Incomplete' in the " +
                        "'Evidence' column and the reason in their details row."
                    else -> ""
                }
                rows.pair("Read limitation", "$read in ${batches.joinToString(", ")}.$note")
            }
        }
        for (note in runNotes) rows.pair("Run note", note)
    }

    private fun columnGuide(rows: SheetRows, title: String, headers: List<String>, guide: List<String>) {
        checkWorkbook(guide.size == headers.size) { "$title guide does not cover every column" }
        rows.section(title)
        headers.forEachIndexed { i, header -> rows.pair(header, guide[i]) }
    }

    private fun mainGuide(options: List<String>): List<String> = listOf(
        "ICMS client ID, repeated on every row so a row can always be traced to its client.",
        "Parent rows and parent details rows: the parent's cRDS party ID. Blank on client rows.",
        "Client row: ICMS client name. Parent row: the parent name recorded in the export.",
        "'Client'; 'Client details'; 'Current parent' (an Active booking's current path ends at this parent); 'Other " +
            "parent' (linked by a path but not current); 'Parent, current not observed' (evidence incomplete, so 'not " +
            "current' is not proven); 'Parent details'. Click + at the left to open a row's details.",
        "Client row: the export's total from the current rule. Blank means unknown, not 0: a read was incomplete, " +
            "or the client was not found in ICMS or more than one ICMS record has its ID.",
        "Client row: the export's total from the original selection check. Blank means unknown, not 0: a read was " +
            "incomplete, or the client was not found in ICMS or more than one ICMS record has its ID.",
        "Parent row: this parent's keys ÷ the client's matched keys. Shares overlap. The light blue bar shows the same " +
            "number; it is not a score.",
        "Client row: total keys with a cRDS path. Parent row: keys that lead to this parent.",
        "Parent row: keys that reach this parent through at least one active account link. A fact only, not a ranking.",
        "Client row: number of the client's booking records on 'Bookings'. Parent row: current booking records whose " +
            "current path leads to this parent. A number above 0 is a link to the first matching row on 'Bookings' " +
            "(clear filters there first; the link does not filter).",
        "'Complete', or 'Incomplete' when a read the row depends on failed or was cut short (the details row says " +
            "which).",
        "Client and parent rows: a one-line summary (current-rule result and data issues; warnings and related-parent " +
            "clues). Details rows: the full text. Not a decision.",
        "For the reviewer: choose a status from the list (" + options.joinToString(", ") + "; draft until the team " +
            "confirms them) or leave empty. Empty on purpose. A filled status turns the row grey (status recorded, not " +
            "approval).",
        "For the reviewer. Empty on purpose.",
        "For the reviewer. Empty on purpose.",
        "For the reviewer: a date, for example 2026-10-21. Empty on purpose.")

    private val BOOKING_GUIDE = listOf(
        "ICMS client ID of the booking record.",
        "ICMS client name.",
        "ICMS booking record ID.",
        "Booking code (with the booking system, one key).",
        "ICMS settlement system ID of the booking.",
        "ICMS settlement system name.",
        "cRDS system mapped to the booking system, or 'mapping not observed' / 'mapping unknown (reference lookup " +
            "...)' when the export recorded none.",
        "ICMS status of the booking record ('unknown' when blank).",
        "ICMS settlement method name.",
        "The parent selected by the current-path rule for this booking (blank when none was selected). Also shown " +
            "when the read was incomplete; the result column then says so.",
        "The parent name recorded in the export for that parent.",
        "How many eligible current parents the source counts on this booking key before one is selected.",
        "Where the booking's current path leads: a current parent selected, a path but none current, no cRDS path " +
            "(A2 scope), no cRDS system mapping, evidence unavailable, or not reviewed (no booking-review row; this " +
            "does not mean no parent).",
        "Relationship-holding party: the cRDS party the booking's path starts from.",
        "RHP name.",
        "RHP status in cRDS.",
        "Date of that RHP status.",
        "cRDS ID assigned to the booking in ICMS.",
        "Comparison of the assigned cRDS ID with the current RHP; a comparison, not proof of identity.",
        "Salesforce reporting group of the RHP ('not observed' when the check ran but no group was found). Grouping, " +
            "not ownership.",
        "Salesforce reporting group name.",
        "Result of the reporting group check.",
        "Number of settlement routings on the booking.",
        "Account types of those routings.",
        "Date of the last routing change.",
        "Names stored on platforms for the verified booking ID. Not proof of identity, ownership or use.",
        "Names stored on platforms for the booking key only. Not proof of identity, ownership or use.",
        "Names stored with any other link status, with its reason. Not proof of identity, ownership or use.",
        "Status of the reference lookup for this booking.",
        "Data quality status of this booking record.",
        "Literal key of the client (C + client number in this file). Used by the client links; do not edit.",
        "Literal key of the client and parent row (the client key, then -P + parent row number). Blank for bookings " +
            "with no selected parent. Used by the parent links; do not edit.")
}
