package com.db.clientinsights.export.adapters.fixture

import com.db.clientinsights.export.adapters.serialization.EvidenceJson
import com.db.clientinsights.export.adapters.serialization.sha256
import com.db.clientinsights.export.domain.*
import com.db.clientinsights.export.ports.IcmsReferenceSource
import com.db.clientinsights.export.ports.IcmsSource
import com.db.clientinsights.export.ports.ReviewCohortSource
import com.db.clientinsights.export.ports.ReviewDataSource
import java.nio.file.Files
import java.nio.file.Path
import java.time.Clock
import java.math.BigInteger
import java.util.UUID
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

@Serializable
data class FixtureData(
    val schemaVersion: String = EVIDENCE_SCHEMA_VERSION,
    val entities: List<IcmsEntity>,
    val bookingRecords: List<BookingRecord>,
    val bookingSystems: List<BookingSystem>,
    val settlementMethods: List<SettlementMethod>,
    val reviewCohortIds: List<IcmsEntityId> = emptyList(),
    val review: ReviewFacts? = null,
)

/** Offline source for tests and repeatable demonstrations. All exported provenance says fixture. */
class FixtureSources(private val data: FixtureData, private val clock: Clock = Clock.systemUTC()) : IcmsSource, IcmsReferenceSource, ReviewCohortSource {
    init { require(data.schemaVersion in READABLE_VERSIONS) { "Unsupported fixture schema version." } }
    private val fixtureHash = sha256(EvidenceJson.format.encodeToString(data).toByteArray(Charsets.UTF_8))
    val reviewSource: ReviewDataSource? = data.review?.let { review -> ReviewDataSource { request, facts ->
        val ids = request.entityIds.toSet()
        val keys = facts.bookingRecords.map { row ->
            val system = data.bookingSystems.singleOrNull { it.id == row.data.settlementSystemId }?.crdsSystemId?.value
            crdsBookingKey(system, row.data.bookingCode)
        }.filterNotNull().toSet()
        val bookingIds = facts.bookingRecords.map { it.data.id }.toSet()
        val scoped = review.copy(paths = review.paths.filter { crdsBookingKey(it.data.systemId, it.data.bookingCode) in keys },
            allStatusPaths = review.allStatusPaths.filter { crdsBookingKey(it.data.systemId, it.data.bookingCode) in keys },
            usageEvidence = review.usageEvidence.copy(
                contacts = review.usageEvidence.contacts.filter { it.data.entityId in ids },
                confirmations = review.usageEvidence.confirmations.filter { it.data.entityId in ids && it.data.bookingRecordId in bookingIds },
                trading = review.usageEvidence.trading.filter { it.data.entityId in ids && it.data.bookingRecordId in bookingIds }),
            currentBookings = review.currentBookings.filter { it.data.entityId in ids },
            routings = review.routings.filter { it.data.entityId in ids }, sharedKeys = review.sharedKeys.filter { it.data.entityId in ids },
            assignments = review.assignments.filter { it.data.entityId in ids }, routingLineage = review.routingLineage.filter { it.data.entityId in ids },
            platformNames = review.platformNames.filter { it.data.entityId in ids && it.data.bookingRecordId in bookingIds }).let { scoped ->
            val nativeIds = scoped.platformNames.mapNotNull { it.data.nativeBookingId }.toSet()
            scoped.copy(platformNativeBookings = scoped.platformNativeBookings.filter { it.data.recordId in nativeIds })
        }
        val queryIds = (review.queries + review.usageEvidence.queries).associate { it.queryRunId to UUID.randomUUID().toString() }
        fun <T> retag(rows: List<SourceRow<T>>): List<SourceRow<T>> = rows.map {
            it.copy(origin = it.origin.copy(queryRunId = checkNotNull(queryIds[it.origin.queryRunId])))
        }
        fun <T> retagUsage(rows: List<SourceRow<T>>): List<SourceRow<T>> = retag(rows).map {
            it.copy(origin = it.origin.copy(sourceId = "synthetic-fixture"))
        }
        val usageDatasets = setOf("ACTIVE_CONTACT_PEOPLE", "CONFIRMATION_ROUTINGS", "BOOKING_TRADING_24_MONTHS")
        fun retagUsageQuery(query: QueryRun): QueryRun {
            val origins = scoped.usageEvidence.contacts.map { it.origin } +
                scoped.usageEvidence.confirmations.map { it.origin } + scoped.usageEvidence.trading.map { it.origin }
            return query.copy(queryRunId = checkNotNull(queryIds[query.queryRunId]), querySha256 = fixtureHash,
                sourceId = "synthetic-fixture", adapter = "fixture",
                exportedRowCount = origins.count { it.queryRunId == query.queryRunId },
                requestedKeys = query.requestedKeys.filter { key -> ids.any { it.value == key } })
        }
        val sizes = mapOf("PARENT_PATHS" to scoped.paths.size, "CURRENT_BOOKING_PATHS" to scoped.currentBookings.size,
            "ALL_BOOKING_STATUS_PATHS" to scoped.allStatusPaths.size,
            "ACTIVE_CONTACT_PEOPLE" to scoped.usageEvidence.contacts.size,
            "CONFIRMATION_ROUTINGS" to scoped.usageEvidence.confirmations.size,
            "BOOKING_TRADING_24_MONTHS" to scoped.usageEvidence.trading.size,
            "CRDS_PARTIES" to scoped.parties.size, "SALESFORCE_HIERARCHY" to scoped.salesforce.size,
            "SETTLEMENT_ROUTINGS" to scoped.routings.size, "SHARED_BOOKING_KEYS" to scoped.sharedKeys.size,
            "ASSIGNMENT_LINEAGE" to scoped.assignments.size, "ROUTING_LINEAGE" to scoped.routingLineage.size,
            "BOOKING_PLATFORM_NAMES" to scoped.platformNames.size, "PLATFORM_NATIVE_BOOKINGS" to scoped.platformNativeBookings.size) +
            listOf("BANK_LEI_IDENTIFIERS", "BANK_IDENTITY_CACHE", "BANK_PARTY_ADDRESS").associateWith { kind -> scoped.identities.count { it.data.kind == kind } }
        val entityDatasets = setOf("ACTIVE_CONTACT_PEOPLE", "CONFIRMATION_ROUTINGS", "BOOKING_TRADING_24_MONTHS", "ALL_BOOKING_STATUS_PATHS", "PARENT_PATHS", "CURRENT_BOOKING_PATHS", "SETTLEMENT_ROUTINGS", "SHARED_BOOKING_KEYS", "ASSIGNMENT_LINEAGE", "ROUTING_LINEAGE", "BOOKING_PLATFORM_NAMES")
        scoped.copy(paths = retag(scoped.paths), currentBookings = retag(scoped.currentBookings), parties = retag(scoped.parties),
            allStatusPaths = retag(scoped.allStatusPaths),
            usageEvidence = scoped.usageEvidence.copy(contacts = retagUsage(scoped.usageEvidence.contacts),
                confirmations = retagUsage(scoped.usageEvidence.confirmations), trading = retagUsage(scoped.usageEvidence.trading),
                queries = scoped.usageEvidence.queries.map(::retagUsageQuery)),
            salesforce = retag(scoped.salesforce), routings = retag(scoped.routings), sharedKeys = retag(scoped.sharedKeys),
            identities = retag(scoped.identities), assignments = retag(scoped.assignments), routingLineage = retag(scoped.routingLineage),
            platformNames = retag(scoped.platformNames), platformNativeBookings = retag(scoped.platformNativeBookings),
            queries = scoped.queries.map { if (it.dataset in usageDatasets) retagUsageQuery(it) else it.copy(queryRunId = checkNotNull(queryIds[it.queryRunId]), querySha256 = fixtureHash,
                sourceId = "synthetic-fixture", adapter = "fixture", exportedRowCount = sizes[it.dataset] ?: it.exportedRowCount,
                requestedKeys = when (it.dataset) {
                    in entityDatasets -> ids.map { id -> id.value }
                    "PLATFORM_NATIVE_BOOKINGS" -> scoped.platformNames.mapNotNull { row -> row.data.nativeBookingId }.distinct()
                    else -> it.requestedKeys
                }) })
    } }

    override fun discoverFlaggedEntities(afterId: IcmsEntityId?, pageSize: Int): EntityPage {
        require(pageSize in 1..500) { "Discovery page size must be between 1 and 500." }
        val page = data.reviewCohortIds.asSequence().distinct()
            .filter { afterId == null || BigInteger(it.value) > BigInteger(afterId.value) }
            .sortedBy { BigInteger(it.value) }.take(pageSize + 1).toList()
        val ids = page.take(pageSize)
        val time = clock.instant().toString()
        val query = QueryRun(UUID.randomUUID().toString(), "synthetic-fixture", "fixture", "BASELINE_MULTIPLE_ULTIMATE_PARENTS",
            "review-cohort", fixtureHash, emptyList(), QueryLimits(pageSize = pageSize + 1), time, time,
            FetchStatus.COMPLETE, ids.size, 1)
        return EntityPage(afterId, ids, if (page.size > pageSize) ids.last() else null, query)
    }

    override fun fetchEntities(ids: List<IcmsEntityId>) = result("entities", "PRD_EXPORT_LEGAL_ENTITY",
        ids.map { it.value }, data.entities.filter { it.id in ids }) { it.id.value }

    override fun fetchBookingRecords(ids: List<IcmsEntityId>, status: String?) = result(
        "booking-records", "PRD_EXPORT_BOOKING_CODE", ids.map { it.value },
        data.bookingRecords.filter { it.entityId in ids && (status == null || it.status == status) }, BookingRecord::id)

    override fun fetchBookingSystems(ids: List<IcmsSettlementSystemId>) = result("booking-systems", "T_CRDS_BOOKING_SYSTEM",
        ids.map { it.value }, data.bookingSystems.filter { it.id in ids }) { it.id.value }

    override fun fetchSettlementMethods(ids: List<String>) = result("settlement-methods", "T_SETTLEMENT_METHOD",
        ids, data.settlementMethods.filter { it.id in ids }, SettlementMethod::id)

    private fun <T> result(query: String, dataset: String, keys: List<String>, records: List<T>, id: (T) -> String): FetchResult<T> {
        val runId = UUID.randomUUID().toString()
        val time = clock.instant().toString()
        val source = "synthetic-fixture"
        return FetchResult(records.map { record ->
            val recordId = id(record)
            SourceRow(record, RecordOrigin("$source:$dataset:$recordId", source, dataset, recordId, runId))
        }, listOf(QueryRun(runId, source, "fixture", dataset, query, fixtureHash, keys,
            QueryLimits(), time, time, FetchStatus.COMPLETE, records.size, if (keys.isEmpty()) 0 else 1)))
    }

    companion object {
        /** Fixture schema versions this reader accepts. 1.3.0 changed exported EntityReview values only. */
        private val READABLE_VERSIONS = setOf("1.0.0", "1.1.0", "1.2.0", "1.3.0", EVIDENCE_SCHEMA_VERSION)

        fun demo(): FixtureSources = decode(checkNotNull(FixtureSources::class.java.getResourceAsStream("/fixtures/demo.json"))
            .bufferedReader(Charsets.UTF_8).use { it.readText() })
        fun load(path: Path): FixtureSources = decode(Files.readString(path))

        private fun decode(text: String): FixtureSources {
            val version = EvidenceJson.format.parseToJsonElement(text).jsonObject["schemaVersion"]?.jsonPrimitive?.content
            require(version in READABLE_VERSIONS) { "Unsupported fixture schema version." }
            return FixtureSources(EvidenceJson.format.decodeFromString<FixtureData>(text))
        }
    }
}
