package com.db.clientinsights.export.application

import com.db.clientinsights.export.domain.*
import com.db.clientinsights.export.ports.IcmsReferenceSource
import com.db.clientinsights.export.ports.IcmsSource
import com.db.clientinsights.export.ports.ReviewDataSource
import com.db.clientinsights.export.ports.UsageEvidenceSource
import com.db.clientinsights.export.rules.ExtractionChecks
import com.db.clientinsights.export.rules.ReviewRules
import java.time.Clock
import java.util.UUID

/** Source orchestration only. This contract can later supply facts to an AI adapter or tool. */
class ExportService(
    private val icms: IcmsSource,
    private val references: IcmsReferenceSource,
    private val producer: Producer,
    private val checks: ExtractionChecks = ExtractionChecks(),
    private val clock: Clock = Clock.systemUTC(),
    private val runId: () -> String = { UUID.randomUUID().toString() },
    private val reviewSource: ReviewDataSource? = null,
    private val usageEvidenceSource: UsageEvidenceSource? = null,
) {
    fun extract(request: ExportRequest): EvidenceBundle {
        val started = clock.instant().toString()
        val requestedIds = request.entityIds.toSet()
        val entities = icms.fetchEntities(request.entityIds)
        val bookings = icms.fetchBookingRecords(request.entityIds, request.bookingStatus)
        requireSourceContract(entities.rows.all { it.data.id in requestedIds } &&
            bookings.rows.all { it.data.entityId in requestedIds }) {
            "A source returned rows outside the requested cohort."
        }
        requireSourceContract(
            bookings.rows.all { request.bookingStatus == null || it.data.status == request.bookingStatus },
        ) { "A source returned booking rows outside the requested status scope." }
        val systemIds = bookings.rows.mapNotNull { it.data.settlementSystemId }.toSet()
        val methodIds = bookings.rows.mapNotNull { it.data.settlementMethodId }.toSet()
        val systems = references.fetchBookingSystems(systemIds.toList())
        val methods = references.fetchSettlementMethods(methodIds.toList())
        requireSourceContract(
            systems.rows.all { it.data.id in systemIds } && methods.rows.all { it.data.id in methodIds },
        ) { "A reference source returned rows outside the requested keys." }
        val facts = ExtractedFacts(entities.rows, bookings.rows, systems.rows, methods.rows)
        val queries = entities.queries + bookings.queries + systems.queries + methods.queries
        val checked = checks.evaluate(request, facts, queries)
        val extractedReview = reviewSource?.fetch(request, facts)
        val usageFacts = usageEvidenceSource?.fetch(request, facts) ?: extractedReview?.usageEvidence
        if (usageFacts != null) validateUsageEvidence(requestedIds, facts, usageFacts)
        val reviewFacts = if (extractedReview != null || usageFacts != null) {
            val base = extractedReview ?: ReviewFacts()
            val mergedQueries = base.queries + usageFacts?.queries.orEmpty()
            requireSourceContract(mergedQueries.groupBy { it.queryRunId }.values.all { it.distinct().size == 1 }) {
                "Review sources returned conflicting query provenance."
            }
            base.copy(usageEvidence = usageFacts ?: UsageEvidenceFacts(),
                queries = mergedQueries.distinctBy { it.queryRunId })
        } else null
        val review = reviewFacts?.let { ReviewRules(clock = clock).evaluate(request, checked, it) }
        val allQueries = queries + reviewFacts?.queries.orEmpty()
        requireSourceContract(allQueries.groupBy { it.queryRunId }.values.all { it.distinct().size == 1 }) {
            "Export sources returned conflicting query provenance."
        }
        val entityReviews = review?.entities?.associateBy { it.entityId }.orEmpty()
        val bookingReviews = review?.bookings?.associateBy { it.bookingRecordId }.orEmpty()
        val summaries = checked.entities.map { entity -> entityReviews[entity.entityId]?.let { result ->
            entity.copy(parentReviewStatus = when (result.currentRuleStatus) {
                "UNKNOWN" -> CheckStatus.ERROR
                "NOT_APPLICABLE" -> CheckStatus.NOT_EVALUATED
                "ONE_PARENT" -> CheckStatus.PASS
                else -> CheckStatus.REVIEW
            })
        } ?: entity }
        val resolved = checked.bookings.map { booking -> bookingReviews[booking.booking.data.id]?.let { result ->
            booking.copy(crdsPathStatus = when (result.resolution) {
                "CURRENT_PATH" -> CheckStatus.PASS
                "UNAVAILABLE" -> CheckStatus.ERROR
                else -> CheckStatus.REVIEW
            })
        } ?: booking }
        return EvidenceBundle(runId = runId(), startedAt = started, finishedAt = clock.instant().toString(),
            producer = producer, request = request,
            extractionStatus = combineFetchStatuses(allQueries.filter { it.requestedKeys.isNotEmpty() || it.queryId.startsWith("activity-") }.map { it.status }),
            facts = facts, entities = summaries, bookings = resolved, issues = checked.issues + review?.findings.orEmpty(),
            queries = allQueries, review = review)
    }

    private fun validateUsageEvidence(ids: Set<IcmsEntityId>, facts: ExtractedFacts, usage: UsageEvidenceFacts) {
        val bookings = facts.bookingRecords.map { it.data.entityId to it.data.id }.toSet()
        requireSourceContract(usage.contacts.all { it.data.entityId in ids } &&
            usage.confirmations.all { (it.data.entityId to it.data.bookingRecordId) in bookings } &&
            usage.trading.all { (it.data.entityId to it.data.bookingRecordId) in bookings }) {
            "A usage source returned evidence outside the requested entity or booking scope."
        }
        requireSourceContract(usage.queries.groupBy { it.queryRunId }.values.all { it.distinct().size == 1 }) {
            "A usage source returned conflicting query provenance."
        }
        val runs = usage.queries.associateBy { it.queryRunId }
        fun <T> valid(rows: List<SourceRow<T>>, dataset: String, entity: (T) -> IcmsEntityId) = rows.all { row ->
            val query = runs[row.origin.queryRunId]
            query != null && query.dataset == dataset && row.origin.dataset == dataset &&
                query.sourceId == row.origin.sourceId && entity(row.data).value in query.requestedKeys
        }
        requireSourceContract(valid(usage.contacts, "ACTIVE_CONTACT_PEOPLE", ContactPersonFact::entityId) &&
            valid(usage.confirmations, "CONFIRMATION_ROUTINGS", ConfirmationRoutingFact::entityId) &&
            valid(usage.trading, "BOOKING_TRADING_24_MONTHS", BookingTradingFact::entityId)) {
            "A usage source returned evidence without matching query provenance."
        }
    }
}
