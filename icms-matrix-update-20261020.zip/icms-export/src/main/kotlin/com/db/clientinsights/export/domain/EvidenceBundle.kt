package com.db.clientinsights.export.domain

import kotlinx.serialization.Serializable

/** 1.4.0 adds all-status paths and independent WIP Confluence assessments; current-parent rules remain unchanged. */
const val EVIDENCE_SCHEMA_VERSION = "1.4.0"
const val EXTRACTION_RULE_VERSION = "1.0.0"

@Serializable
data class ExportRequest(val entityIds: List<IcmsEntityId>, val bookingStatus: String? = "Active") {
    init {
        require(entityIds.isNotEmpty()) { "At least one entity ID is required." }
        require(entityIds.distinct().size == entityIds.size) { "Entity IDs must be unique." }
    }
}

@Serializable
enum class EntityPresence { FOUND, NOT_FOUND, UNKNOWN, AMBIGUOUS }

@Serializable
enum class CheckStatus { PASS, REVIEW, NOT_EVALUATED, ERROR }

@Serializable
enum class IssueSeverity { REVIEW, ERROR }

@Serializable
data class DataIssue(
    val issueId: String,
    val ruleId: String,
    val ruleVersion: String = EXTRACTION_RULE_VERSION,
    val severity: IssueSeverity,
    val entityId: IcmsEntityId?,
    val bookingRecordId: String? = null,
    val evidenceIds: List<String> = emptyList(),
    val queryRunIds: List<String> = emptyList(),
    val message: String,
)

@Serializable
data class EntitySummary(
    val entityId: IcmsEntityId,
    val presence: EntityPresence,
    val name: String?,
    val sourceStatus: String?,
    val entityReadStatus: FetchStatus,
    val bookingReadStatus: FetchStatus,
    val extractionStatus: FetchStatus,
    val exportedBookingCount: Int,
    val dataQualityStatus: CheckStatus,
    val issueIds: List<String>,
    val queryRunIds: List<String>,
    val parentReviewStatus: CheckStatus = CheckStatus.NOT_EVALUATED,
    val activityStatus: CheckStatus = CheckStatus.NOT_EVALUATED,
)

@Serializable
data class ResolvedBooking(
    val booking: SourceRow<BookingRecord>,
    val bookingSystem: SourceRow<BookingSystem>?,
    val settlementMethod: SourceRow<SettlementMethod>?,
    val referenceReadStatus: FetchStatus,
    val dataQualityStatus: CheckStatus,
    val issueIds: List<String>,
    val crdsPathStatus: CheckStatus = CheckStatus.NOT_EVALUATED,
)

@Serializable
data class Producer(val applicationVersion: String, val gitRevision: String, val workingTreeDirty: Boolean)

@Serializable
data class EvidenceBundle(
    val schemaVersion: String = EVIDENCE_SCHEMA_VERSION,
    val runId: String,
    val startedAt: String,
    val finishedAt: String,
    val producer: Producer,
    val request: ExportRequest,
    val extractionStatus: FetchStatus,
    val extractionRuleVersion: String = EXTRACTION_RULE_VERSION,
    val crossSourceAtomicSnapshot: Boolean = false,
    val facts: ExtractedFacts,
    val entities: List<EntitySummary>,
    val bookings: List<ResolvedBooking>,
    val issues: List<DataIssue>,
    val queries: List<QueryRun>,
    val review: DeterministicReview? = null,
)

@Serializable
data class ArtifactDigest(val filename: String, val sha256: String, val bytes: Long, val dataRows: Int?)

@Serializable
data class RunManifest(
    val schemaVersion: String = EVIDENCE_SCHEMA_VERSION,
    val runId: String,
    val startedAt: String,
    val finishedAt: String,
    val producer: Producer,
    val request: ExportRequest,
    val extractionStatus: FetchStatus,
    val extractionRuleVersion: String = EXTRACTION_RULE_VERSION,
    val requestedEntityCount: Int,
    val foundEntityCount: Int,
    val exportedBookingCount: Int,
    val issueCount: Int,
    val queryVersions: Map<String, String>,
    val artifacts: List<ArtifactDigest>,
)
