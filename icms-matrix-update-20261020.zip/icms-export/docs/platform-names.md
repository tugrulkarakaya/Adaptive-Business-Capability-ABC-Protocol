# Platform name evidence

This increment adds account/platform configuration to CSV and evidence schema 1.2.0. It does not change parent, Salesforce or unused-confidence decisions, call AI, infer trading, or update bank data.

## Sources and links

`booking-platform-names.sql` selects the requested entity/status scope and follows the exact entity ID, booking code and ICMS settlement system to `PRD_EXPORT_SETTLEMENT_ROUTING`. It then joins `ACCOUNT_ID` to `PRD_EXPORT_ACCOUNT.ID`, and `T_ACCOUNT_CODE_ON_EP.ACCOUNT_ID` to that account. `T_EPLATFORM.ID = EP_ID` provides the platform label. Customer code, `NAME`, `BBG_FIRM_CODE`, `BBG_FIRM_NAME`, account owner and creation/update timestamps remain separate raw fields. Empty names are retained without being counted as named coverage. No fuzzy name join or formatting guess is used.

The `platforms` profile owns this query and requires these copies in one connection. `platform-native-bookings.sql` separately reads `T_BOOKING_CODE` using the `native-bookings` profile. Both profiles inherit `icms` unless independently configured. All SQL values are bound, queries are read-only, and limits/partial results retain normal query provenance.

The routing's `BOOKING_CODE_ID` is an original booking ID. It is not the ID in `PRD_EXPORT_BOOKING_CODE`. Never equate the two numbers. Verification uses the original reference and checks its entity, booking code and settlement system against the exported row. Native status is shown without treating a stored configuration as proof of current usage.

## Link labels

- `VERIFIED_BOOKING_ID`: the scoped exported key, account owner, original booking reference and original entity/code/system all agree; the native lookup is complete and unambiguous.
- `BOOKING_KEY_ONLY`: the scoped exported key and account owner agree, but native validation is unavailable, partial, missing or ambiguous. `link_reason` and `native_read_status` explain which case applies.
- `NATIVE_BOOKING_KEY_MISMATCH`: the original reference exists but points to another entity/code/system. This is a conflict, not a verified or key-only link.
- `ACCOUNT_OWNER_MISMATCH` / `ACCOUNT_OWNER_UNKNOWN`: do not attribute the account to the target company as a valid link.
- `EXPORTED_BOOKING_KEY_MISMATCH` / `EXPORTED_BOOKING_UNAVAILABLE`: raw observations do not agree with the extracted core booking scope.

An unavailable or truncated platform source never becomes `NO_NAME`. Coverage counts are observed lower bounds when source status is incomplete. Per-entity booking counts are disjoint: a booking with a verified named path is counted as verified; otherwise a key-only path takes precedence; otherwise a named conflict is counted as conflicted. All individual paths and conflicting observations remain in the detail CSV and JSON.

## Outputs and future consumers

`booking-platform-names.csv` includes every extracted platform/routing observation with its confidence, reason, native lookup status and references. `platform-native-bookings.csv` contains raw native booking observations. `entity-platform-coverage.csv` summarizes all requested entities with source status, coverage status and counts. The other CSV layouts are unchanged.

`evidence.json` stores raw facts in `review.facts.platformNames` and `review.facts.platformNativeBookings`. Assessments and coverage are under `review.platformNames`. A later AI consumer must retain the link confidence, source status, dates and limitation. A platform customer name or firm name is neither an LEI binding nor a parent relationship. The same account may retain an old name on one platform and a newer name on another.

Full review now writes 32 CSVs, evidence JSON and a manifest (34 files). The manifest hashes all 33 other artifacts and is written last. Ten added status/optional-usage views are described in [Confluence coverage](confluence-theme-b6.md); they keep booking/account platform observations separate from verified active-person names. Older 1.0.0/1.1.0 fixtures remain readable with empty platform fields.
