# Review workbook

The review workbook is the Excel file the team uses to review the companies in an export. It is built by this
application from the export's own CSV files. It adds no business rule and changes no bank record.

## What it is

`ICMS-company-review.xlsx` has six tabs:

| Tab | What it shows |
|---|---|
| Summary | How to review in 3 steps, a progress count, the numbers of this file and a chart of clients by number of current parents. |
| Company review | One row per client and, under it (click **+**), one row per possible parent, each with a details row. Reviewers fill in the four reviewer columns. |
| Bookings | One row per exported booking record, with every booking fact the export holds. It has a filter. |
| Rules and assumptions | How to read the numbers, a glossary, the assumptions A1 to A4 with 8 blank cells for the team, and the run details. |
| Company evidence | Confirmed active-contact count, independent name coverage, all-path RHP/parent statuses and source gaps. |
| Matrix review | One booking/path per row with three separate WIP category results, conditional scenarios, missing inputs and provenance. |

What the workbook never does:

- It never chooses a parent, ranks parents or scores them. The word `MAIN_PARENT` appears nowhere.
- It never fills in a reviewer cell. Decision, comment, name and date start blank on every client and parent row, and
  the 8 team cells on the Rules tab start blank. Nothing is filled in automatically (no "today", no name).
- It never turns "unknown" into 0. A total the export left blank stays blank and is counted as "Unknown" on Summary.
- It never shortens text, drops a booking or caps a count. If something does not fit Excel, the build stops instead.
- It never links outside the file: the booking-count links jump to the Bookings tab inside the same file and still
  find the right rows after the Bookings tab is sorted. Clear any filter on Bookings before jumping; a link cannot
  clear a filter.

A grey row on Company review only means a reviewer status was recorded. It does not mean the row is correct or
approved. The reviewer statuses are a draft list until the team confirms them.

The numbers describe only the companies in this export (a selected sample), not the whole bank.

The existing four tabs retain their columns. **Company evidence** adds active-person counts, separate CUSTOMER-name coverage, all-path RHP/parent statuses and source gaps. **Matrix review** adds three independent WIP category results per booking/path, conditional levels, missing inputs and evidence/query references. Conditional IF levels are scenarios, not actual confidence; there is no combined score or automatic action. Both new tabs have filters and frozen headers. Source CSVs are integrity checked before use; 1.3.0 exports without these fields remain readable and display unavailable supplementary evidence.

## How it is made

**Normal export (main path).** Every export run writes the workbook into its collection folder:

```text
<output>/<collection-run-id>/
    batches/...                     the CSVs and evidence of each batch
    ICMS-company-review.xlsx        the review workbook
    workbook-receipt.json           what the workbook was built from (see Receipt)
    collection-manifest.json        published last
```

Order of work: all batches are written; the collection manifest is written under a temporary name
(`.collection-manifest.pending.json`); the workbook is built from it, re-read and checked; only then is the
manifest renamed to `collection-manifest.json`. So a published manifest always has its workbook beside it.

The last console line is `Review workbook: <path>`.

The workbook is built for complete and for incomplete (exit 2) exports alike; incomplete evidence is shown as such.
It is skipped, with a plain console line, in two cases that keep their usual exit code:

- `No review workbook: the export selected no companies.` (for example a discovery that found nothing);
- `No review workbook: this export has no review data.` (a source without review facts, such as a fixture without a
  `review` section, writes no review CSVs).

**Again from a saved export (no database).** The `workbook` command rebuilds the workbook from any saved export:

```text
icms-export workbook --input <collection folder | collection-manifest.json | single-run batch folder | run-manifest.json>
                     --output <new folder | new file.xlsx>
                     [--expected-count N] [--expected-ids FILE] [--run-note TEXT]... [--decision-options "a|b|c"]
```

Windows example:

```powershell
.\build\install\icms-export\bin\icms-export.bat workbook `
    --input C:\review-runs\3f2c9a1e-0000-0000-0000-000000000000 `
    --output C:\review-workbooks\review-2026-10-21 `
    --expected-count 50 --run-note "Second look after the October export"
```

| Option | Meaning |
|---|---|
| `--input` | A collection folder or its `collection-manifest.json`, or one batch folder or its `run-manifest.json` (a single run). An unpublished collection (only the temporary manifest) is never read. |
| `--output` | A new folder: it gets `ICMS-company-review.xlsx` and `workbook-receipt.json`. Or a new `.xlsx` file: its receipt is written beside it as `<name>.receipt.json`. The folder that contains it must exist. Nothing existing is replaced, and nothing may be written inside the input export (checked after resolving links, so an alias folder cannot hide it). |
| `--expected-count`, `--expected-ids` | Stop unless the export holds exactly this many companies / exactly these company IDs (IDs separated by spaces, commas or new lines; `#` starts a comment). |
| `--run-note` | A line shown under "This run" on the Rules tab. Repeat it for several lines. Only the number of notes goes into the receipt. |
| `--decision-options` | 2 to 6 reviewer statuses separated by `|`, each 1 to 40 characters, no comma or double quote, not starting with `=`, `+`, `-` or `@`. Default: the team's draft list (`Correct as is`, `Needs correction`, `Need more information`). The export accepts the same option. |

The workbook is written to a temporary name next to its destination, re-read and checked, and only then renamed into
place: a new output folder appears in one step; for a `.xlsx` output the workbook appears first and its receipt
second, and the workbook is removed again if the receipt cannot be written. Temporary files are always removed.
An interruption inside the application is checked before work starts and before each of these moves: the run stops
with exit 130, publishes nothing (a workbook already moved is removed again, so there is never a workbook without its
receipt) and removes only the files it created. If the process itself is stopped from outside (for example Ctrl+C or
closing the window), Java ends at once without this clean-up: nothing new is claimed (a normal export publishes
collection-manifest.json last, so that folder has no manifest), but a hidden temporary file or folder named
`.<name>.<random>.tmp` may remain next to the output; delete it.

## Checks before anything is published

- Every CSV the workbook reads must match its run manifest exactly: size, SHA-256 and row count. Every batch manifest
  must match the SHA-256 in the collection manifest. Batch folders must be plain folders inside the collection (no
  `..`, no link to a folder elsewhere). A manifest given as `--input` must really be that file in that folder: a
  link named `collection-manifest.json` that points to a file with another name, or to a manifest in another folder,
  is refused (exit 3).
- Each booking's selected parent must be one of its client's possible parents, and each parent row's count of current
  booking records must equal the bookings that select it.
- The written file is opened again and compared with what was meant to be written: every cell, the outline, the
  single formula, the links (also after a simulated re-sort of Bookings), the drop-down lists, the colour rules, the
  filter, the chart, and that the reviewer cells are blank.
- Messages name files, columns, sheets and cells only, never client data.

## Receipt

`workbook-receipt.json` records, in this order: `workbookFormat` (`icms-review-workbook/5`), `producer` (application
version, git revision, uncommitted-changes flag), `inputKind` (`export-run`, `collection` or `single-run`), `runId`,
`manifestFile` and `manifestSha256` (the primary manifest: `collection-manifest.json`, or the run's
`run-manifest.json` for a single run), evidence schema, extraction status, booking status, the exporting program
(`exportProducer`), the number of batches and consumed files, the SHA-256 of every file read
(`consumedFileSha256`), the options (expected count, number of expected IDs, decision options, number of run notes),
every count of the re-read check (`verification`), and the workbook's file name, size in bytes and SHA-256. It
contains hashes, counts and file names, never client values.

The same export and options always give a byte-identical workbook.

## Exit codes

| Code | Export run | `workbook` command |
|---|---|---|
| `0` | Complete extraction; workbook built and verified. | Workbook and receipt written and verified. |
| `2` | Incomplete evidence; manifest and workbook published. | (not used) |
| `3` | Batches kept; the workbook failed, so the collection manifest was **not** published. | A workbook check failed (input integrity, reconciliation, expected cohort, Excel limits, re-read check). Nothing written. |
| `64` | Invalid arguments. | Invalid arguments, or an output name that exists or lies inside the input. |
| `1` | File error. | File error (for example a missing input). |
| `70` | Unexpected failure (only its type is shown). | Unexpected failure (only its type is shown). |
| `130` | Interrupted; no manifest published. | Interrupted; nothing published. |

## Limits and memory

Excel limits are checked and the build stops instead of truncating:

- 1,048,576 rows per tab including the header: at most 1,048,575 bookings, and Company review needs
  `1 + 2 × (clients + parent rows)` rows;
- 65,530 links per tab (one per non-zero booking count);
- 32,767 characters per cell; text with characters XML cannot store also stops the build.

Memory: the consumed CSV rows of the whole export are held in memory as compact rows (about proportional to the
number of bookings); the Bookings tab is generated row by row and streamed into the file, and the check re-reads the
worksheets as a stream. The automated capacity test builds and checks a synthetic export of 50 companies, 400 parent
rows and 200,000 bookings within the default 512 MB test heap (about 13 seconds on a developer laptop). For much
larger exports, raise the Java heap (`JAVA_OPTS=-Xmx2g`) or export in smaller selections.
