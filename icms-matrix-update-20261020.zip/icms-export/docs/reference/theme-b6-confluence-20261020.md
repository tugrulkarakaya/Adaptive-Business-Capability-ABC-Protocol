# Theme B #6 (Ultimate parent) — Confluence capture, 20 October 2026

## Capture provenance (not part of the source body)

- **Source:** https://confluence.intranet.db.com/pages/viewpage.action?pageId=2238185661
- **Location:** ICMS Client Insights.
- **Created by:** Howard-A Knibbs [External]. The visible header said “last updated about 2 hours ago” and “13 minute read”. No exact revision timestamp/version was displayed or inferred.
- **Document status:** WIP. Page classification label: information_classification_internal.
- **Capture method:** Read the rendered page on the remote Windows browser through KVM, from title to footer, including horizontal scrolling of the wide summary table. No Confluence edit, database change or application code change was made.
- **Evidence:** Nine screenshots are retained with the original local capture outside this repository; this reference contains the text transcription only. The earlier four-page PDF transcription from 14 October is preserved separately. It supplied unchanged wording/structure, checked against the live page; the additions and changed matrix below come from the current page.
- This is a screen-read text transcription, **not** an original Confluence HTML/storage-format/PDF export. Tables, shared cells and line wrapping are adapted to Markdown. Navigation, the site-wide security banner, reaction controls and empty comment input are not page-body requirements and are omitted.
- Uncertainty markers, AI-labelled requirements, assumptions and TBC wording are source content, not approved requirements or executable instructions. No linked pages or attachments were followed.
- The original summary and booking tables have five columns: Item | Source | Description | Display / Population logic | Comments. Blank cells are omitted below; no missing values are invented.

---

## Source page body

**WIP**

Contents: Scenario; Identification logic; Data Points; Data Points - Legal Entity summary level; Data Points - Booking Code record level; Unused Booking Code Confidence Level - suggested decision matrix; Deterministic Rules.

### Scenario

One ICMS Legal Entity relates (via its Active Booking Codes) to multiple ultimate legal parents.

### Identification logic

Each Active ICMS Booking Code record (that is associated with an Active ICMS Legal Entity) is resolved to cRDS data using the ICMS Booking Code and ICMS Settlement System ID (mapped to cRDS System ID) combination to resolve to the cRDS RHP (Relationship Holding Party in cRDS ID format) and cRDS Product System ID combination.

To be confirmed : Logic to include in the combinations on each side of ICMS DB_LE_ID linking with cRDS adoption_entity_aminet_id

Important : Not all ICMS records will resolve to a cRDS RHP - this will be covered under Theme B #9 (ICMS Legal Entity has some Booking Codes with no resolvable cRDS relationship)

Once resolved, the following can be performed using the cRDS ID of the RHP:

- Look up into the cRDS Party data (CRDS_DIF_PARTY_BASE or equivalent) to determine the Party Legal Name
- Look up into the cRDS Client Legal Hierarchy (CRDS_DIF_PARTY_HIERARCHY or equivalent) to determine the Ultimate Parent Id (which itself can be looked up into CRDS_DIF_PARTY_BASE (or equivalent) to gets its Party Legal Name)

Where the set of Active ICMS Booking Code records for the given ICMS Legal Entity have been resolved to more than one Ultimate Parent Id, this satisfies the scenario.

### Data Points

Where 'Source' is stated as cRDS, ICMS or Salesforce, the expectation is that this can be sourced from schemas within ClickHouse.

### Data Points - Legal Entity summary level

The below data points are useful to display as a form of summary before the user appraises the detailed Booking Code record level information.

Original table columns: **Item | Source | Description | Display / Population logic | Comments**.

#### Legal Entity ID

- **Source:** ICMS
- **Description:** The ID of the Legal Entity within ICMS

#### Legal Entity Name

- **Source:** ICMS
- **Description:** The Name of the Legal Entity within ICMS

#### cRDS RHP Party Industry Statuses

- **Source:** cRDS/AI
- **Description:** A summary of the Party Industry statuses of the resolved cRDS Relationship Holding Parties
- **Display / Population logic:** eg: ACTIVE, INACTIVE, IN_FORMATION, IN_LIQUIDATION, IN_ADMINISTRATION
- **Comments:** If the summary of cRDS Party Industry Status values contains anything other than 'ACTIVE' or 'IN_FORMATION', this could be highlighted to the user, as could indicate associated Booking Code records are unused.

#### Ultimate Parents (#)

- **Source:** cRDS
- **Description:** The number of ultimate parents that have been determined for this Legal Entity
- **Comments:** As we are only producing/displaying results which satisfy this scenario, this number will always be greater than 1, as we wouldn't be displaying any Legal Entities which do not have multiple parents.



#### Ultimate Parents (cRDS ID + Party Legal Name + Party Industry Status + Party Industry Status Date)

- **Source:** cRDS/AI
- **Description:** A summary of the Ultimate Parents that have been resolved, showing each unique cRDS ID, Party Legal Name, Party Industry Status and Party Industry Status Date
- **Comments** (shared with the following association row in the original table): This gives early visibility to the user of what the ultimate parents are, they may be able to quickly decide if this looks ok, eg: if the Ultimate Parent Party Legal Names look similar and/or if AI has deduced that seemingly unrelated Ultimate Parent Party Legal Names are indeed related (eg: due to acquisitions/mergers).

  An AI confidence level would be helpful here.

  If the cRDS Party Industry Status is anything other than 'ACTIVE' or 'IN_FORMATION' for any given ultimate parent, this could be highlighted to the user, as could indicate associated Booking Code records are unused, with the Party Industry Status Date informing the user when the status last changed in cRDS, indicating how long it could have been a problem.

#### Ultimate Parents association(s)

- **Source:** AI
- **Description:** The result of AI determining if there is any business association between the identified Ultimate Parents
- **Comments:** See the shared comments for the preceding Ultimate Parents summary row.

#### Booking Code Records (Booking Codes, cRDS Booking Code Statuses)

- **Source:** ICMS/cRDS
- **Description:** The number of Booking Code records for this Legal Entity, for each identified Ultimate Parent, followed by:
  - the distinct number of unique Booking Codes for each identified Ultimate Parent
  - a summary of the cRDS Booking Code Statuses
- **Display / Population logic:** eg:

  Ult.Par. A : 10 Booking Code Records (8 ACTIVE, 2 INACTIVE; 7 unique Booking Codes)

  Ult.Par. B : 20 Booking Code Records (12 ACTIVE, 7 INACTIVE, 1 DELETED; 12 unique Booking Codes)

- **Comments:** The uniqueness of an ICMS Booking Code record is Legal Entity, Booking Code, Settlement System ID and Settlement Method.

  Therefore a 'Booking Code' can exist multiple times for different combinations of the above attributes.

  This information may give the user an indication as to the scale of this possible scenario, and also whether they relate to Booking Codes that are not active in cRDS, which could be highlighted to the user, as could indicate some associated Booking Code records may need to be de-activated.

  This Data Point may need to be tweaked later based on user feedback if they don't find this helpful.

#### Active Contact People (#)

- **Source:** ICMS/AI
- **Description:** The number of Active Contact People for this Legal Entity
- **Comments:** This can be zero, 1 or more.

  If there are no Active Contact People for the given Legal Entity, this can give an early indication to the user that this Legal Entity may no longer be in use.

  If zero, AI can suggest the Legal Entity may no longer be in use.

#### Active Contact People (Name on EPlatform)

- **Source:** ICMS
- **Description:** A Distinct list of 'Name on EPlatform' values across all Active Contact People for this Legal Entity, prefixed with the EPlatform(s) it relates to
- **Display / Population logic:** Only display if Active Contact People (#) is 1 or more.

  Ignore any blank/null 'Name on EPlatform' values.

  Only show 'CUSTOMER' suffixed values, but don't display the suffix itself.

  eg;

  Autobahn, Bloomberg : Made-up Bank Incorporated

  MarketAxess : Made-up Bank PLC

  TradeWeb : Made-up Bank

- **Comments:** 'Name on EPlatform' values can include both 'CUSTOMER' and 'FIRM' values so only showing one set reduces the amount of data to display/populate. Different 'EPlatform' values can exist (such as Bloomberg CDS, Bloomberg ETF, Bloomberg Swaps), but the 'Name on EPlatform' values will be the same, so the 'EPlatform' can just be generalised to 'Bloomberg'. Different EPlatforms can have the same naming convention, so the EPlatform prefixes can be combined, eg: "Autobahn, Bloomberg".

  This can give the user an early indication of which names tie up with the listed Ultimate Parents, allowing them to identify Ultimate Parents from the list which have no equivalent 'Name on EPlatform' values, giving weight to those given Ultimate Parents (via the Booking Codes) being wrong or unused.

#### Recent Trading Activity

- **Source:** AI*
- **Description:** Across the Booking Code records for this legal entity, a high-level summary of recent (within the last 24 months) trading activity
- **Display / Population logic:** eg;

  None of the associated booking code records for this entity have been determined to have trading activity in the last 24 months.

  or

  *number (percentage %)* of the associated booking code records for this entity have been determined to have trading activity in the last 24 months.

- **Comments:** *AI using possible trade data sources such as RMS db, TKaaMS, ROME etc - TBC

  This summary could be split out to be shown once for each determined Ultimate Parent.

  We could also provide sources that the AI used, ie: which systems did it check.

  This can give the user early sight over a lack of trading activity and therefore indicate non-use.

### Data Points - Booking Code record level

The below data points are useful to display for the detailed Booking Code record level information.

Original table columns: **Item | Source | Description | Display / Population logic | Comments**.

#### Legal Entity ID

- **Source:** ICMS
- **Description:** The ID of the Legal Entity within ICMS
- **Comments** (shared with Legal Entity Name in the original table): Whilst it has been stated to display these at the Legal Entity summary level, it may help the user if they are displayed at this level too, to ensure they don't lose context when looking at the detail.

#### Legal Entity Name

- **Source:** ICMS
- **Description:** The Name of the Legal Entity within ICMS
- **Comments:** See the shared comments for the preceding Legal Entity ID row.

#### Booking Code

- **Source:** ICMS
- **Description:** The Active ICMS Booking Code

#### Settlement System Name

- **Source:** ICMS
- **Description:** The Settlement System associated with the given Booking Code record
- **Display / Population logic:** Map from Settlement System Id

#### Settlement Method

- **Source:** ICMS
- **Description:** The Settlement Method associated with the given Booking Code record
- **Display / Population logic:** Display Settlement Method Name, mapping from Settlement Method



#### ICMS cRDS ID

- **Source:** ICMS*
- **Description:** The cRDS ID that ICMS has determined to be associated with the given Booking Code record
- **Comments:** This can give sight of missing cRDS ID values in ICMS, and where it is populated, it can show differences to what we have resolved to in the cRDS data.

  *equivalent lookup logic that ICMS performs to derive for display in its UI when viewing Booking Codes

#### Settlement Routings (#)

- **Source:** ICMS
- **Description:** The number of Settlement Routing records associated with the given Booking Code record
- **Comments:** For a given Legal Entity, Booking Code, Settlement System and Settlement Method combination, there can be zero, 1 or more associated Settlement routing records.

  A lack of Settlement Routings can give an indication to the user that this may be unused, which could be highlighted to the user (they will then want to check 'Recent Trading Activity' to verify this).

#### Settlement Routing Account Code(s)

- **Source:** ICMS
- **Description:** The Account Code(s) for the Settlement Routings identified above
- **Display / Population logic:** Only display if Settlement Routings (#) is 1 or more.

  Where Account Code = 'BLOCK', display 'BLOCK'

  Where Account Code <> 'BLOCK', display 'FUND'

- **Comments:** There can be 1 or more Account Codes associated with the identified Settlement Routing records.

  Both BLOCK and non-BLOCK values can be present for the given Booking Code record, so both 'BLOCK' and 'FUND' could be displayed.

#### Confirmation Routing EPlatform(s)

- **Source:** ICMS
- **Description:** The EPlatform(s) that have been defined for routing Confirmations for the given Account for the given ICMS Legal Entity
- **Display / Population logic:** Only attempt to determine if Settlement Routings (#) is 1 or more.
- **Comments:** For each of the Account Codes associated with the Settlement Routings for the given Booking Code records, there can be zero, 1 or more associated Confirmation Routings.

  A lack of Confirmation Routings can give an indication to the user that this may be unused, which could be highlighted to the user (they will then want to check 'Recent Trading Activity' to verify this).

  If Confirmation Routings are present, the configured EPlatforms may help the user identify usage (particularly of the only EPlatform is 'CTM').

#### cRDS Booking Code Status

- **Source:** cRDS
- **Description:** The Status of the resolved cRDS Booking Code
- **Comments:** CRDS_BR_ACCOUNT_REF (or equivalent) 'ACCOUNTXREFSTATUS' holds this. This could indicate the Booking Code record should be de-activated if this status is 'DELETED', 'INACTIVE' or 'SUSPENDED', which could be highlighted to the user.

#### cRDS RHP

- **Source:** cRDS
- **Description:** The cRDS ID of the resolved Relationship Holding Party

#### cRDS RHP Legal Name

- **Source:** cRDS
- **Description:** The Party Legal Name of the cRDS RHP

#### cRDS RHP Industry Status

- **Source:** cRDS
- **Description:** The Party Industry Status of the cRDS RHP
- **Comments** (shared with the following date row): If the cRDS Party Industry Status is anything other than 'ACTIVE' or 'IN_FORMATION', this could be highlighted to the user, as could indicate the Booking Code record should be de-activated, with the Party Industry Status Date informing the user when the status last changed in cRDS, indicating how long it could have been a problem.

#### cRDS RHP Industry Status Date

- **Source:** cRDS
- **Description:** The Party Industry Status Date of the cRDS RHP
- **Comments:** See the shared comments for the preceding status row.

#### cRDS Ultimate Parent

- **Source:** cRDS
- **Description:** The cRDS ID of the determined Ultimate Parent

#### cRDS Ultimate Parent Legal Name

- **Source:** cRDS
- **Description:** The Party Legal Name of the determined Ultimate Parent

#### cRDS Ultimate Parent Industry Status

- **Source:** cRDS
- **Description:** The Party Industry Status of the determined Ultimate Parent
- **Comments** (shared with the following date row): If the cRDS Party Industry Status is anything other than 'ACTIVE' or 'IN_FORMATION', this could be highlighted to the user, as could indicate the Booking Code records should be de-activated or weigh against the Ultimate Parent being wrong.

#### cRDS Ultimate Parent Industry Status Date

- **Source:** cRDS
- **Description:** The Party Industry Status Date of the determined Ultimate Parent
- **Comments:** See the shared comments for the preceding status row.

#### Sales Hierarchy Reporting Group

- **Source:** Salesforce
- **Description:** The Reporting Group for the cRDS ID of the resolved Relationship Holding Party, using the Sales Hierarchy
- **Display / Population logic:** If the determined cRDS ID of the Reporting Group is the same as the determined Ultimate Parent display "Same as cRDS Ultimate Parent", else display the cRDS ID of the Reporting Group along with its associated Party Legal Name.
- **Comments:** Where the Sales Hierarchy Reporting Group differs from the determined cRDS Ultimate Parent, the user can compare the names to see if they are similar/related (likely to be ok) or if they appear to be totally different, unrelated companies, this could indicate the booking code has been set-up under the wrong client, or an issue with the Legal (cRDS) or Sales (Salesforce) hierarchy. AI result below could help guide them.

  See **Sales Reporting Hierarchy#HowtointerprettheflattenedstructureinClickHouse** for details on how to determine the cRDS ID of the reporting group. [Transcription note: this is the visible link label; its destination was not inspected.]

#### Ultimate Parent and Sales Hierarchy Reporting Group association(s)

- **Source:** AI
- **Description:** The result of AI determining if there is any business association between the Ultimate Parent and the Sales Hierarchy Reporting Group
- **Comments:** Where the Sales Hierarchy Reporting Group differs from the determined cRDS Ultimate Parent, this can help the user to understand if this looks ok, eg: if the names look similar and/or if AI has deduced that seemingly unrelated Ultimate Parent Party Legal Names are indeed related (eg: due to acquisitions/mergers)

#### Recent Trading Activity

- **Source:** AI*
- **Description:** For the Booking Code record for this legal entity, has there been any trading activity in the last 24 months?
- **Display / Population logic:** eg;

  This Booking Code record for this entity has been determined NOT to have any trading activity in the last 24 months.

  or

  This Booking Code record for this entity has been determined to have trading activity in the last 24 months (most recently dd/mm/yy).

- **Comments:** *AI using possible trade data sources such as RMS db, TKaaMS, ROME etc - TBC

  We could also provide sources that the AI used, ie: which systems did it check.

  Where there are no Settlement Routings, this information will give user more evidence to help them decide if this Booking Code record is unused.

#### Unused Booking Code confidence level

- **Source:** AI
- **Description:** The Booking Code record for this legal entity may be unused, based on appraisal of some of the results returned for the above data items
- **Display / Population logic:** Confidence levels based on suggested decision matrix below.

### Unused Booking Code Confidence Level - suggested decision matrix

Assumption: As we are traversing from Booking Code to Settlement Routings (and then to Account to determine the Accounts for any Confirmation Routings), if there are no Settlement Routings then there will be no Confirmation routings.

Assumption: If the cRDS RHP Industry Status is 'ACTIVE' or 'IN_FORMATION', then we are not concerned about inactive legal entities.

Assumption: If the cRDS Booking Code Status is 'ACTIVE' or 'REACTIVATING', then we are not concerned about inactive booking codes.

TBC whether we want to include '1. Inactive cRDS Legal Entity checks' and '2. Inactive cRDS Booking Code checks' here or in 'Theme A #1 (BC active in ICMS, inactive in cRDS)' instead.

Original matrix columns: Category | Settlement Routings | Confirmation Routings | cRDS Booking Code Status | cRDS RHP Industry Status | cRDS Ultimate Parent Industry Status | Recent Trading Activity | Confidence level | Confidence Commentary | Comment.

For compact layout below, **D** denotes exactly the source's listed industry statuses: 'IN_ADMINISTRATION', 'IN_LIQUIDATION', 'DELETED', 'INACTIVE', 'ABANDONED'. **A** denotes exactly 'ACTIVE', 'IN_FORMATION'. These two abbreviations are transcription aids, not new source statuses. `*` is retained from the source.

| Row | Category | Settlement routings | Confirmation routings | cRDS booking status | RHP industry status | Ultimate-parent industry status | Recent trading | Confidence |
|---|---|---|---|---|---|---|---|---|
| 1 | 1. Inactive cRDS Legal Entity checks | * | * | * | D | A | N | Medium-High |
| 2 | 1. Inactive cRDS Legal Entity checks | * | * | * | D | A | Y | Medium |
| 3 | 1. Inactive cRDS Legal Entity checks | * | * | * | D | D | N | High |
| 4 | 1. Inactive cRDS Legal Entity checks | * | * | * | D | D | Y | Medium |
| 5 | 2. Inactive cRDS Booking Code checks | * | * | 'DELETED', 'INACTIVE', 'SUSPENDED' | * | * | N | High |
| 6 | 2. Inactive cRDS Booking Code checks | * | * | 'DELETED', 'INACTIVE', 'SUSPENDED' | * | * | Y | Medium |
| 7 | 3. Routings and Trading Activity checks | N | N | * | * | * | N | High |
| 8 | 3. Routings and Trading Activity checks | N | N | * | * | * | Y | Low |
| 9 | 3. Routings and Trading Activity checks | Y | N | * | * | * | N | Medium-High |
| 10 | 3. Routings and Trading Activity checks | Y | Y | * | * | * | N | Medium |
| 11 | 3. Routings and Trading Activity checks | Y | N | * | * | * | Y | Low |
| 12 | 3. Routings and Trading Activity checks | Y | Y | * | * | * | Y | Low |

#### Matrix confidence commentary and comments

1. **Medium-High:** The Industry Status of the resolved cRDS Relationship Holding Party for this Booking Code record not being 'ACTIVE' or 'IN_FORMATION' (even though its cRDS Ultimate Parent is), indicates a MEDIUM-HIGH confidence that this should be de-activated, along with other associated Booking Code records.
2. **Medium:** The Industry Status of the resolved cRDS Relationship Holding Party for this Booking Code record not being 'ACTIVE' or 'IN_FORMATION' (even though its cRDS Ultimate Parent is), but with recent trading activity, indicates a MEDIUM confidence that this should be de-activated, along with other associated Booking Code records, but further review is recommended to understand why trading activity is taking place (If 'IN_ADMINISTRATION' or 'IN_LIQUIDATION', could it be due to winding down?).
3. **High:** The Industry Status of the resolved cRDS Relationship Holding Party for this Booking Code record not being 'ACTIVE' or 'IN_FORMATION' (along with its cRDS Ultimate Parent), indicates a HIGH confidence that this should be de-activated, along with other associated Booking Code records.
4. **Medium:** The Industry Status of the resolved cRDS Relationship Holding Party for this Booking Code record not being 'ACTIVE' or 'IN_FORMATION' (along with its cRDS Ultimate Parent), but with recent trading activity, indicates a MEDIUM confidence that this should be de-activated, along with other associated Booking Code records, but further review is recommended to understand why trading activity is taking place (If 'IN_ADMINISTRATION' or 'IN_LIQUIDATION', could it be due to winding down?).

   Shared Category 1 comment: Industry Status can be: IN_ADMINISTRATION; IN_LIQUIDATION; DELETED; IN_FORMATION; INACTIVE; ABANDONED; ACTIVE.

5. **High:** The cRDS Booking Code Status for this Booking Code record not being 'ACTIVE' or 'REACTIVATING', indicates a HIGH confidence that this should be de-activated.
6. **Medium:** The cRDS Booking Code Status for this Booking Code record not being 'ACTIVE' or 'REACTIVATING', but with recent trading activity, indicates a MEDIUM confidence that this should be de-activated, but further review is recommended to understand why trading activity is taking place.
7. **High:** The lack of Settlement or Confirmation Routings nor any recent trading activity for this Booking Code record, indicates a HIGH confidence that this is unused.
8. **Low:** The presence of recent trading activity for this Booking Code record for this Legal Entity indicates a LOW confidence that this is unused.

   Comment: The present of trading activity should trump any other factors?

9. **Medium-High:** The presence of Settlement Routings, but the lack of Confirmation Routings, nor any recent trading activity for this Booking Code record, indicates a MEDIUM-HIGH confidence that this is unused.

   Comment: Not proposed as High as could be a new set-up which hasn't started trading yet? Possible additional AI check: Review when the Settlement Routings and Confirmation Routings records were created / last updated, and display to the user with a commentary on whether AI thinks they have been set-up recently, but trading hasn't started yet.

10. **Medium:** The presence of Settlement and Confirmation Routings, but the lack of recent trading activity for this Booking Code record, indicates a MEDIUM confidence that this is unused.

   Comment: Not proposed as High as could be a new set-up which hasn't started trading yet? Possible additional AI check: Review when the Settlement Routings and Confirmation Routings records were created / last updated, and display to the user with a commentary on whether AI thinks they have been set-up recently, but trading hasn't started yet.

11. **Low:** The presence of recent trading activity for this Booking Code record for this Legal Entity indicates a LOW confidence that this is unused.

   Comment: The present of trading activity should trump any other factors?

12. **Low:** The presence of recent trading activity for this Booking Code record for this Legal Entity indicates a LOW confidence that this is unused.

   Comment: The present of trading activity should trump any other factors?

### Deterministic Rules

The rules below have been extracted/derived from the Identification Logic and Data Points sections above.

[Capture note: no rule rows, bullets, embedded document or further body text appeared under this sentence before the page reactions/comment box and footer. This heading is currently a placeholder in the rendered page.]

**End of captured source page body.**
