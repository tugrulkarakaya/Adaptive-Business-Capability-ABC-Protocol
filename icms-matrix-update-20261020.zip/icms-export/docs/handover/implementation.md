# How it works, tests and QA

## Flow of one export run

```mermaid
flowchart TD
    A["Command line<br/>CliOptions checks every option"] --> B{"Selection"}
    B -->|"--ids or --ids-file"| C["Typed entity IDs"]
    B -->|"--all-flagged"| D["Discovery: review-cohort.sql<br/>pages of 500 IDs"]
    C --> E["Cut into batches<br/>(--export-batch-size)"]
    D --> E
    E --> F["At most --workers batches<br/>read at the same time"]
    F --> G["Per batch: read-only, parameterized<br/>Oracle queries (or demo / fixture data)"]
    G --> H["Rules: extraction checks and<br/>parent review facts (no AI)"]
    H --> I["Batch folder: 32 CSVs, evidence.json,<br/>run-manifest.json; written in input order"]
    I --> J["All batches done:<br/>manifest staged under a temporary name"]
    J --> K["Workbook: read the staged export, build 6 tabs,<br/>re-read and verify, write receipt"]
    K -->|"verified"| L["Publish collection-manifest.json<br/>exit 0 complete, 2 incomplete"]
    K -->|"failed"| M["Remove staged manifest, keep batches<br/>exit 3, no manifest"]
```

In words:

1. The CLI checks the options and opens the sources (demo, fixture or the Oracle profiles). Configuration mistakes stop the run with exit 64.
2. The selection becomes a list of typed entity IDs, either given by you or discovered page by page.
3. IDs are cut into batches. Up to `--workers` batches are extracted in parallel. A new batch starts only after an earlier one has been written, so memory holds at most `--workers` batches.
4. Each batch reads its sources with bound parameters in read-only transactions ([data-sources.md](data-sources.md)). A failed or truncated read is recorded as PARTIAL or FAILED, never as "no data".
5. Pure Kotlin rules turn the facts into checks, review counts and clues. They never choose a parent.
6. Each batch is written to its own folder, in selection order. `run-manifest.json` is written last and holds the SHA-256 of every other file.
7. After the last batch the collection manifest is staged. The workbook is built from the staged export, re-read and checked, and its receipt written. Only then is `collection-manifest.json` published. If the workbook fails, the run exits 3 and publishes nothing. An export with no companies or no review data skips the workbook and publishes as before.

Batching, memory and cancellation details: [batch-processing.md](../batch-processing.md). Workbook layout and checks: [review-workbook.md](../review-workbook.md).

## Who owns each step

Packages are under `src/main/kotlin/com/db/clientinsights/export/`.

| Step | Package | Main classes |
|---|---|---|
| Parse options, open sources, run, print results, map failures to exit codes | `cli` | `ExportRunner` (`runCli`, `openSources`, `exportCollection`), `CliOptions`, `ExitCodes`, `ExportWorkbookStep`, `WorkbookCommand` |
| Selection, batches, bounded parallel workers, one batch extraction | `application` | `CohortExportService`, `BatchExportProcessor`, `ExportService` |
| Contracts between the core and the adapters | `ports` | `IcmsSource`, `IcmsReferenceSource`, `ReviewCohortSource`, `ReviewDataSource`, `UsageEvidenceSource`, `EvidenceBatchSink` |
| Oracle configuration, JDBC, SQL templates | `adapters/icms` | `OracleSourceConfiguration`, `JdbcQueryExecutor`, `SqlTemplate`, `OracleIcmsSource`, `OracleIcmsReferenceSource`, `OracleReviewCohortSource`, `OracleReviewDataSource`, `OracleUsageEvidenceSource` |
| Demo and fixture data | `adapters/fixture` | `FixtureSources` |
| Typed facts, statuses, evidence and manifest schemas | `domain` | `EvidenceBundle`, `ExportCollection`, `SourceFacts`, `ReviewFacts`, `DeterministicReview`, `ThemeB6`, `UsageEvidence`, `Identifiers` |
| Business checks (pure functions, no I/O) | `rules` | `ExtractionChecks`, `ReviewRules`, `EntityReviewRules`, `BookingReviewRules`, `ParentCandidateRules`, `ParentRelationships`, `BankIdentityRules`, `PlatformNameRules`, `NameSignals`, `UnusedConfidence`, `ThemeB6Rules`, `UsageEvidenceRules` |
| CSV files | `adapters/csv` | `CsvExports`, `ReviewCsvExports`, `PlatformCsvExports`, `ThemeB6CsvExports`, `UsageCsvExports` |
| Batch folders and manifests (stage, publish, discard) | `adapters/bundle` | `EvidenceBundleWriter`, `ExportCollectionWriter` |
| Evidence JSON format | `adapters/serialization` | `EvidenceJson` |
| Workbook: orchestration, layout, tabs, XLSX writer, receipt, safe publishing | `workbook` | `ReviewWorkbookService`, `WorkbookLayout`, `WorkbookModel`, `WorkbookInput`, `ReviewJoin`, `WorkbookContent`, `SummarySheet`, `CompanyReviewSheet`, `BookingsSheet`, `RulesSheet`, `XlsxWriter`, `XlsxVerifier`, `WorkbookTarget`, `WorkbookReceipt` |
| Workbook input: read and integrity-check a saved export | `workbook/input` | `BatchReader`, `CsvTableReader`, `ManifestJson`, `PathGuards`, `RequiredColumns`, `CompanyIndex` |
| Workbook verification: re-read the written file | `workbook/verify` | `PackageReader`, `PackageChecks`, `WorksheetChecks`, `CompanyReviewChecks`, `BookingsChecks`, `ChartChecks` |

The rules depend only on `domain`. The adapters depend on `ports` and `domain`. A new source (for example a composed cross-database adapter) can be added behind the same ports without changing rules or exports.

## Tests

Run all tests from the `icms-export` folder (its own Gradle build; no database, no network beyond the Gradle mirror):

```powershell
.\gradlew.bat test
.\gradlew.bat test --tests "com.db.clientinsights.export.CharacterizationTest"
```

At handover the suite had 238 tests, all passing. The report is `build\reports\tests\test\index.html`.

SQL tests run the shipped SQL files against H2 in Oracle mode with synthetic data. They prove the SQL logic, not Oracle driver behaviour, real data or timings.

| Test | What it protects |
|---|---|
| `CharacterizationTest` | Every output file for fixed synthetic inputs must equal an accepted snapshot in `src/test/resources/characterization/`: the demo fixture, a rule corpus that reaches every rule outcome, and SQL exports (mapped entities, a failed cRDS path read, failed optional sources). Only query-run IDs are normalized. A difference writes the new output to `build\characterization\`; accept it only after reviewing the diff and copying the file over the snapshot. |
| `WorkbookCapacityTest` (tag `capacity`, runs in the normal suite) | 50 companies, 400 parents and 200,000 bookings: the workbook is built and verified within the default test heap and under 90 seconds. A tab over Excel's row or link limit stops the build instead of truncating. |
| `ReviewVolumeTest` | 10,000 bookings through the rules (in memory). |
| `BatchExportTest` | 1,083 synthetic flagged companies in bounded batches; worker admission, cancellation, interruption. |
| `CliExitCodesTest`, `ExportWorkbookTest`, `WorkbookCommandTest`, `WorkbookArgumentsTest` | Every exit code and option, including the workbook step in a normal run (exit 3, batches kept, no manifest) and the offline command. |
| `WorkbookInputGuardsTest`, `WorkbookGuardsTest`, `WorkbookOutputRulesTest`, `WorkbookPublicationTest` | Integrity checks of a saved export (sizes, hashes, row counts, links, unpublished exports), output naming, never replacing a file, all-or-nothing publishing. |
| `XlsxVerifierTest` | The re-read check rejects a workbook that differs from what was meant to be written. |
| `ReviewSqlTest`, `JdbcSourcesTest`, `CurrentPathCoverageTest` | Current-rule and baseline SQL behaviour, paging, row limits, partial reads, unknown versus zero. |

## QA checklist for a real run

1. **Exit code.** `$LASTEXITCODE` is 0 or 2. Anything else: see [exit codes](running.md#exit-codes). For 2, open `source-status.csv` in each batch folder and list the queries whose `status` is not `COMPLETE` (`failure_code` says why). In the verified bank environment one activity view was known to fail, which alone gives exit 2 ([oracle-verification-20261019.md](../oracle-verification-20261019.md)).
2. **Files.** The collection folder printed by the run holds `collection-manifest.json`, `ICMS-company-review.xlsx`, `workbook-receipt.json` and `batches\`.
3. **Counts.** The console line `Selected entities: N` equals the number of IDs you gave (or the number discovered). For explicit IDs, `batches` = N divided by the batch size, rounded up.
4. **Open the workbook in Excel.** No repair prompt. Exactly 6 tabs, in order: Summary, Company review, Bookings, Rules and assumptions, Company evidence, Matrix review.
5. **Client count.** Company review has one client row per selected client; `verification.companyRows` in the receipt equals N.
6. **Jump links.** Clear any filter on the Bookings tab first (a link cannot clear a filter). Click the link in the bookings column of a client row and of a parent row: each goes to the first matching row on the Bookings tab. Sort the Bookings tab and try again: the link still finds the first matching row in the new order.
7. **Filters.** The Bookings tab has a filter on its header row. Filter by one client ID; the number of rows equals the bookings number on that client's row.
8. **Decisions are empty.** Decision, comment, reviewer and date cells are blank; the dropdown shows the agreed options. The A1-A4 team cells on Rules and assumptions are blank.
9. **Receipt hashes.** In the collection folder:

   ```powershell
   $r = Get-Content .\workbook-receipt.json -Raw | ConvertFrom-Json
   (Get-FileHash .\ICMS-company-review.xlsx -Algorithm SHA256).Hash -eq $r.workbookSha256
   (Get-FileHash .\collection-manifest.json -Algorithm SHA256).Hash -eq $r.manifestSha256
   ```

   Both lines must print `True` (`-eq` ignores case). The receipt also lists the SHA-256 of every CSV it read (`consumedFileSha256`) and the producer version and Git revision.
10. **Blank is not zero.** A blank count means the read it depends on was incomplete. Do not read it as 0 ([assumptions.md](assumptions.md#blank-means-unknown-not-zero)).

## Confluence status and optional usage extension

Evidence schema 1.4.0 adds `all-booking-status-paths.sql` on the existing `review` profile. Unlike the selected current-parent query, it retains inactive account links, historical hierarchy paths, and incomplete party/hierarchy joins. It does not change existing parent selection. `ThemeB6Rules` prepares separate suggested-matrix categories and deduplicated RHP/parent status summaries. There is no combined confidence or automatic bank update.

`UsageEvidenceSource` is an independent optional read port for verified contact-person, confirmation-route and dated trading facts. Oracle mode connects `OracleUsageEvidenceSource` to `contact-people.sql` on the `contacts` profile for active-person counts. Contact platform names, confirmation routes and dated trades remain unconfigured until their source joins are validated. `UsageEvidenceRules` checks completion, verified links and explicit trading-window coverage before publishing known results. JSON `review.usage.entityTrading` adds per-company confirmed trading/no-trading/unknown counts; a percentage is emitted only with a complete booking cohort. Booking/account platform names remain separate from active-person names. The existing four Excel tabs retain their columns. Company evidence and Matrix review present the new counts/statuses and separate provisional categories, and the same JSON/CSV fields are ready for the future HTML page. See [Confluence coverage](../confluence-theme-b6.md) for requirement coverage and remaining decisions.
