# Data sources and SQL map

This page lists every SQL file the exporter runs, which connection profile runs it, which tables and views it reads, and which output it feeds. It was written from the SQL text in `src/main/resources/sql/icms/oracle/` and the adapters in `adapters/icms/`.

Counts, so you can cross-check: **24 SQL files** (23 queries plus 1 shared block of common table expressions), **25 database objects** (tables or views; the code does not tell which is which), **12 connection profiles**.

## Connection profiles and source boundaries

A profile is a named connection in the configuration file (`<profile>.jdbc.url`, `.username`, `.password-env`, `.schema`, ...). See [running.md](running.md#oracle-configuration) for the settings.

| Profile | SQL files it runs | Kotlin adapter |
|---|---|---|
| `icms` | `entities`, `booking-records`, `shared-booking-keys`, `assignment-lineage` | `OracleIcmsSource`, `OracleReviewDataSource` |
| `references` | `booking-systems`, `settlement-methods` | `OracleIcmsReferenceSource` |
| `cohort` | `review-cohort` (only with `--all-flagged`) | `OracleReviewCohortSource` |
| `review` | `parent-paths`, `current-booking-paths` (both include `review-paths-ctes`), `all-booking-status-paths` | `OracleReviewDataSource` |
| `routings` | `settlement-routings`, `routing-lineage` | `OracleReviewDataSource` |
| `platforms` | `booking-platform-names` | `OracleReviewDataSource` |
| `native-bookings` | `platform-native-bookings` | `OracleReviewDataSource` |
| `parties` | `party-facts` | `OracleReviewDataSource` |
| `salesforce` | `salesforce-hierarchy` | `OracleReviewDataSource` |
| `identity` | `bank-lei-identifiers`, `bank-identity-cache`, `bank-party-address` | `OracleReviewDataSource` |
| `activity` | `activity-ps-trade`, `activity-eplatform`, `activity-mosaic` | `OracleReviewDataSource` |
| `contacts` | `contact-people` | `OracleUsageEvidenceSource` |

Rules that follow from the code:

- **One query, one connection.** Every table in one SQL statement must be reachable through that statement's profile (same database, schema or synonyms). There is no join across two databases. For example, `review-cohort`, `parent-paths` and `current-booking-paths` join ICMS export tables with cRDS tables, so the `cohort` and `review` connections must see both. Moving a profile to another database only works if that database has every object its SQL files read.
- **Inheritance.** A non-ICMS profile without its own `jdbc.url` falls back to the `icms` settings. A profile with its own URL gets no `icms` fallback and must name its own `password-env`.
- **Schema prefix.** `{{schema}}` in the SQL becomes `<schema>.` from the profile's `schema` setting (checked against a strict name pattern). With no schema, table names are not prefixed. Object names below are shown without a schema.
- **Read only.** Each connection runs `SET TRANSACTION READ ONLY` and is rolled back after the read. Only bundled `SELECT`/`WITH` files can run.
- **Bound values.** IDs and the booking status are bind parameters (`?`). Only the schema prefix, the page size and the number of `?` placeholders are put into the text, and all three are validated first.
- **Paging.** Every query except the three activity probes ends with a keyset filter `(? IS NULL OR id > ?)`, `ORDER BY id` and `FETCH FIRST n ROWS ONLY`. Lookup keys go in chunks of `query.batch-size` (default 500). The `id` column of most review queries is a generated `ROW_NUMBER()` used only for paging; it is not a business ID.
- **No snapshot.** Queries, batches and profiles are read at different moments. `snapshot-at` is a label you supply; it does not make the database read the past.

## What the exporter does not read

- **No trade or activity data.** The three activity queries only check whether a source can be reached (see [Activity probes](#activity-probes)). They do not fetch any trade, date, entity or booking. Oracle mode does not evaluate recent trading from these probes. An optional `UsageEvidenceSource` can supply verified dated trading, but no validated Oracle adapter is provided.
- Active contact-person counts have a validated Oracle adapter. Its external-system/platform-name bridge is not yet validated, so a known count does not certify contact platform names. Confirmation routing and dated trading remain unconfigured; missing inputs remain unknown.
- No GLEIF, web, AI model or agent call.
- No write of any kind to any database.

## Query map

"Batch IDs" means the ICMS entity IDs of one export batch. Every output CSV is per batch folder. "Evidence" means the batch's `evidence.json`.

### Core extraction

| SQL file | Profile, adapter | Reads | Keys, joins and filters | Fields fetched | Feeds |
|---|---|---|---|---|---|
| `entities.sql` | `icms`, `OracleIcmsSource.fetchEntities` | `PRD_EXPORT_LEGAL_ENTITY` | `id IN (batch IDs)` | `id`, `name`, `status`: the company header | `entities.csv`; evidence `facts.entities` |
| `booking-records.sql` | `icms`, `OracleIcmsSource.fetchBookingRecords` | `PRD_EXPORT_BOOKING_CODE` | `le_id IN (batch IDs)`; `(? IS NULL OR status = ?)` bound to `Active`, or to null for `--booking-status all` | `id`, `le_id`, `booking_code`, `settlement_system_id`, `settlement_method`, `crds_id` (the booking's assigned cRDS party), `status` | `booking-records.csv`; evidence `facts.bookingRecords`; workbook Bookings tab |
| `booking-systems.sql` | `references`, `OracleIcmsReferenceSource` | `T_CRDS_BOOKING_SYSTEM` | `id IN (distinct settlement_system_id of the bookings read)` | `id`, `name`, `crds_system_id`: ICMS system name and its cRDS system | system columns of `booking-records.csv`; evidence `facts.bookingSystems` |
| `settlement-methods.sql` | `references`, `OracleIcmsReferenceSource` | `T_SETTLEMENT_METHOD` | `id IN (distinct settlement_method of the bookings read)` | `id`, `name` | method columns of `booking-records.csv`; evidence `facts.settlementMethods` |

### Automatic selection (discovery)

| SQL file | Profile, adapter | Reads | Keys, joins and filters | Fields fetched | Feeds |
|---|---|---|---|---|---|
| `review-cohort.sql` | `cohort`, `OracleReviewCohortSource` (only `--all-flagged`) | `PRD_EXPORT_LEGAL_ENTITY`, `PRD_EXPORT_BOOKING_CODE`, `T_CRDS_BOOKING_SYSTEM` (left join), and the [cRDS chain](#the-shared-crds-join-chain) | No entity keys. Bookings with `status = 'Active'` (fixed, whatever `--booking-status` says); entity status is not filtered. cRDS paths: 27-system list, `TEMP_LE` excluded, primary hierarchy. Per (system, booking code, AMINET ID): Active account link first, then the latest of five status dates, a missing date counting as now (A1). Per key: lowest ultimate parent ID wins (copy of the old first-match lookup). A company is selected when its keys give more than one distinct parent (a missing parent counts as one value). Pages of 500 IDs plus one look-ahead row, cursor on `le_id`. | `le_id AS id` only | `collection-manifest.json` discovery pages; no CSV |

### Parent paths (shared block plus selected-parent queries and independent status evidence)

| SQL file | Profile, adapter | Reads | Keys, joins and filters | Fields fetched | Feeds |
|---|---|---|---|---|---|
| `review-paths-ctes.sql` | Not run alone. Pasted into the next two files in place of `{{review_paths_ctes}}`; part of their query hash. | `PRD_EXPORT_LEGAL_ENTITY`, `PRD_EXPORT_BOOKING_CODE`, `T_CRDS_BOOKING_SYSTEM`, the [cRDS chain](#the-shared-crds-join-chain) | `RequestedEntities`: `id IN (batch IDs)`, the only place the IDs are bound. `ActiveICMSBookings`: Active bookings with a matching booking-system reference row (inner join); the cRDS mapping (`crds_system_id`) can be null, and such bookings then match no path. `ScoredPaths`: cRDS chain matched to those bookings by booking code and cRDS system; 27-system list; `TEMP_LE` excluded; `recency` = latest of five status dates, missing = now (A1); `hierarchy_ended` = end date before now. `RankedPaths`: old-report rank per (system, code, AMINET ID), Active link first then recency; ties counted. `KeyStats`: per key. `CurrentPaths`: Active account link, Active business relationship, hierarchy not ended, parent not null; ranked by recency, then lowest parent ID, then lowest RHP ID. Also defines `LeAllPaths`, `LeReportLogic`, `LeCurrent`, which neither query uses. | (internal) | via the next two files |
| `parent-paths.sql` | `review`, `OracleReviewDataSource` | as above | `RankedPaths` grouped by (cRDS system, booking code, hierarchy parent) | `system_id`, `booking_code`, `hierarchy_parent_id`, `MAX(report_parent_id)`, `path_count`, `active_xref_paths`, `report_rank_paths`, `tie_at_report_rank`, `min_xref_status`, `max_xref_status` | `parent-paths.csv`; evidence `review.facts.paths`; path columns of `entity-review.csv`; `parent-candidates.csv`; `parent-relationships.csv`; findings in `data-issues.csv` |
| `current-booking-paths.sql` | `review`, `OracleReviewDataSource` | as above, plus `T_SETTLEMENT_METHOD` | Every Active booking of the batch's entities (`bc.status = 'Active'`), left-joined to its system, method, `KeyStats` and the top `CurrentPaths` row, on booking code and cRDS system | Used: `id`, `le_id`, `has_crds_path`, `rhp_id`, `ultimate_parent_id`, `current_parents_on_key`, and seven link statuses (`account_xref_status`, `product_system_status`, `product_adoption_status`, `adoption_entity_status`, `adoption_location_status`, `business_relationship_status`, `hierarchy_status`). Fetched but not mapped: `booking_code`, `settlement_system_id`, `settlement_system_name`, `system_id`, `settlement_method`, `settlement_method_name`, `icms_crds_id`. | `booking-review.csv` (resolution, RHP, current parent, statuses); current columns of `entity-review.csv`; `parent-candidates.csv`; evidence `review.facts.currentBookings`; no own CSV |
| `all-booking-status-paths.sql` | `review`, `OracleReviewDataSource` | Active `PRD_EXPORT_BOOKING_CODE` keys mapped through `T_CRDS_BOOKING_SYSTEM`, then `CRDS_BR_ACCOUNT_XREF`, `CRDS_BR_PRODUCT_SYSTEM` and left-joined adoption, relationship and primary-hierarchy tables | Batch entity IDs; same 27-system scope and `TEMP_LE` exclusion. No ACTIVE account-link or current-hierarchy filter. Partial chains survive left joins; identical status observations are grouped with a path count. All grouping fields participate in the paging order. | cRDS system/code, RHP/parent IDs, accountxref status/date, all link statuses, hierarchy-ended flag and path multiplicity | `theme-b6-status-paths.csv`, separate path/category assessments, RHP/parent status summaries; evidence `review.facts.allStatusPaths`. Existing current/baseline selection is unchanged. |

### Routings, shared keys and assignments

| SQL file | Profile, adapter | Reads | Keys, joins and filters | Fields fetched | Feeds |
|---|---|---|---|---|---|
| `settlement-routings.sql` | `routings`, `OracleReviewDataSource` | `PRD_EXPORT_SETTLEMENT_ROUTING` | `le_id IN (batch IDs)`, grouped by entity, booking code and ICMS system | `routing_count`; `block_count` (`UPPER(TRIM(account_code)) = 'BLOCK'`); `last_change` = latest of update or creation time, as a date | `settlement-routings.csv` (its `fund_count` is `routing_count - block_count`, computed in Kotlin); routing columns of `booking-review.csv`; "unused" check input |
| `routing-lineage.sql` | `routings`, `OracleReviewDataSource` | `PRD_EXPORT_BOOKING_CODE` (all statuses), `PRD_EXPORT_SETTLEMENT_ROUTING`, `PRD_EXPORT_ACCOUNT` | Distinct (entity, booking code, ICMS system) of the entity's assignments; routings joined on all three; assignment matched by `sr.booking_code_id = bc.id`; account by `a.id = sr.account_id`; totals of the same code and system for any entity | `route_count`, `active_route_count` (`booking_code_status = 'Active'`), `matching_assignment_ids`, `account_count`, `requested_entity_accounts`, `missing_accounts`, `other_entity_routes` | `routing-lineage.csv`; routing findings in `data-issues.csv`; evidence |
| `shared-booking-keys.sql` | `icms`, `OracleReviewDataSource` | `PRD_EXPORT_BOOKING_CODE` (twice), `PRD_EXPORT_LEGAL_ENTITY` | Active bookings of the batch's entities joined to Active bookings of *other* entities with the same booking code and ICMS system | `le_id`, `booking_code`, `settlement_system_id`, `other_le_id`, `other_name` | `shared-booking-keys.csv`; `shared_keys` in `entity-review.csv` and `parent-candidates.csv` |
| `assignment-lineage.sql` | `icms`, `OracleReviewDataSource` | `PRD_EXPORT_BOOKING_CODE` | `le_id IN (batch IDs)`, no status filter | `id`, `le_id`, `booking_code`, `settlement_system_id`, `crds_id`, `status`, `activated_db_le_id`, `db_le_override_src` | `assignment-lineage.csv`; `assignment-key-summary.csv`; `activated_db_le_id` and `override_source` in `booking-review.csv` |

### Platform names

Details and confidence labels: [platform-names.md](../platform-names.md).

| SQL file | Profile, adapter | Reads | Keys, joins and filters | Fields fetched | Feeds |
|---|---|---|---|---|---|
| `booking-platform-names.sql` | `platforms`, `OracleReviewDataSource` | `PRD_EXPORT_BOOKING_CODE`, `PRD_EXPORT_SETTLEMENT_ROUTING`, `PRD_EXPORT_ACCOUNT`, `T_ACCOUNT_CODE_ON_EP`, `T_EPLATFORM` (left join) | Batch entities' bookings; routing on entity, booking code and ICMS system; account on `sr.account_id`; platform account on `x.account_id`; platform on `x.ep_id`. Same booking-status bind as `booking-records`. | booking (`booking_record_id`, `le_id`, `booking_code`, `settlement_system_id`, `booking_status`), routing (`routing_id`, `native_booking_id`), account (`account_id`, `account_entity_id`), platform (`platform_record_id`, `platform_id`, `platform_name`, `customer_code`, `name`, `firm_code`, `firm_name`, `created_at`, `updated_at`) | `booking-platform-names.csv`; `entity-platform-coverage.csv`; workbook platform names |
| `platform-native-bookings.sql` | `native-bookings`, `OracleReviewDataSource` | `T_BOOKING_CODE` | `id IN (native_booking_id values from the query above)`; no entity or status filter | `id`, `le_id`, `booking_code`, `settlement_system_id`, `status` | `platform-native-bookings.csv`; link checks in `booking-platform-names.csv` |

### Active contact people

| SQL file | Profile, adapter | Reads | Keys, joins and filters | Fields fetched | Feeds |
|---|---|---|---|---|---|
| `contact-people.sql` | `contacts`, `OracleUsageEvidenceSource` | `T_CONTACT_PERSON`, `PRD_EXPORT_LEGAL_ENTITY` | `le.id IN (batch IDs)`; `cp.le_id = le.id`; all observed statuses retained; keyset cursor on `cp.id`. Rules count distinct ACTIVE contact IDs after a complete query. | `id`, `le_id`, `status` only. No person name, email or phone. Platform/name fields intentionally null pending a validated bridge. | `contact-person-evidence.csv`, `active-contact-review.csv`, Theme B #6 availability; evidence `review.facts.usageEvidence.contacts` and `review.usage.contacts` |

### Parties and Salesforce

Which party IDs are read (the "first party set"): the hierarchy and report parents from `parent-paths`, the current RHP (`rhp_id`) and current ultimate parent from `current-booking-paths`, every observed RHP and ultimate parent from `all-booking-status-paths` (including inactive/historical paths), and each booking's assigned cRDS party (`crds_id`). `party-facts`, `salesforce-hierarchy` and the identity queries all read this set. Then **one** more round: party IDs referenced by those party rows (survivor, ultimate, immediate parent) and by the Salesforce rows (legal parents, resolved group, L1-L25) are read with `party-facts` only. This is not a full walk up the hierarchy.

| SQL file | Profile, adapter | Reads | Keys, joins and filters | Fields fetched | Feeds |
|---|---|---|---|---|---|
| `party-facts.sql` | `parties`, `OracleReviewDataSource` | `CRDS_DIF_PARTY_BASE`, `CRDS_DIF_PARTY_HIERARCHY` (left join, `primary_flag = 'Y'`) | `party_id IN (party IDs)`; read in two rounds per batch (first set, then referenced set) | `party_id`, `party_std_nm`, `party_legal_nm`, `surviving_entity_id`, `party_industry_status`, `industry_status_date`, `ultimate_parent_id`, `immediate_parent_id` | `party-facts.csv`; names and statuses in `booking-review.csv` and `parent-candidates.csv`; `parent-relationships.csv` |
| `salesforce-hierarchy.sql` | `salesforce`, `OracleReviewDataSource` | `PRD_EXPORT_CLIENT_REP_HIERARCHY_V6` | `TRIM(crds_id) IN (first party set)`, bound as text | `party_id`, `name`, `legal_ultimate_parent_id`, `legal_immediate_parent_id`, `reporting_group_id`, `reporting_level` (`is_reporting_level = 1`), `l1`..`l25` | `salesforce-hierarchy.csv`; reporting-group columns of `booking-review.csv`; `parent-relationships.csv` |

### Bank identity

Party IDs: the first set plus the referenced set above.

| SQL file | Profile, adapter | Reads | Keys, joins and filters | Fields fetched | Feeds |
|---|---|---|---|---|---|
| `bank-lei-identifiers.sql` | `identity`, `OracleReviewDataSource` | `CRDS_DIF_PARTY_IDENTIFIERS` | `party_id IN (party IDs) AND party_id_type_cd = 'LEI'` | `party_id`, `lei` (`party_alt_id`), `valid_from`, `valid_to`, `expiry_date`, `updated_at` | `bank-identity-evidence.csv`; `bank-lei-selection.csv` |
| `bank-identity-cache.sql` | `identity`, `OracleReviewDataSource` | `T_CRDS_PARTY_LOCAL_CACHE` | `party_id IN (party IDs)` | `party_id`, `lei`, `db_le_name`, `country`, `bic`, `status`, `updated_at` | `bank-identity-evidence.csv`; cache conflict check in `bank-lei-selection.csv` |
| `bank-party-address.sql` | `identity`, `OracleReviewDataSource` | `CRDS_DIF_PARTY_ADDRESS` | `party_id IN (party IDs)`; no "latest" or "active" filter | `party_id`, `address_type`, `address_line1`..`address_line4`, `postal_code`, `country` | `bank-identity-evidence.csv` |

### Activity probes

Each probe runs once per export batch, with no keys. It reads at most one row of the constant `1`. No column of the source is fetched.

| SQL file | Profile, adapter | Reads | Result | Feeds |
|---|---|---|---|---|
| `activity-ps-trade.sql` | `activity`, `OracleReviewDataSource` | `PS_TRADE` | `HAS_ROWS`, `NO_ACCESSIBLE_ROWS` or `UNAVAILABLE` | `activity-readiness.csv`; batch extraction status |
| `activity-eplatform.sql` | `activity`, `OracleReviewDataSource` | `V_ICMS_EPLATFORMACCOUNTTRADE` | same | same |
| `activity-mosaic.sql` | `activity`, `OracleReviewDataSource` | `V_MOSAIC_TRANSACTION` | same | same |

`HAS_ROWS` means "the source can be read". It says nothing about any company or booking. A probe that fails makes the batch PARTIAL, so the run exits 2.

## The shared cRDS join chain

Used by `review-cohort.sql` and `review-paths-ctes.sql`:

1. `CRDS_BR_ACCOUNT_XREF.BRPS_ID` = `CRDS_BR_PRODUCT_SYSTEM.productsystemuniqueid`
2. `CRDS_BR_PRODUCT_SYSTEM.BRPA_ID` = `CRDS_BR_PRODUCT_ADOPTION.productadoptionuniqueid`
3. `CRDS_BR_PRODUCT_ADOPTION.BRE_ID` = `CRDS_BR_ADOPTION_ENTITY.adoptionentityuniqueid`
4. `CRDS_BR_ADOPTION_ENTITY.BRL_ID` = `CRDS_BR_ADOPTION_LOCATION.adoptionlocationuniqueid`
5. `CRDS_BR_ADOPTION_LOCATION.BRID` = `CRDS_BUSINESS_RELATIONSHIP.id`
6. `CRDS_BUSINESS_RELATIONSHIP.holderpartyid` = `CRDS_DIF_PARTY_BASE.party_id` (the RHP)
7. RHP `party_id` = `CRDS_DIF_PARTY_HIERARCHY.party_id` with `primary_flag = 'Y'` (`hierarchy_parent_id` = its `ultimate_parent_id`)
8. `ultimate_parent_id` = `CRDS_DIF_PARTY_BASE.party_id`, left join (`report_parent_id`; blank when the parent has no base row)

A path is kept only when `systemaccountid` equals an Active ICMS booking code **and** `systemid` equals that booking's cRDS system, `systemaccountid` is not `TEMP_LE`, and `systemid` is in the fixed list of 27 cRDS system IDs written in both SQL files (assumption A2).

The five status dates behind `recency` are: account link, business relationship, adoption entity, adoption location and product adoption status dates. They are used for ranking only and are not exported.

## Status scopes differ between queries

Row counts of different CSVs are not expected to match.

| Scope | Queries |
|---|---|
| Follows `--booking-status` (Active, or all) | `booking-records`, `booking-platform-names` |
| Active bookings only, always | `review-cohort`, `parent-paths`, `current-booking-paths`, `all-booking-status-paths`, `shared-booking-keys` |
| All statuses, always | `assignment-lineage`, `routing-lineage`, `contact-people` (contact statuses; independent of booking status) |
| No status filter (looked up by ID) | `platform-native-bookings`, `booking-systems`, `settlement-methods` |

Paths, party facts, identities and platform rows have their own grain (one-to-many). Do not add their row counts as if they were one row per booking.

## Database object index (25)

| # | Object | SQL files |
|---|---|---|
| 1 | `PRD_EXPORT_LEGAL_ENTITY` | entities, review-cohort, review-paths-ctes, all-booking-status-paths, shared-booking-keys, contact-people |
| 2 | `PRD_EXPORT_BOOKING_CODE` | booking-records, review-cohort, review-paths-ctes, current-booking-paths, all-booking-status-paths, shared-booking-keys, assignment-lineage, routing-lineage, booking-platform-names |
| 3 | `T_CRDS_BOOKING_SYSTEM` | booking-systems, review-cohort, review-paths-ctes, current-booking-paths, all-booking-status-paths |
| 4 | `T_SETTLEMENT_METHOD` | settlement-methods, current-booking-paths |
| 5 | `CRDS_BR_ACCOUNT_XREF` | review-cohort, review-paths-ctes, all-booking-status-paths |
| 6 | `CRDS_BR_PRODUCT_SYSTEM` | review-cohort, review-paths-ctes, all-booking-status-paths |
| 7 | `CRDS_BR_PRODUCT_ADOPTION` | review-cohort, review-paths-ctes, all-booking-status-paths |
| 8 | `CRDS_BR_ADOPTION_ENTITY` | review-cohort, review-paths-ctes, all-booking-status-paths |
| 9 | `CRDS_BR_ADOPTION_LOCATION` | review-cohort, review-paths-ctes, all-booking-status-paths |
| 10 | `CRDS_BUSINESS_RELATIONSHIP` | review-cohort, review-paths-ctes, all-booking-status-paths |
| 11 | `CRDS_DIF_PARTY_BASE` | review-cohort, review-paths-ctes, party-facts |
| 12 | `CRDS_DIF_PARTY_HIERARCHY` | review-cohort, review-paths-ctes, all-booking-status-paths, party-facts |
| 13 | `PRD_EXPORT_SETTLEMENT_ROUTING` | settlement-routings, routing-lineage, booking-platform-names |
| 14 | `PRD_EXPORT_ACCOUNT` | routing-lineage, booking-platform-names |
| 15 | `T_ACCOUNT_CODE_ON_EP` | booking-platform-names |
| 16 | `T_EPLATFORM` | booking-platform-names |
| 17 | `T_BOOKING_CODE` | platform-native-bookings |
| 18 | `PRD_EXPORT_CLIENT_REP_HIERARCHY_V6` | salesforce-hierarchy |
| 19 | `CRDS_DIF_PARTY_IDENTIFIERS` | bank-lei-identifiers |
| 20 | `T_CRDS_PARTY_LOCAL_CACHE` | bank-identity-cache |
| 21 | `CRDS_DIF_PARTY_ADDRESS` | bank-party-address |
| 22 | `PS_TRADE` | activity-ps-trade |
| 23 | `V_ICMS_EPLATFORMACCOUNTTRADE` | activity-eplatform |
| 24 | `V_MOSAIC_TRANSACTION` | activity-mosaic |
| 25 | `T_CONTACT_PERSON` | contact-people |

The SQL files mix upper and lower case for the same object; Oracle treats unquoted names as the same.

## Provenance

Every exported source row keeps its origin (source ID, dataset, record ID, query run). Every query run is listed in `source-status.csv`: SQL file, SHA-256 of the SQL template (with the shared block pasted in), requested keys, schema, snapshot label, times, status, row and page counts, limits, and a safe failure code (never driver text).

## Optional usage sources and Confluence scope

`UsageEvidenceSource` accepts contact/person/platform facts, verified booking-to-account confirmation routes, and dated booking trade coverage through an independent read-only port. It is not an Oracle query profile. Oracle mode now connects `OracleUsageEvidenceSource` to `contact-people.sql` through the `contacts` profile. The contact count is validated; contact platform names, confirmation routes and dated trades still lack validated Oracle source joins and remain unknown by default. Completeness queries and provenance accompany supplied optional facts, and the raw rows are retained in the evidence bundle and usage CSVs. Source accessibility is never substituted for activity.

The current routing query still aggregates by entity/code/ICMS system, while Confluence specifies settlement method as part of a booking's identity. Exact method-specific routing attribution remains a source-validation question. The new matrix accepts a complete zero wider-key count as no routing, but leaves positive wider-key counts unknown for a specific settlement method (`SETTLEMENT_METHOD_ROUTING_ATTRIBUTION`). See [Confluence requirement coverage](../confluence-theme-b6.md) for the provisional matrix, source gaps and future HTML evidence contract.
