# Build and run on Windows

All commands run in PowerShell from the `icms-export` folder. `icms-export` is its own Gradle build (its own `settings.gradle.kts` and `gradlew.bat`); the repository root build does not include it. Examples use placeholders only (`<...>`) and the synthetic demo IDs `101`, `102`, `103`, `404`.

## Build

You need a JDK 17 (the default toolchain). `-PexportJavaVersion=21` builds with an installed JDK 21; the output still targets Java 17. The wrapper downloads Gradle from the internal mirror and checks its SHA-256. Put the repository credentials (`artifactory_user`, `artifactory_password`) in your own `%USERPROFILE%\.gradle\gradle.properties`, never in the project.

| Command | What it does |
|---|---|
| `.\gradlew.bat clean` | Deletes `build\`. |
| `.\gradlew.bat build` | Compiles, runs all tests, builds the archives. Warnings fail the build. |
| `.\gradlew.bat test` | Runs all tests only. Report: `build\reports\tests\test\index.html`. |
| `.\gradlew.bat installDist` | Creates the runnable app in `build\install\icms-export\` (`bin\icms-export.bat` and `lib\`). |
| `.\gradlew.bat demoExport` | Runs a demo export (IDs 101, 102, 103, 404) into `build\demo-runs\`. |

Outside the bank network, use an installed Gradle 8.14.3 with public repositories: `gradle -PpublicRepositories=true clean build installDist`.

## Start the app

```powershell
$app = ".\build\install\icms-export\bin\icms-export.bat"
& $app --help
```

The start script needs `JAVA_HOME` or `java` on the `PATH`. JVM options go in `JAVA_OPTS` or `ICMS_EXPORT_OPTS`, for example `$env:ICMS_EXPORT_OPTS = "-Xmx4g"`. After a run, `$LASTEXITCODE` holds the [exit code](#exit-codes).

In PowerShell, quote lists: `--ids "101,102"` and `--decision-options "a|b|c"`. An unquoted comma or `|` is read by PowerShell itself.

### Demo run (no database)

```powershell
& $app --demo --ids "101,102,103,404" --output C:\work\review-runs
& $app --demo --all-flagged --output C:\work\review-runs
```

The demo uses the synthetic data built into the app. ID 404 does not exist there, so it is reported as not found.

### Fixture run (a synthetic JSON file instead of a database)

```powershell
& $app --fixture .\src\main\resources\fixtures\demo.json --ids "101,102" --output C:\work\review-runs
```

A fixture is a JSON file with `schemaVersion` (1.0.0 to 1.4.0), `entities`, `bookingRecords`, `bookingSystems`, `settlementMethods`, and optionally `reviewCohortIds` and `review`. Without `review` there is no parent review and no workbook. Its provenance says `synthetic-fixture`.

### Oracle run

1. Copy `config\oracle.example.properties` to a private place outside Git, for example `C:\private\icms.properties`, and fill in the placeholders (see below). Use a read-only database account.
2. Put the password in the environment variable named by `icms.password-env`, for this session only:

   ```powershell
   $secure = Read-Host "Read-only DB password" -AsSecureString
   $env:ICMS_DB_PASSWORD = [System.Net.NetworkCredential]::new("", $secure).Password
   ```

3. Run, then remove the variable:

   ```powershell
   & $app --config C:\private\icms.properties --ids-file C:\private\cohort-50.csv --output C:\work\review-runs
   & $app --config C:\private\icms.properties --all-flagged --export-batch-size 10 --workers 2 --output C:\work\review-runs
   Remove-Item Env:ICMS_DB_PASSWORD
   ```

## Oracle configuration

A minimal file (placeholders only):

```properties
icms.jdbc.url=jdbc:oracle:thin:@//<DB_HOST>:<PORT>/<SERVICE_NAME>
icms.username=<READ_ONLY_USER>
icms.password-env=ICMS_DB_PASSWORD
icms.schema=<SCHEMA>
icms.source-id=icms
# icms.snapshot-at=<YYYY-MM-DDTHH:MM:SSZ>   optional label from the copy owner

query.batch-size=500
query.page-size=1000
query.max-rows=100000
query.timeout-seconds=60
connection.timeout-seconds=15
```

There are 12 profiles: `icms`, `references`, `cohort`, `review`, `parties`, `salesforce`, `identity`, `routings`, `activity`, `platforms`, `native-bookings`, `contacts`. Which SQL each one runs, and why tables joined in one query must sit behind one connection, is in [data-sources.md](data-sources.md#connection-profiles-and-source-boundaries).

**Fallback rule.** A non-ICMS profile **without** its own `jdbc.url` uses the `icms` value of any setting it does not set itself (URL, username, password-env, schema, snapshot-at). A profile **with** its own `jdbc.url` gets no `icms` fallback at all: give it its own username, password-env, schema and snapshot-at.

| Setting | Default | Allowed values and checks |
|---|---|---|
| `<profile>.jdbc.url` | none | Must start with `jdbc:oracle:`. A profile with no URL of its own and no `icms` URL to fall back on is "not configured": its reads are recorded as `NOT_CONFIGURED` and the run exits 2. Profiles with their own URL are not affected. |
| `<profile>.username` | see fallback rule | Required when the profile has a URL. |
| `<profile>.password-env` | `ICMS_DB_PASSWORD` for `icms` and for profiles that fall back to it | Name of an environment variable, never the password. Required for a non-ICMS profile with its own URL (write `ICMS_DB_PASSWORD` there to share the password deliberately). Blank is rejected. A missing variable is exit 64. |
| `<profile>.schema` | see fallback rule; else none | Letter first, then letters, digits, `_`, `$`, `#`; at most 128 characters. Empty means table names are not prefixed. A profile without its own URL can still set its own schema (same connection, other schema). |
| `<profile>.source-id` | the profile name | Letters, digits, `_`, `.`, `-`. A label in the evidence. Never taken from `icms`. |
| `<profile>.snapshot-at` | see fallback rule; else none | ISO-8601 instant. A label only. |
| `query.batch-size` | 500 | 1 to 500. Lookup keys per SQL statement. Not the same as `--export-batch-size`. |
| `query.page-size` | 1000 | 1 to 10,000 rows per page. |
| `query.max-rows` | 100,000 | 1 to 10,000,000 rows per query per export batch. Hitting it marks that read PARTIAL (exit 2); rows are never dropped silently. Use smaller export batches or raise it. |
| `query.timeout-seconds` | 60 | 1 to 3,600. Statement and network read timeout. A timeout is a failed read (exit 2), not an interruption. |
| `connection.timeout-seconds` | 15 | 1 to 3,600. |

Settings of the `icms`, `references` and `cohort` profiles are checked before the export starts. The other profiles are checked when first used, so a mistake there can give exit 64 after the collection folder was created. Such a folder has no `collection-manifest.json`; delete it.

## Export command options

Form: `icms-export (source) (selection) [options]`. Write `--name value` or `--name=value`. Each option at most once. A value may not start with `--`. Unknown or repeated options are exit 64. `--help` works only on its own.

**Source: choose exactly one.**

| Option | Meaning |
|---|---|
| `--demo` | Built-in synthetic data. No database. Takes no value. |
| `--fixture FILE` | Synthetic JSON fixture (see above). |
| `--config FILE` | Oracle properties file (see above). |

**Selection: choose exactly one.**

| Option | Meaning |
|---|---|
| `--ids LIST` | Comma-separated entity IDs, for example `--ids "101,102"`. |
| `--ids-file FILE` | UTF-8 CSV with one column. Optional header `entity_id` on the first line. Empty lines ignored. More than one column is rejected. |
| `--all-flagged` | All companies flagged by the old "multiple ultimate parents" selection (`review-cohort.sql`). Not the whole entity table. Takes no value. |

ID rules for both lists: digits only, greater than zero; leading zeros are removed (`007` becomes `7`); a repeated ID (also after that) is rejected; an empty list is rejected. IDs that do not exist, are inactive or are not flagged are still exported and reported as such.

**Other options.**

| Option | Default | Allowed | Meaning |
|---|---|---|---|
| `--booking-status` | `active` | `active` or `all` (lower case) | `active` exports Active booking assignments only. `all` exports every status in `booking-records.csv` and `booking-platform-names.csv`. Parent rules always use Active bookings; discovery always uses Active bookings. |
| `--export-batch-size` | 10 | 1 to 500 | Companies per batch. Each batch is one folder. |
| `--workers` | 2 | 1 to 4 | Batches read at the same time. Each worker runs its queries one after another, one connection per query. |
| `--output` | `output` (in the current folder) | a folder | A new subfolder named after a random run ID is created inside it. Nothing is ever overwritten. |
| `--decision-options` | `Correct as is`, `Needs correction`, `Need more information` | 2 to 6 options separated by `\|` | Dropdown values of the workbook's decision column. Each option 1 to 40 characters, distinct, no comma or `"`, not starting with `=`, `+`, `-` or `@`, no control characters; the whole list at most 255 characters as an Excel list. |

**Selected clients versus batch size.** The selection decides *how many* clients are exported. The batch size only decides *how they are grouped*. A file with 50 IDs selects 50 clients; with `--export-batch-size 10` they are processed as 5 batches of 10, and with `--workers 2` at most 2 batches are read at once. There is no cap on the number of clients and no `--limit` option. With `--all-flagged`, discovery reads 500 IDs per page and cuts batches inside each page.

**The workbook is part of every normal run.** After the last batch, the export writes the collection manifest under a temporary name (`.collection-manifest.pending.json`), builds `ICMS-company-review.xlsx` and `workbook-receipt.json` in the collection folder, re-reads and checks the workbook, and only then publishes `collection-manifest.json`. A workbook failure gives exit 3: batches stay, the temporary manifest is removed, no manifest is published. No workbook is built (and the run keeps its normal exit code) when the export selected no companies or has no review data. The console then says `No review workbook: <reason>.` Otherwise the last console line is `Review workbook: <path>`. What the workbook contains: [review-workbook.md](../review-workbook.md).

## Workbook command (offline, no database)

Rebuilds the workbook from a saved export. The export itself is never changed.

```powershell
& $app workbook --input C:\work\review-runs\<run-id> --output C:\work\review-books\<new-name> --expected-count 50
& $app workbook --input C:\work\review-runs\<run-id>\collection-manifest.json --output C:\work\review-books\<new-name>.xlsx --expected-ids C:\private\cohort-50-ids.txt --run-note "<note>"
```

| Option | Required | Meaning and checks |
|---|---|---|
| `--input` | yes | A collection folder or its `collection-manifest.json`, or a single batch folder or its `run-manifest.json`. Any other file name, and a folder with only the pending manifest, is exit 64 (an unfinished export is never read). A link named like a manifest that points to a file with another name or in another folder is refused (exit 3). |
| `--output` | yes | A new folder (gets `ICMS-company-review.xlsx` and `workbook-receipt.json`) or a new `.xlsx` file (its receipt is `<name>.receipt.json` beside it). It must not exist yet, its parent folder must exist, and it must be outside the input export folder. |
| `--expected-count N` | no | Whole number of at least 1. Stops (exit 3) unless the export holds exactly N requested companies. |
| `--expected-ids FILE` | no | IDs separated by commas, spaces or new lines; `#` starts a comment. The export's own `--ids-file` works as is: an optional `entity_id` header is skipped, quotes are removed and leading zeros are dropped (`007` = `7`). Stops (exit 3) unless the set matches the export exactly. |
| `--run-note TEXT` | no | Repeatable. A line on the "Rules and assumptions" tab. No control characters. Only the number of notes goes in the receipt. |
| `--decision-options` | no | As for the export. |
| `--help` | no | Only on its own: `& $app workbook --help`. |

It prints the workbook path, the receipt path, the number of clients, parent rows and booking rows, and the workbook's SHA-256. Publishing details and the receipt fields: [review-workbook.md](../review-workbook.md).

## Exit codes

| Code | Export command | Workbook command | What to do |
|---|---|---|---|
| 0 | Complete extraction; workbook built and verified (or not needed). Manifest published. Review findings may still exist. | Workbook written and verified. | Review the workbook. |
| 2 | Some source evidence is incomplete or not configured (SQL error, timeout, row limit, unreachable activity source). Manifest published with that status; the workbook is built and shows what is incomplete. | (not used) | Check `source-status.csv` in each batch for rows whose status is not `COMPLETE`. Fix and re-run, or review knowing which parts are unknown. |
| 3 | Batches written, but the workbook could not be built or verified. No manifest published. The console names the folder and the reason. | A workbook check failed (input integrity, expected count or IDs, reconciliation, Excel size limits, re-read check). Nothing published. | Read the reason. Fix it (for example an existing file, or a too-large export) and run again into a new output folder. A single batch folder can be given to the workbook command. |
| 64 | Invalid option, ID list, fixture or configuration (including a missing password variable or an unreadable `snapshot-at`). | Invalid option or unusable `--input`/`--output`. | Fix the command or configuration. |
| 1 | An input file (configuration, fixture, ID list) cannot be read, or output cannot be written. No manifest. | A file cannot be read or written. | Check paths, permissions and disk space. |
| 70 | A source broke its contract (rows outside the request, bad discovery order) or any unexpected failure. Only the error type is shown. No manifest. | Unexpected failure. Nothing published. | Keep the console text and contact the maintainers. |
| 130 | The run was interrupted. Completed batches stay; no manifest. | Interrupted; nothing published. | Run again into a new output folder. After Ctrl+C, leftover temporary files (names starting with `.`) can remain; delete the unfinished folder. |

Only exit 0 and 2 publish `collection-manifest.json`. **A collection folder without `collection-manifest.json` is not a finished export.** Read results only after 0 or 2. A complete extraction does not prove the source data is correct or current.

## Where the output lands

```text
<output>\
  <run-id>\                          one collection per run (printed as "Collection folder")
    collection-manifest.json         published last; exists only after exit 0 or 2
    ICMS-company-review.xlsx         review workbook, 6 tabs
    workbook-receipt.json            inputs, hashes, options, verification counts
    batches\
      <batch-run-id>\                one folder per batch
        32 CSV files, evidence.json, run-manifest.json (34 files for a full review)
```

The CSV files are listed in the [module README](../../README.md#outputs). CSVs are UTF-8 with BOM; import IDs and booking codes into Excel as Text to keep leading zeros.

The new status and optional usage CSV views are documented in [Confluence coverage](../confluence-theme-b6.md). The existing first four tabs keep their columns; two additive tabs show company evidence and separate matrix categories; it accepts evidence schemas 1.3.0 and 1.4.0. Oracle-mode active-contact counts use the `contacts` profile. Contact platform names, confirmation routings and trading still require validated source joins before their results become known.
