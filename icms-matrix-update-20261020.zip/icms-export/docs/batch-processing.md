# Bounded batch processing

All CLI selections (`--ids`, `--ids-file`, `--all-flagged`) use the same batch processor. Defaults are 10 companies per batch and two extraction workers. Set `--export-batch-size=1..500` and `--workers=1..4`; use one worker for serial operation.

Each worker runs the existing extraction service, SQL and deterministic rules for its company group. JDBC reads remain sequential inside a worker, and each query owns and closes its connection. For explicit selection, two workers therefore run at most two extraction queries/connections at once. Automatic selection can also have one discovery query in flight on the coordinator. Adapters supplied to the processor must support concurrent calls; the Oracle adapters create independent connections and the fixture adapter reads immutable data.

The admission window includes running tasks and completed bundles waiting to be written. At most `workers` bundles are in flight. The coordinator writes one bundle at a time, in selection order, and admits a replacement only after that write succeeds. There is no queue containing every company's booking data. Discovery also remains lazy and reads at most 500 IDs per page.

This is streaming by company batch, not by individual SQL row. Each batch's facts, rules and JSON serialization still need memory; one company with very many bookings can still be large. Query paging and `query.max-rows` remain independent safeguards. Smaller batches do not guarantee that an individual company's source rows fit the configured limit. Truncation remains explicit rather than being treated as missing data.

## Outputs and compatibility

Every finished CLI run (exit 0 or 2) publishes `collection-manifest.json` (schema 1.1.0), including explicit-ID runs; a run that stops earlier publishes none. Resolve `batches/<run-id>/` through its batch receipts. Each full-review folder contains 32 CSVs, evidence schema 1.4.0 and a hash-backed run manifest (34 files). The existing workbook accepts both 1.3.0 and 1.4.0 batch manifests; additional structured views are documented in [Confluence coverage](confluence-theme-b6.md). The collection records the selection, explicit IDs or discovery pages, batch size, worker limit, totals and each batch manifest hash. Earlier collection manifests remain readable because new fields have defaults.

Batching itself does not change business rules or SQL. The later Confluence increment adds separate all-status evidence and provisional assessments while preserving the existing current/baseline parent selection. Run IDs, evidence/query references, timestamps, query scopes and pagination metadata naturally differ between runs and batch sizes. Shared reference facts can occur in several batch bundles. Compare decisions by entity/booking and deduplicate shared reference facts by their business keys; do not sum every raw reference CSV as though all rows were unique.

There is no atomic snapshot across queries, batches or independent sources. Concurrent queries can observe source updates at different times, just as sequential queries can. Query timestamps, source snapshot metadata and partial statuses remain in evidence.

## Failure and cancellation

Expected source failures, including SQL errors and query timeouts, remain explicit query statuses and produce partial evidence. The processor writes those batches and publishes the collection with incomplete status (exit 2). A timeout is never treated as an interruption.

Any other failure cancels the remaining futures, stops admission and leaves completed batch folders intact. No collection manifest is published in that case:

- A failure while writing output files exits 1.
- A source-contract violation exits 70: a source returned rows outside the requested cohort, status or reference keys, a discovery page outside its scope or numeric order, or a non-advancing page cursor.
- Any other exception also exits 70, including an argument or IO error raised by a source, adapter or the environment. The console shows only the exception type, because its message can contain SQL, credentials or client data. Only the CLI's own input, configuration and file boundaries produce 64 or 1.

An interrupted coordinator preserves its interrupt flag and returns exit 130. A cancellation or an interrupted channel close counts as interruption only while that flag is set; a timeout never does. Some batch writes can finish after an interrupt, so the processor checks the flag after every batch write and admits no further extraction once it is set; the collection writer checks it again immediately before publishing the collection manifest. An interrupt received during any batch write therefore exits 130 without a manifest. JDBC interruption is best effort; configured driver/query timeouts still bound blocked reads.

The CLI prints each saved batch and final totals. Parallelism improves throughput only when source capacity permits it. Start with two workers and measure query durations, memory and database load before raising the limit.
