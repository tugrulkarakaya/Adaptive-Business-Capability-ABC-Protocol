# Theme B #6: Confluence requirements and evidence contract

The `UsageEvidenceSource` port accepts verified contact, confirmation-route and dated trade facts from independent sources. Oracle mode now wires `OracleUsageEvidenceSource` to the validated contact-count query. Confirmation routes, dated trades and the contact-to-platform-name bridge remain unconfigured until their joins are validated. When a validated source supplies complete evidence, the same rules, JSON and CSV outputs use it.

This implementation follows the **WIP** “Theme B #6 (Ultimate parent)” page captured on 20 October 2026. The [captured requirements](reference/theme-b6-confluence-20261020.md) are retained in this repository for team review. It adds evidence and separate, provisional assessments for human review. It does not select a correct parent, deactivate a booking, change bank data, or call an AI model.

## How to interpret the output

The existing current-parent and baseline-parent calculations retain their original meaning. The new inactive-party and inactive-booking checks do not remove paths from those calculations. In particular, `REACTIVATING` is acceptable for the new inactive-booking check; it does not change the existing current-parent rule, which requires an `ACTIVE` account link.

All relevant cRDS path/status evidence must remain visible, including paths rejected by the current-parent filter. One ICMS booking can have several cRDS paths. A path-level assessment is evidence about that path, not a statement that the path is the correct match. Parent summaries count distinct ICMS booking records and distinct booking-code strings. Multiple source paths do not create additional booking records. Each record uses one status bucket within a parent: a single observed status, `AMBIGUOUS` for mixed statuses, or `UNKNOWN` for missing status. The full observed statuses remain visible. A record can be associated with several parents; do not add parent counts to obtain a distinct company total.

Unknown is not zero, false, or proof of inactivity. A source must have a complete, validated read before an empty result can establish absence. Evidence IDs link rows to raw source records; query-run IDs link them to the query hash, requested keys, source status and execution details in `evidence.json`.

## Added CSV views

| File | Row meaning |
|---|---|
| `theme-b6-status-paths.csv` | One raw all-status cRDS path fact, including source evidence/query IDs. It is not limited to the selected current-parent path. |
| `theme-b6-booking-assessments.csv` | One ICMS booking/path/category assessment. Actual confidence and conditional levels have separate columns; row counts are not booking counts. |
| `theme-b6-rhp-summary.csv` | One observed RHP per ICMS entity, with distinct statuses/dates and booking-record count. |
| `theme-b6-parent-status-summary.csv` | One parent per ICMS entity across all-status path associations, with deduplicated records/codes and an explicit evidence scope. This is not the existing current-parent count. |
| `theme-b6-source-availability.csv` | Source and business-policy limitations that prevent a requirement from becoming a confirmed result. |
| `active-contact-review.csv` | One entity's distinct active-person count and grouped CUSTOMER platform names, or an unknown result with limitations. |
| `booking-usage-evidence.csv` | One active ICMS booking's confirmation-route and dated trading assessments, with an explicit coverage window and limitations. |
| `contact-person-evidence.csv` | Raw optional contact/person/platform facts, with evidence and query-run references. |
| `confirmation-routing-evidence.csv` | Raw optional confirmation-route facts and their verified-booking/account-link flag. |
| `trading-coverage-evidence.csv` | Raw optional trade-window counts, dates and completeness/link flags. |

The original exports remain available. A full review batch now has **32 CSV files**, `evidence.json` and `run-manifest.json`: **34 files**. The run manifest hashes the other **33 artifacts** and records CSV row counts. Core-only fixtures without review data retain their smaller output set. Evidence/run-manifest schema **1.4.0** contains the new typed evidence and assessments for later HTML or AI use; collection schema remains **1.1.0**.

`crds_system_id` in the path and assessment CSVs is the mapped cRDS system, not the original ICMS settlement-system ID. Join `booking_record_id` to `booking-records.csv` to see the ICMS system and settlement-method reference names.

## Current presentation and compatibility

Workbook format `icms-review-workbook/5` retains the existing first four sheets, their columns and current/baseline meanings, and adds **Company evidence** and **Matrix review**. It reads supported 1.3.0 and 1.4.0 batch manifests, validates the size/hash/row count of each CSV it consumes, including the five new evidence views when present. Older exports without those views show unknown supplementary evidence. **Company evidence** shows active-person counts, independent contact-name coverage, RHP statuses, all-path parent/status counts and source gaps. **Matrix review** shows one row per booking/path with the three independent WIP category results, conditional levels, missing inputs and provenance. The future HTML page can present the same evidence model. Older evidence JSON remains readable because the new fields have defaults; this does not promise compatibility for unrelated consumers that hard-code schema 1.3.0 or a fixed artifact count.

The code implements the new status evidence, distinct parent counts and separate suggested-matrix categories. It also implements optional contact/name, confirmation and dated trade contracts/rules. It does **not** establish that every Confluence field is populated in Oracle mode: active-person counts have a validated Oracle adapter, while contact platform names, confirmation routes and dated trades still need validated source joins. The default Oracle export states those gaps explicitly. The JSON `review.usage.entityTrading` includes a company-level trading summary: observed active-booking count, confirmation of booking-cohort completeness, confirmed trading/no-trading counts, unknown count and confirmed-trading percentage. The percentage uses the observed active-booking denominator and is only emitted when the booking read is complete; unknown records remain explicitly counted and must not be described as no trading. The summary does not add another CSV. AI associations and the new HTML interface are not implemented here. The new Excel tabs contain evidence only; the existing human decision cells remain empty.

## Requirement coverage

| Confluence data point | Evidence and behaviour |
|---|---|
| ICMS legal-entity ID and name | Original entity and booking exports; kept as bank identifiers, not substituted with a name match. |
| Identified ultimate parents and legal names | Current-parent candidates, baseline comparison and all-path evidence remain separate. A candidate is not a final decision. |
| RHP industry statuses at company level | Summarise the distinct observed RHP IDs/statuses, keeping missing values and incomplete reads visible. |
| Ultimate-parent industry status and date | Party facts, candidate evidence and booking/path status evidence. Source dates are displayed as supplied. |
| Booking-record counts, unique codes and cRDS status breakdown per parent | Dedicated parent-status summary. Distinct record IDs and codes prevent inflation from multiple paths. Overlapping statuses are visible rather than forced into one status. |
| Active contact people: count | `contact-people.sql` reads contact ID, legal-entity ID and status from `T_CONTACT_PERSON`, joined by `LE_ID` to the requested ICMS entity. Rules count distinct ACTIVE contact IDs only after a complete read. No person name, email or phone is fetched. Do not infer the count from account/platform rows. |
| Active contact people: Name on EPlatform | Optional verified contact source: active people only, CUSTOMER-only names, suffix removal and Bloomberg family grouping. Existing booking/account platform names remain separate evidence and are not labelled as names of active people. The live count adapter intentionally returns null platform/name fields until its external-system bridge is validated. A complete count therefore does not imply complete platform names; `ACTIVE_CONTACT_CUSTOMER_PLATFORM_NAMES_NOT_VALIDATED_OR_INCOMPLETE` identifies this separate gap. |
| Recent trading: company summary | JSON `review.usage.entityTrading` summarises distinct active booking records: confirmed trading, confirmed no trading and unknown. The percentage is only available with a complete booking cohort; unknown trading records remain visible. The trade contract checks an explicit dated 24-month window, booking link and complete coverage. The default remains unknown because no validated Oracle trade adapter is connected. Source-accessibility probes do not demonstrate trading or absence of trading. |
| Booking code, system name and settlement method | Original booking records and reference lookup evidence. A record is identified by its source record ID; its business key includes legal entity, booking code, settlement system and settlement method. |
| ICMS-assigned cRDS ID | Original assignment evidence and comparison with the resolved RHP. It is not a comparison with the ultimate parent. |
| Settlement-routing count and BLOCK/FUND | Existing routing summary and account/assignment lineage. Current routing aggregation is entity + booking code + ICMS system. Settlement-method-specific attribution still requires source validation; the wider aggregation must not be presented as an exact method-specific count. A complete zero across that wider key proves no route for the booking; a positive wider-key count does not establish a route for its settlement method, so the new matrix leaves that input unknown and lists `SETTLEMENT_METHOD_ROUTING_ATTRIBUTION`. |
| Confirmation-routing ePlatforms | Optional verified confirmation-route contract requires a booking-to-account link and complete query. No validated Oracle adapter is connected by default. An account's ePlatform name is not proof of a confirmation route. With a complete zero-settlement-routing result, the matrix may use the document's explicit no-settlement-implies-no-confirmation assumption. |
| cRDS booking status | Preserve `ACCOUNTXREFSTATUS` on all relevant path evidence, including inactive paths excluded from the current-parent calculation. Missing or conflicting statuses remain visible. |
| cRDS RHP ID, legal name, industry status and date | Path evidence plus cRDS party facts, with source IDs and query-run provenance. |
| cRDS ultimate-parent ID, legal name, industry status and date | Path evidence plus cRDS party facts, with source IDs and query-run provenance. |
| Salesforce reporting group | Existing flattened hierarchy logic; `IS_REPORTING_LEVEL = 1` uses that party's own ID. Same/different/ambiguous results remain evidence, not proof of ownership. |
| AI association between parent and Salesforce group | **Outside this non-AI increment.** Structured facts and assessments are available for future AI input. No model output is fabricated. |
| Booking recent trading | Optional verified source contract implemented; unknown until a dated trade adapter supplies validated 24-month coverage. |
| Suggested unused-booking confidence | The three source categories are assessed separately. Missing required inputs produce `NOT_DETERMINED`, with conditional levels available for review. No overall winning confidence or automatic action is invented. |

## Verified contact-count source

`contact-people.sql` runs through the `contacts` profile, which inherits the `icms` connection unless independently configured. It reads `T_CONTACT_PERSON.ID`, `LE_ID` and `STATUS`, keeps all observed statuses, and joins `PRD_EXPORT_LEGAL_ENTITY.ID = T_CONTACT_PERSON.LE_ID`. Rules count distinct IDs with status ACTIVE. This data is contact-count evidence; the query does not fetch person names, email addresses or phone numbers.

DEV sample checks observed **248 → 7**, **47 → 5**, **850 → 8**, and **894 → 2** active people. These are point-in-time source observations, not fixed production expectations or a claim about all 50 entities. A complete count and an unvalidated platform/name bridge are reported separately. With zero active contacts, an empty contact-name list is valid; with active contacts but no validated name bridge, names remain undetermined.

## The suggested matrix

Party statuses `ACTIVE` and `IN_FORMATION` do not trigger the inactive-party concern. The page explicitly lists `IN_ADMINISTRATION`, `IN_LIQUIDATION`, `DELETED`, `INACTIVE` and `ABANDONED` as its inactive-party cases. An unrecognised status is not silently classified as inactive.

Booking statuses `ACTIVE` and `REACTIVATING` do not trigger the inactive-booking concern. The explicit concern statuses are `DELETED`, `INACTIVE` and `SUSPENDED`. Other or missing statuses require review.

| Separate category | Evidence condition | No recent trading | Recent trading |
|---|---|---|---|
| Inactive party | RHP is in the listed concern set; ultimate parent is ACTIVE or IN_FORMATION | MEDIUM_HIGH | MEDIUM |
| Inactive party | RHP and ultimate parent are in the listed concern set | HIGH | MEDIUM |
| Inactive booking | cRDS booking status is DELETED, INACTIVE or SUSPENDED | HIGH | MEDIUM |
| Routings and trading | No settlement routes; therefore no confirmation routes under the documented assumption | HIGH | LOW |
| Routings and trading | Settlement routes; no confirmation routes | MEDIUM_HIGH | LOW |
| Routings and trading | Settlement and confirmation routes | MEDIUM | LOW |

Conditional values mean “if this missing input were confirmed.” They are not actual confidence levels and must have a different label in any future HTML page. With the default unconfigured source, actual trading remains unknown; a verified optional source can provide it. Inactive-party and inactive-booking cases with trading have MEDIUM confidence; the routings category's LOW result must not override them.

## Decisions still owned by the business/source owners

1. The page marks placement of the inactive-party and inactive-booking categories in Theme B #6 versus Theme A #1 as **TBC**. Keep the categories separate and provisional until this is agreed.
2. The page supplies no precedence when several categories match. Do not combine them into a single score or choose a main parent by their scores.
3. The active-person count join is validated. Validate its external-system/platform-name bridge, CUSTOMER name semantics and ePlatform family grouping before displaying contact names.
4. Validate confirmation-routing tables, account joins, route statuses and platform attribution.
5. Validate trade sources, event dates, booking/system/entity joins, coverage dates, source freshness and the 24-month boundary before classifying trading or absence of trading. Candidate systems named by the page are RMS, TKaaMS and ROME; these names are not validated integrations.
6. Confirm settlement-method-specific routing attribution. The current three-part aggregation is a documented limitation, not an exact four-part match.

The page's final “Deterministic Rules” section contains a heading and introductory sentence but no populated rule list. The implementation therefore traces the Identification Logic, Data Points and twelve-row suggested matrix explicitly; it does not claim a further missing rule list was supplied.

## Future HTML presentation

Consume the same versioned evidence bundle and dedicated CSV views. Show a concise company summary, parent groups and booking detail, with expandable raw path/status evidence and source limitations. Keep current-parent results, all-path evidence, provisional concerns, missing inputs and the human decision visually separate. Never hide an inactive alternate path simply because it did not qualify for the current-parent selection.
