import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    kotlin("jvm") version "2.2.21"
    kotlin("plugin.serialization") version "2.2.21"
    application
}

group = "com.db.clientinsights"
version = "0.5.0"

kotlin {
    jvmToolchain(providers.gradleProperty("exportJavaVersion").orElse("17").get().toInt())
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
        allWarningsAsErrors.set(true)
    }
}

tasks.withType<JavaCompile>().configureEach { options.release.set(17) }

dependencies {
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.9.0")
    implementation("org.apache.commons:commons-csv:1.14.1")
    runtimeOnly("com.oracle.database.jdbc:ojdbc11:23.3.0.23.09")
    testImplementation(platform("org.junit:junit-bom:5.13.4"))
    testImplementation("org.junit.jupiter:junit-jupiter")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
    testImplementation("com.h2database:h2:2.3.232")
}

application { mainClass.set("com.db.clientinsights.export.cli.ExportRunnerKt") }

val exportVersion = version.toString()
val producerRevision = providers.exec {
    workingDir(rootDir)
    commandLine("git", "rev-parse", "HEAD")
    isIgnoreExitValue = true
}.standardOutput.asText.map { it.trim().ifEmpty { "unknown" } }.orElse("unknown")
val producerDirty = providers.exec {
    workingDir(rootDir)
    commandLine("git", "status", "--porcelain", "--untracked-files=normal")
    isIgnoreExitValue = true
}.standardOutput.asText.map { it.isNotBlank() }

val generateBuildInfo by tasks.registering {
    val destination = layout.buildDirectory.dir("generated-resources")
    inputs.property("exportVersion", exportVersion)
    inputs.property("revision", producerRevision)
    inputs.property("dirty", producerDirty)
    outputs.dir(destination)
    doLast {
        destination.get().file("export-build.properties").asFile.apply {
            parentFile.mkdirs()
            writeText("version=$exportVersion\nrevision=${producerRevision.get()}\ndirty=${producerDirty.get()}\n")
        }
    }
}
sourceSets.main { resources.srcDir(generateBuildInfo) }
tasks.test { useJUnitPlatform() }

tasks.register<JavaExec>("demoExport") {
    group = "application"
    description = "Export a synthetic cohort, with no database or AI connection."
    classpath = sourceSets.main.get().runtimeClasspath
    mainClass.set(application.mainClass)
    args("--demo", "--ids=101,102,103,404", "--output=${layout.buildDirectory.dir("demo-runs").get().asFile}")
}
