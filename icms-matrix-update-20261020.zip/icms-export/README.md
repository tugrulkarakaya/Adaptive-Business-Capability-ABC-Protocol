# ICMS deterministic review export

This Kotlin application reproduces the Oracle-backed, non-AI review of ICMS booking assignments and cRDS parent paths. It reads sources, checks the original business rules, and writes CSVs, a versioned evidence bundle and the Excel review workbook for the team ([Review workbook](docs/review-workbook.md)). It never changes bank records. No model, agent, AI token or GLEIF download is required.

**Team handover: start at [docs/handover/README.md](docs/handover/README.md)** (how to run it and with which options, assumptions and open questions, which SQL reads which table and feeds which file, implementation flow, tests and QA).

## Select cases

Choose exactly one selection mode:

```text
--ids=248,300
--ids-file /path/to/cohort.csv
--all-flagged --export-batch-size=10 --workers=2
```

`--all-flagged` discovers every company selected by the previous baseline multiple-ultimate-parent report. This is **not** a scan/export of the whole legal-entity table. The old observation of 1,083 cases was a database result, not a fixed selection size. The original ACTIVE booking filter, system allowlist, account-link ranking, lowest-parent first-match rule, and distinct-parent count are retained. Baseline selection is separate from the official current-link review; a baseline flag is not a confirmed current ownership error.

ID input is a single `entity_id` CSV column, optionally headed `entity_id`. IDs must be positive integers. Leading zeros are canonicalized; duplicate IDs are rejected. Explicit input can include unflagged, missing and inactive entities. There is no 25-, 50- or 1,083-entity cap.

All selection modes process groups of 10 companies by default. `--export-batch-size` accepts 1..500 and `--workers` accepts 1..4 (default 2). Automatic selection discovers at most 500 IDs per page. The coordinator admits at most the configured number of batches, including finished batches awaiting persistence. It writes each batch in input order and admits the next batch only after a write completes. The application retains collection metadata and IDs, not all groups' booking/path records in memory. Discovery pages use numeric keyset cursors with one-row lookahead. If discovery fails, previously completed batches remain available and the collection is marked incomplete.

## Build and run

Open `icms-export` as a standalone Gradle project. It does not compile the old Java/AI prototype. JDK 17 is the default toolchain; `-PexportJavaVersion=21` selects another installed toolchain while the artifact still targets Java 17.

Inside the bank:

```powershell
.\gradlew.bat clean
.\gradlew.bat build
.\gradlew.bat test
.\gradlew.bat installDist
```

The wrapper uses the approved internal Gradle mirror and verifies its SHA-256. Keep credentials in user-level Gradle properties. Outside the bank, use the pinned Gradle 8.14.3 installation with `-PpublicRepositories=true`; public repository selection does not replace the wrapper's internal distribution URL.

```bash
gradle -PpublicRepositories=true clean build test installDist
./build/install/icms-export/bin/icms-export --demo --all-flagged --output=build/demo-runs
```

Windows launcher: `build/install/icms-export/bin/icms-export.bat`.

Copy `config/oracle.example.properties` to an untracked local file. Store the database password in the configured environment variable. Use a read-only account.

```powershell
.\build\install\icms-export\bin\icms-export.bat --config C:\private\icms.properties --ids-file C:\private\cohort-50.csv --output C:\review-runs
.\build\install\icms-export\bin\icms-export.bat --config C:\private\icms.properties --all-flagged --export-batch-size=10 --workers=2 --output C:\review-runs
```

`--booking-status=active` is the default. `--booking-status=all` includes inactive raw assignments too; parent business rules still use only Active assignments. Inactive rows are not silently included in current-parent counts.

Exit codes:

| Code | Meaning |
|---|---|
| `0` | Complete extraction; the review workbook was built and verified. Review findings may still exist. |
| `2` | Incomplete or unconfigured source evidence (SQL errors, query timeouts, row limits, unconfigured sources). The collection manifest is published with that status; the review workbook is still built and shows the evidence as incomplete. |
| `3` | The batches were written, but the review workbook could not be built or failed its re-read check. The batches stay; the collection manifest is **not** published. |
| `64` | Invalid command-line input, fixture or configuration found by the export's own validation, including an unreadable `snapshot-at`, a missing password environment variable and a separate profile URL without `password-env`. |
| `1` | File error: an input file (configuration, fixture or ID list) cannot be read or output cannot be written. |
| `70` | A source broke its contract (rows outside the requested scope, invalid discovery order or a non-advancing page cursor), or any other failure, including an unexpected argument or IO error raised by a source, adapter or the environment. The console shows a fixed message and, for unexpected failures, only the exception type; never raw exception, SQL or credential text. |
| `130` | Interrupted export. Completed batch folders remain. |

Only `0` and `2` publish a collection manifest (and, when the export has review data, the review workbook beside it); schedulers should read results only after those codes. A complete extraction is not proof that source data is correct or current.

## Business rules and evidence

The complete scope map is in [Deterministic scope](docs/deterministic-scope.md).

- Keep original assignments, system/method names and cRDS mappings; check missing, duplicate and ambiguous source data.
- Keep every candidate parent path, including inactive/historical paths, baseline-hidden parents and selection ties.
- Apply the official rule: Active ICMS entity and booking, ACTIVE account cross-reference and business relationship, unended primary hierarchy; select the most recent current path, then lowest parent ID, then RHP.
- Compare baseline, active-link, all-path and official-current parent counts independently. Incomplete reads produce unknown results, never false absence or a false pass.
- Compare the assigned booking cRDS ID with its selected RHP. This does not establish the ICMS company's own cRDS identity.
- Resolve Salesforce legal parents, reporting groups and all L1-L25 positions. `IS_REPORTING_LEVEL = 1` uses the row's own cRDS ID even when the explicit reporting-group field is empty or different. Missing rows and duplicate rows remain distinct outcomes.
- Retain party status dates, surviving entities, own ultimate/immediate parents, common tops and Salesforce hierarchy relationships. Name/typo/shared-brand signals are clues, never legal-identity proof.
- Retain shared booking keys and other ICMS entity names. Shared keys do not establish common ownership.
- Match settlement routings by entity + booking code + ICMS settlement system. Export BLOCK/FUND types, last change, account and assignment lineage. A routing's booking-code ID is checked as lineage, not assumed to be the reliable join.
- Read typed bank LEIs and validity/expiry dates, local identity cache, BIC/country/status and addresses. Check LEI checksum, validity, conflicts and source completeness. Bank identifier expiry remains separate from GLEIF renewal semantics.
- Preserve the original tri-state unused-confidence matrix. Recent trading and confirmation routing have no validated booking-level source in the previous code. They remain unknown. The three legacy activity sources are checked for accessibility only; accessible rows do not establish activity for a booking.

`PASS` in extraction-quality columns covers only those checks. Parent eligibility and reporting-group comparisons have separate explicit columns. All findings are read-only review support.

## Review workbook (Excel)

Every export also writes `ICMS-company-review.xlsx` (six tabs: Summary, Company review, Bookings, Rules and assumptions, Company evidence, Matrix review) and its `workbook-receipt.json` into the collection folder, before it publishes `collection-manifest.json`. The last console line is the workbook path. The workbook shows facts for people to decide; it chooses no parent and every reviewer cell starts blank. `--decision-options "a|b|c"` replaces the team's draft reviewer statuses.

To build the workbook again from a saved export, without a database:

```powershell
.\build\install\icms-export\bin\icms-export.bat workbook --input C:\review-runs\<collection-folder> --output C:\review-workbooks\review-2026-10-21
```

See [Review workbook](docs/review-workbook.md) for inputs, outputs, the receipt, exit codes and limits.

## Outputs

Every CLI run writes a new collection directory. A full review batch produces 32 CSV files plus `evidence.json` and `run-manifest.json` (34 files; the manifest hashes the other 33). Core-only fixtures without review data retain a smaller output set:

| File | Purpose |
|---|---|
| `entities.csv`, `booking-records.csv` | Selected companies and original booking assignments with extraction checks. |
| `data-issues.csv`, `source-status.csv` | Findings and per-query provenance, completeness, limits, timing and sanitized errors. |
| `entity-review.csv`, `booking-review.csv` | Current/baseline parent results, RHP/group comparisons, routing and unused-confidence results. |
| `parent-candidates.csv`, `parent-relationships.csv` | Every candidate, signals and evidence-linked deterministic relationship clues. |
| `parent-paths.csv`, `party-facts.csv`, `salesforce-hierarchy.csv` | Raw path, party and complete L1-L25 hierarchy evidence. |
| `bank-identity-evidence.csv`, `bank-lei-selection.csv` | All bank identifier/cache/address observations and dated identifier assessments. |
| `settlement-routings.csv`, `shared-booking-keys.csv` | Routing configuration and other entities sharing booking keys. |
| `assignment-lineage.csv`, `assignment-key-summary.csv`, `routing-lineage.csv` | Assignment overrides/activation and account/routing lineage. |
| `activity-readiness.csv` | Source accessibility and the unvalidated activity-join limitation. |
| `booking-platform-names.csv` | Account/platform names with separate native-ID-verified, booking-key-only and conflicting links, timestamps and evidence references. |
| `platform-native-bookings.csv` | Original booking records used to validate routing references; these IDs can differ from export IDs. |
| `entity-platform-coverage.csv` | Per-entity name coverage, disjoint booking counts by link confidence and explicit source availability. |
| `theme-b6-status-paths.csv`, `theme-b6-booking-assessments.csv` | All-status cRDS path facts and separate WIP matrix-category assessments, with actual and conditional levels kept separate. |
| `theme-b6-rhp-summary.csv`, `theme-b6-parent-status-summary.csv`, `theme-b6-source-availability.csv` | RHP statuses, deduplicated all-path parent/status counts, and source/policy limitations. |
| `active-contact-review.csv`, `booking-usage-evidence.csv` | Validated Oracle active-person counts and optional contact-name/confirmation/trading results; unvalidated inputs remain unknown. |
| `contact-person-evidence.csv`, `confirmation-routing-evidence.csv`, `trading-coverage-evidence.csv` | Raw optional usage facts, coverage/link flags and provenance. |
| `evidence.json` | Schema 1.4.0: normalized raw facts, source references, query provenance and deterministic results. Future AI adapters can consume this boundary. |
| `run-manifest.json` | Producer, cohort, counts and hashes/sizes of every other artifact; written last. |

Both explicit-ID and automatic runs write `collection-manifest.json` plus `batches/<run-id>/` folders containing the same per-batch outputs. Collection schema 1.1.0 records selection rule/version, explicit requested IDs or discovery pages, worker/batch limits, overall completeness, totals, batch paths and each batch manifest's SHA-256. Batch evidence and run-manifest schema is 1.4.0. Consumers of earlier explicit-ID runs must now resolve the batch paths from the collection manifest. A collection is published only when its collection manifest exists. A published manifest can report incomplete extraction; inspect its status. Existing folders are never overwritten. See [Bounded batch processing](docs/batch-processing.md) for memory, cancellation and concurrency limits.

CSVs use UTF-8 BOM, RFC 4180 quoting and CRLF. Formula-like cell prefixes are escaped for spreadsheets; exact original text remains in JSON. Import IDs and booking codes into Excel as Text to preserve leading zeros and long identifiers.

### Unknown entity totals

Every count and flag in `entity-review.csv` (and `review.entities` in `evidence.json`) is a claim about one whole resolved ICMS entity. It is blank in CSV and `null` in JSON when a read it depends on did not complete for that entity; blank never means 0 or false. A requested ID whose entity lookup did not complete, found no row or found several rows has every total blank, while its status stays `UNKNOWN`.

| Columns | Known only when |
|---|---|
| `active_records` | The entity lookup completed with exactly one row (H) and its booking read completed (B). |
| `current_parent_count`, `flagged_current`, `current_records` | H, and the official rule's evidence is complete: current-path read, ICMS extraction (including settlement-method lookups) and exactly one current-path row per Active booking. |
| `baseline_parent_count`, `flagged_baseline`, `active_link_parent_count`, `matched_keys`, `keys_without_path`, `keys_with_several_parents`, `tied_baseline_keys` | H and B, every Active booking's settlement-system lookup completed with at most one row (K), and the parent-path read completed. |
| `all_path_parent_count` | Both rows above: it unites path parents and current parents. |
| `shared_keys` | H, B and K, and the shared-key read completed. |
| `keys_with_several_current_parents` | The current columns' conditions and K. |

A booking without a settlement system, an unknown system or a system without a cRDS mapping is a known absence after a completed lookup, not unknown evidence. A failed settlement-method lookup leaves the current columns blank (the existing conservative rule) but not the path columns. Salesforce, routing, party-name, platform and activity sources never blank these totals, so an unavailable activity view leaves them unchanged even though the batch reports PARTIAL extraction. `exported_booking_count` in `entities.csv`, manifest counts and the raw rows still count every row actually exported, including partial reads and bookings of entities that were not found; they are observed row counts, not entity totals.

Schema 1.3.0 widens six EntityReview fields that were always integers in 1.2.0 (`matchedKeyCount`, `keysWithSeveralParents`, `tiedReportKeys`, `currentRecords`, `activeBookingRecords`, `keysWithSeveralCurrentParents`) to nullable, and the remaining totals and flags can now be null in more cases. A strict 1.2.0 consumer that decodes these fields as non-null integers can fail on 1.3.0 output; this is not a backward-compatible change for such consumers. CSV file names, headers and column order are unchanged.

Schema 1.0.0, 1.1.0, 1.2.0 and 1.3.0 fixtures remain readable. Synthetic fixtures are explicitly identified and do not prove Oracle driver compatibility or production counts. Producer metadata includes version, Git revision and checkout-dirty state at build time.

## Source boundaries and limits

The `icms`, `references`, `cohort`, `review`, `parties`, `salesforce`, `identity`, `routings`, `activity`, `platforms`, `native-bookings` and `contacts` profiles can have separate URLs/credentials/schema/source IDs. A profile without its own URL inherits `icms`, including its password variable. A separate URL must provide its own credentials and snapshot metadata, including an explicit `<profile>.password-env`; omitting or blanking it is a configuration error raised before any environment variable is read. Set `<profile>.password-env=ICMS_DB_PASSWORD` to share the ICMS password deliberately. No cross-source atomic snapshot is claimed.

The platform-name SQL needs the copied export booking/routing/account tables plus `T_ACCOUNT_CODE_ON_EP` and `T_EPLATFORM` in the `platforms` connection. Original `T_BOOKING_CODE` IDs are looked up separately in `native-bookings`. See [Platform name evidence](docs/platform-names.md) for the join rules and confidence labels. Stored names never establish actual platform trading, company identity equivalence or ownership.

The legacy baseline/current-path SQL joins copied ICMS, mapping and cRDS tables inside the `cohort`/`review` connection. That connection must expose those tables or compatible views. Changing a URL alone cannot make a SQL join span independent databases. The `ReviewCohortSource` and `ReviewDataSource` ports isolate this requirement so a later adapter can compose sources without rewriting rules or exports. Separate parties, Salesforce, identity, routing and activity lookups already use their own profiles.

SQL is in `src/main/resources/sql/icms/oracle`. Entity/party IDs are bound parameters; schema names are validated. Query hashes include expanded shared path CTEs. Batches contain at most 500 lookup keys, numeric keyset pages avoid OFFSET, and each query uses a read-only transaction.

`query.max-rows` defaults to 100,000 per dataset within one extraction batch. Reaching the limit triggers lookahead: genuine truncation is explicit and exits incomplete, while an exactly full result is complete. Use smaller export batches or raise the explicit configured limit when needed. No source rows are silently treated as absent after truncation. Historical baseline selection quirks, including fallback to non-active links and lowest-parent first-match selection, remain visible rather than being silently repaired.

## Structure

`cli` validates options and wires adapters. `application` orchestrates extraction and bounded cohort runs. `ports` defines source and persistence contracts. `domain` holds typed facts and versioned evidence. `rules` contains pure extraction, parent, name, identifier and unused-confidence checks. `adapters/icms` owns JDBC/configuration/SQL mapping; `adapters/csv` and `adapters/bundle` write artifacts. Source layout remains `src/main/kotlin` and `src/test/kotlin`.

## Confluence Theme B #6 evidence

[Confluence coverage and source limitations](docs/confluence-theme-b6.md) describes the all-status cRDS paths, separate provisional matrix categories, contact/platform-name rules and dated trade-coverage contracts. Evidence schema 1.4.0 adds these results without changing current/baseline parent selection. Normal exports add ten CSV views; the existing four workbook tabs keep their columns, while Company evidence and Matrix review show the new counts/statuses and separate WIP category results. The same structured views are ready for the planned HTML report. Active-contact counts use a validated Oracle query. Contact platform names, confirmation routings and trading stay unknown in Oracle mode until their source joins are validated. No AI calls or bank record updates are performed.
