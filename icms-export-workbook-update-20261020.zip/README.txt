ICMS export workbook update - 20 October 2026

Contains one frozen source package with 68 code, test and documentation files.
No credentials, local configuration, bank data, generated reports or dependencies.
The package is JSON compressed with gzip; it contains file paths, original source hashes, new source hashes and full UTF-8 source content.
The transfer operator must validate original file hashes and back up existing files before applying it.

Package SHA256: bc1814525394927dc9a57f338cec4bc296b056a7f9e4ac80a6763f8f4052b697

Local verification: clean build/installDist; 239 tests passed, no failures or skipped tests.
Windows verification and real-data Excel QA are still pending.
